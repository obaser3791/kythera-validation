#!/usr/bin/env python
"""Workflow 5. Block E: missingness, multiple imputation and delta-adjusted sensitivity."""

from __future__ import annotations

from _common import cohort, dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_e_missingness as block_e


def main() -> None:
    args = parser(__doc__, n=100_000, extra={"--m": {"type": int, "default": 20, "help": "imputations"}}).parse_args()
    result = block_e.run(cohort(args.n, args.seed), m=args.m, seed=args.seed)

    heading("Published")
    pub = result["published"]
    print(
        f"  Little's chi2={pub['littles_chisq']} df={pub['littles_df']}  "
        f"m={pub['imputations']}  pooled FMI={pub['pooled_fmi']}  "
        f"pooled missingness={pub['pooled_missingness_pct']}%"
    )

    heading("Missingness profile (highest first)")
    for row in result["profile"][:10]:
        print(f"  {row['variable']:28s} {row['overall_pct']:6.2f}%")

    heading("Recomputed Little's test")
    lt = result["littles_test"]
    print(
        f"  chi2={lt['chisq']:.3f}  df={lt['df']}  p={lt['p_value']:.4f}  "
        f"patterns={lt['n_patterns']}"
    )

    if "pooled_example" in result:
        heading("Pooled estimate (Rubin's rules)")
        pe = result["pooled_example"]
        print(
            f"  {pe['variable']}: estimate={pe['estimate']:.4f}  SE={pe['se']:.5f}  "
            f"95% CI {pe['ci'][0]:.4f}-{pe['ci'][1]:.4f}"
        )
        print(
            f"  FMI={pe['fmi']:.3f}  lambda={pe['lambda']:.3f}  df={pe['df']:.1f}  "
            f"({result['imputations_run']} imputations)"
        )
        heading("Delta-adjusted sensitivity")
        for row in result["delta_sensitivity"]:
            print(
                f"  delta={row['delta_sd']:+.2f} SD   pooled mean={row['pooled_mean']:.4f}  "
                f"(shift {row['shift']:+.4f})"
            )

    show_thresholds([result["threshold"]])

    heading("How to read this")
    print(
        "  A non-rejection of Little's test is not evidence that missingness is ignorable;\n"
        "  at this sample size the test is close to uninformative in both directions. The\n"
        "  delta range answers the question that matters: how wrong would ignorability have\n"
        "  to be to change the conclusion."
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
