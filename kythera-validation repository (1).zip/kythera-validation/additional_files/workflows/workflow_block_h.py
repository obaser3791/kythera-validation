#!/usr/bin/env python
"""Workflow 8. Block H: temporal stability with the minimum detectable trend."""

from __future__ import annotations

import numpy as np
import pandas as pd

from _common import dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_h_temporal as block_h


def main() -> None:
    args = parser(__doc__).parse_args()

    # A fourteen-quarter series with no trend, used to exercise the recomputation path.
    rng = np.random.default_rng(args.seed)
    series = pd.Series(11.8 + rng.normal(0.0, 0.12, size=14), index=range(1, 15))
    result = block_h.run(series)

    heading("Pre-registered window")
    pr = result["pre_registered"]
    print(
        f"  {pr['window']}  quarters={pr['quarters']}  Kendall tau={pr['tau']:.3f}  "
        f"p={pr['p_value']:.3f}  CUSUM breaks={pr['cusum_breaks']}"
    )

    heading("Power")
    pw = result["power"]
    for key, value in pw.items():
        print(f"  {key:28s} {value}")

    heading("Exploratory window")
    ex = result["exploratory"]
    print(
        f"  {ex['window']}  tau={ex['tau']:.3f}  p={ex['p_value']:.3f}  "
        f"break at {ex['break_quarter']}"
    )
    print(f"  status: {ex['status']}")

    heading("Recomputed on the supplied series")
    rc = result["recomputed"]
    print(
        f"  n={rc['n']}  tau={rc['tau']:.3f}  S={rc['s_statistic']}  z={rc['z']:.3f}  "
        f"p={rc['p_value']:.3f}"
    )
    print(
        f"  CUSUM breaks={rc['cusum_breaks_detected']} at {rc['cusum_break_indices']}  "
        f"max+={rc['cusum_max_positive']:.3f}  max-={rc['cusum_max_negative']:.3f}"
    )

    show_thresholds([pr["threshold"], rc["threshold"]])

    heading("How to read this")
    print(
        "  The reported null is consistent with no trend and with trends up to the minimum\n"
        "  detectable tau above. Fourteen quarters cannot distinguish them, and reporting the\n"
        "  null without the detectable effect would overstate the evidence for stability."
    )
    print()
    print("  " + result["panel_composition_caveat"])
    dump(result, args.json)


if __name__ == "__main__":
    main()
