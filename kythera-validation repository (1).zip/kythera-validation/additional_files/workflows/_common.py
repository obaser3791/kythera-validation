"""Shared helpers for the per-block example workflows.

Each workflow script is standalone and prints the quantities that appear in the manuscript
tables for its block. Run any of them with ``PYTHONPATH=src python <script>``.
"""

from __future__ import annotations

import argparse
import json
from typing import Any

DEFAULT_SEED = 20250731


def parser(description: str, *, n: int | None = None, extra: dict[str, Any] | None = None) -> argparse.ArgumentParser:
    """Build a standard argument parser for a workflow script."""
    p = argparse.ArgumentParser(description=description)
    if n is not None:
        p.add_argument("--n", type=int, default=n, help="surrogate cohort size")
    p.add_argument("--seed", type=int, default=DEFAULT_SEED, help="master seed")
    p.add_argument("--json", action="store_true", help="print the full block result as JSON")
    for flag, spec in (extra or {}).items():
        p.add_argument(flag, **spec)
    return p


def cohort(n: int, seed: int = DEFAULT_SEED):
    """Return the patient-level surrogate frame."""
    from kythera_validation.surrogate.generate import SurrogateSpec, generate

    return generate(SurrogateSpec(n=n, seed=seed))["patients"]


def heading(text: str) -> None:
    print()
    print(text)
    print("-" * len(text))


def dump(result: dict, enabled: bool) -> None:
    """Print the whole result as JSON when the caller asked for it."""
    if enabled:
        print(json.dumps(result, indent=2, default=str))


def show_thresholds(checks: list[dict]) -> None:
    """Print pre-registered threshold checks in a fixed layout."""
    heading("Pre-registered checks")
    for c in checks:
        verdict = "met" if c.get("passes") else "NOT MET"
        print(
            f"  {c['key']:22s} observed={c['observed']:.4f}  "
            f"{c['operator']} {c['threshold']:.4f}   {verdict}"
        )
