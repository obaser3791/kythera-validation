#!/usr/bin/env python
"""Workflow 1. Block A: internal consistency, stability and known-group separation."""

from __future__ import annotations

from _common import cohort, dump, heading, parser
from kythera_validation.blocks import block_a_internal_consistency as block_a


def main() -> None:
    args = parser(__doc__, n=250_000).parse_args()
    result = block_a.run(cohort(args.n, args.seed))

    heading("Internal consistency")
    for scale in result["internal_consistency"]:
        lo, hi = scale["alpha_ci"]
        print(
            f"  {scale['construct']:26s} k={scale['items']:2d}  n={scale['n']:,}  "
            f"alpha={scale['alpha']:.3f} ({lo:.3f}-{hi:.3f})"
        )

    heading("Stability")
    tr = result["test_retest"]
    print(f"  test-retest ICC = {tr['icc']:.3f} ({tr['icc_ci'][0]:.3f}-{tr['icc_ci'][1]:.3f})")

    heading("Known-group separation")
    for label, row in result["known_group"].items():
        print(f"  {label:38s} SMD={row['smd']:.3f}  high={row['mean_high']:.2f}  low={row['mean_low']:.2f}")

    heading("Discrimination of the index alone")
    for label, row in result["discrimination"].items():
        print(f"  {label:34s} c={row['c_statistic']:.3f} ({row['c_ci'][0]:.3f}-{row['c_ci'][1]:.3f})")

    heading("Verdict")
    print(f"  all Block A thresholds met: {result['all_thresholds_met']}")
    print(
        "  Read alpha beside the item count: a 31-item composite clears 0.80 on modest\n"
        "  intercorrelation, so alpha alone does not establish unidimensionality. That is\n"
        "  Block C's question, and the known-group and discrimination rows above are the\n"
        "  evidence that the index separates groups it should separate."
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
