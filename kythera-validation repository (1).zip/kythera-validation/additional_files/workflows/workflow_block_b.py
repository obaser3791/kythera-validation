#!/usr/bin/env python
"""Workflow 2. Block B: agreement with NHANES, MEPS and ACS benchmarks."""

from __future__ import annotations

from _common import dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_b_external_consistency as block_b


def main() -> None:
    args = parser(__doc__).parse_args()
    result = block_b.run()

    heading("Measure-by-measure agreement")
    for row in result["measures"]:
        print(
            f"  {row['measure'][:42]:42s} kythera={row['kythera']:>9.2f}  "
            f"reference={row['reference']:>9.2f}  APE={row['absolute_percentage_error']:.3f}"
        )

    heading("Summary")
    print(f"  worst measure MAPE (stratified)      {result['worst_measure_mape']:.4f}")
    print(f"  worst marginal relative difference   {result['worst_marginal_relative_difference']:.4f}")
    print(f"  pooled marginal MAPE                 {result['pooled_marginal_mape']:.4f}")
    lo, hi = result["lins_ccc_ci"]
    print(f"  Lin's concordance correlation        {result['lins_ccc']:.4f} ({lo:.4f}-{hi:.4f})")

    show_thresholds(result["thresholds"])

    heading("How to read a difference")
    print(
        "  A departure from a survey estimate is not automatically an error in the claims.\n"
        "  NHANES ascertains undiagnosed diabetes by laboratory assay and such patients\n"
        "  generate no claim, so the claims estimate is expected to run below the survey\n"
        "  estimate; the direction is stated in advance in config/conditions.yaml.\n"
        "  This block runs from published marginals alone and needs no record-level data."
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
