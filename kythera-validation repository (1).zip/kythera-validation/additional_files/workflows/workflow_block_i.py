#!/usr/bin/env python
"""Workflow 9. Block I: predictive utility across three validation schemes."""

from __future__ import annotations

from _common import cohort, dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_i_predictive as block_i


def main() -> None:
    args = parser(__doc__, n=250_000).parse_args()
    result = block_i.run(cohort(args.n, args.seed), seed=args.seed)

    heading("Leakage controls in force")
    for c in result["leakage_controls"]:
        print(f"  - {c}")

    heading("Hyperparameter grid")
    for model, grid in result["hyperparameter_grid"].items():
        print(f"  {model}: {grid}")

    heading("Recomputed performance")
    for outcome, payload in result.get("recomputed", {}).items():
        print(f"  {outcome}")
        for scheme in ("random_split", "temporal_holdout"):
            row = payload[scheme]
            print(
                f"    {row['scheme']:22s} n={row['n']:>7,} events={row['events']:>6,}  "
                f"AUROC={row['auroc']:.3f} ({row['auroc_ci'][0]:.3f}-{row['auroc_ci'][1]:.3f})  "
                f"Brier={row['brier']:.4f}  slope={row['calibration_slope']:.2f}  "
                f"intercept={row['calibration_intercept']:+.2f}"
            )
        loro = payload["leave_one_region_out"]
        print(
            f"    {loro['scheme']:22s} AUROC {loro['auroc_range'][0]:.3f}-{loro['auroc_range'][1]:.3f}  "
            f"slope {loro['calibration_slope_range'][0]:.2f}-{loro['calibration_slope_range'][1]:.2f}  "
            f"Brier {loro['brier_range'][0]:.4f}-{loro['brier_range'][1]:.4f}"
        )
        for fold in loro["folds"]:
            print(f"      held out {fold['held_out_region']:10s} AUROC={fold['auroc']:.3f}")

    show_thresholds(result["thresholds"])

    heading("How to read this")
    print(
        "  The pre-registered thresholds apply to the random split. The temporal and\n"
        "  geographic schemes are diagnostics of transportability: a fold below the threshold\n"
        "  says the model does not transport to that period or region, which is a finding\n"
        "  about generalisation rather than a failed criterion."
    )
    print()
    print("  " + result["discrimination_is_not_calibration"])
    dump(result, args.json)


if __name__ == "__main__":
    main()
