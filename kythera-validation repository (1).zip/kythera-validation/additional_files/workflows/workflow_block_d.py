#!/usr/bin/env python
"""Workflow 4. Block D: representativeness against external margins, raked and trimmed."""

from __future__ import annotations

from _common import cohort, dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_d_representativeness as block_d


def main() -> None:
    args = parser(__doc__, n=250_000).parse_args()
    result = block_d.run(cohort(args.n, args.seed))

    heading("Published")
    print(
        f"  max |SMD| = {result['published_max_abs_smd']:.3f} "
        f"({result['published_max_abs_smd_variable']}), "
        f"after weighting {result['published_max_abs_smd_after_weighting']:.3f}, "
        f"{result['strata_evaluated']} strata"
    )

    heading("Recomputed")
    print(f"  unweighted        max |SMD| = {result['max_abs_smd_unweighted']:.3f}")
    print(f"  raked             max |SMD| = {result['max_abs_smd_weighted']:.3f}")
    print(f"  raked + trimmed   max |SMD| = {result['max_abs_smd_weighted_trimmed']:.3f}")
    worst = result["worst_unweighted_stratum"]
    print(f"  worst unweighted stratum: {worst['variable']} = {worst['level']}")

    heading("Weight distribution (normalised)")
    ws = result["weight_summary"]
    print(
        f"  min={ws['min']:.3f}  median={ws['median']:.3f}  max={ws['max']:.3f}  "
        f"design effect={ws['design_effect']:.3f}  effective n={ws['effective_n']:,.0f}"
    )

    heading("Largest imbalances after trimming")
    rows = sorted(result["weighted_trimmed"], key=lambda r: -r["abs_smd"])[:8]
    for row in rows:
        print(f"  {row['variable']:22s} {str(row['level'])[:18]:18s} |SMD|={row['abs_smd']:.3f}")

    show_thresholds([result["threshold"], result["recomputed_threshold"]])

    heading("How to read this")
    print(
        "  Report the trimmed figure. Untrimmed raking reproduces the target margins exactly\n"
        "  by attaching large weights to a small number of patients, which is arithmetically\n"
        "  correct and substantively indefensible; the design effect above is the price.\n"
        f"  {result['residual_selection']}"
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
