#!/usr/bin/env python
"""Workflow 7. Block G: intercoder agreement read against category prevalence."""

from __future__ import annotations

import numpy as np

from _common import dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_g_intercoder as block_g


def main() -> None:
    args = parser(__doc__).parse_args()

    # Two illustrative coder-by-coder tables, recomputed end to end so the kappa in the
    # table below is produced by the same estimator as the reported values.
    coder_tables = {
        "diabetes": np.array([[812.0, 24.0], [19.0, 1345.0]]),
        "depression": np.array([[188.0, 61.0], [54.0, 1897.0]]),
    }
    result = block_g.run(coder_tables=coder_tables)

    heading("Overall")
    o = result["overall"]
    print(
        f"  kappa={o['kappa']:.3f} ({o['kappa_ci'][0]:.3f}-{o['kappa_ci'][1]:.3f})  "
        f"PPV={o['ppv']:.3f}  sensitivity={o['sensitivity']:.3f}  specificity={o['specificity']:.3f}"
    )

    heading("By category")
    for row in result["categories"]:
        flag = "" if row["meets_threshold"] else "   <- below threshold"
        print(
            f"  {row['condition'][:26]:26s} kappa={row['kappa']:.3f}  PPV={row['ppv']:.3f}  "
            f"sensitivity={row['sensitivity']:.3f}  {row['agreement_strength']}{flag}"
        )
    print(f"  kappa range: {result['kappa_range'][0]:.3f}-{result['kappa_range'][1]:.3f}")
    print(f"  below threshold: {result['categories_below_threshold'] or 'none'}")

    heading("Recomputed from coder tables")
    for row in result["recomputed"]:
        print(
            f"  {row['condition']:12s} kappa={row['kappa']:.3f} "
            f"({row['kappa_ci'][0]:.3f}-{row['kappa_ci'][1]:.3f})  "
            f"prevalence={row['prevalence']:.3f}  "
            f"observed agreement={row['observed_agreement']:.3f}  "
            f"p_pos={row['positive_specific_agreement']:.3f}  "
            f"p_neg={row['negative_specific_agreement']:.3f}"
        )

    show_thresholds([result["overall"]["threshold"]])

    heading("How to read this")
    print(
        "  Read kappa with the category prevalence. At constant observed agreement of 0.90,\n"
        "  kappa falls from about 0.80 to about 0.44 as prevalence moves from balanced to\n"
        "  10 per cent. A low kappa on a rare category is usually the base rate speaking\n"
        "  rather than the coders, which is why the positive and negative specific-agreement\n"
        "  proportions are reported beside it."
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
