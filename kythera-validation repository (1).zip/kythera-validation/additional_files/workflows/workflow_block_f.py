#!/usr/bin/env python
"""Workflow 6. Block F: linkage accuracy, the operating point and the trade-off curve."""

from __future__ import annotations

import pandas as pd

from _common import dump, heading, parser
from kythera_validation.blocks import block_f_linkage as block_f
from kythera_validation.linkage import fellegi_sunter as fs
from kythera_validation.reporting.tables import to_markdown


def main() -> None:
    args = parser(
        __doc__, extra={"--n-pairs": {"type": int, "default": 1_000_000, "help": "candidate pairs"}}
    ).parse_args()
    result = block_f.run(simulate=True, n_pairs=args.n_pairs, seed=args.seed)

    heading("Weight schedule")
    print(to_markdown(pd.DataFrame(result["weight_schedule"])))

    heading("Blocking passes")
    for p in result["blocking_passes"]:
        print(f"  pass {p['pass']}: {p['key']}")
        print(f"          {p['purpose']}")

    heading("Operating point")
    op = result["operating_point"]
    print(f"  upper T_mu = {op['upper']:.2f}   lower T_lambda = {op['lower']:.2f}")

    heading("Adjudicated accuracy")
    acc = result["adjudication"]["accuracy"]
    counts = acc["counts"]
    print(f"  2x2 counts: tp={counts['tp']:,} fp={counts['fp']:,} fn={counts['fn']:,} tn={counts['tn']:,}")
    for key in ("sensitivity", "specificity", "ppv", "npv"):
        est, lo, hi = acc[key]
        print(f"  {key:18s} {est:.4f} ({lo:.4f}-{hi:.4f})")
    fmr_lo, fmr_hi = acc["false_match_rate_ci"]
    print(f"  {'false_match_rate':18s} {acc['false_match_rate']:.4f} ({fmr_lo:.4f}-{fmr_hi:.4f})")
    mr = result["match_rate"]
    print(f"  match rate         {mr['rate']:.4f} ({mr['ci'][0]:.4f}-{mr['ci'][1]:.4f})")

    heading("Weakest stratum")
    ws = result["lowest_sensitivity_stratum"]
    print(f"  {ws['variable']} = {ws['level']}  n={ws['n']:,}  sensitivity={ws['sensitivity']:.3f}")
    print(f"  widest sensitivity gap: {result['adjudication']['widest_sensitivity_gap']}")
    print(f"  difficult-scenario floor: {result['adjudication']['difficult_scenario_floor']}")

    heading("Threshold derivation from the simulated weight distribution")
    sim = result["simulation"]
    print(f"  derived upper={sim['derived_upper']:.2f}  derived lower={sim['derived_lower']:.2f}")
    for label in ("at_pre_registered_operating_point", "at_derived_operating_point"):
        oc = sim[label]
        print(
            f"  {label.replace('_', ' '):36s} FMR={oc['false_match_rate']:.4f}  "
            f"sensitivity={oc['sensitivity']:.3f}  review share={oc['clerical_review_share']:.3f}"
        )

    heading("Trade-off curve")
    curve = pd.DataFrame(sim["threshold_curve"])
    print(to_markdown(curve.iloc[:: max(1, len(curve) // 12)]))

    heading("How to read this")
    print(
        "  Inspect the curve before adopting this operating point in your own study. Moving\n"
        "  the upper threshold a few percent moves the false-match rate by an order of\n"
        "  magnitude, so the operating point is a study-design parameter and not a property\n"
        "  of the data. For any analysis restricted to a subgroup, the weakest stratum above\n"
        "  matters more than the average."
    )
    print()
    print("  " + result["tokenization_trade_off"])
    dump(result, args.json)


if __name__ == "__main__":
    main()
