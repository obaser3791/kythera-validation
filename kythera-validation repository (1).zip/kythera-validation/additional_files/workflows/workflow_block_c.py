#!/usr/bin/env python
"""Workflow 3. Block C: two-factor measurement model against a one-factor alternative."""

from __future__ import annotations

from _common import cohort, dump, heading, parser, show_thresholds
from kythera_validation.blocks import block_c_construct_validity as block_c


def main() -> None:
    args = parser(__doc__, n=200_000).parse_args()
    result = block_c.run(cohort(args.n, args.seed), seed=args.seed)

    heading("Standardized loadings")
    for name, value in result["loadings"].items():
        print(f"  {name:28s} {value:.3f}")

    heading("Fit")
    two, one = result["two_factor"], result["one_factor"]
    print(
        f"  two-factor   chi2={two['chisq']:.1f} df={two['df']}  CFI={two['cfi']:.3f}  "
        f"TLI={two['tli']:.3f}  RMSEA={two['rmsea']:.3f}  SRMR={two['srmr']:.3f}"
    )
    print(
        f"  one-factor   chi2={one['chisq']:.1f} df={one['df']}  CFI={one['cfi']:.3f}  "
        f"RMSEA={one['rmsea']:.3f}  SRMR={one['srmr']:.3f}"
    )
    print(f"  delta chi2={result['delta_chisq']:.1f} on {result['delta_df']} df")

    heading("Discriminant validity")
    print(f"  factor correlation phi = {result['factor_correlation']:.3f}  (phi^2 = {result['factor_correlation'] ** 2:.3f})")
    for key, value in result["average_variance_extracted"].items():
        print(f"  AVE   {key:22s} {value:.3f}")
    for key, value in result["composite_reliability_omega"].items():
        print(f"  omega {key:22s} {value:.3f}")
    print(f"  Fornell-Larcker satisfied: {result['fornell_larcker_satisfied']}")

    show_thresholds(result["thresholds"])

    heading("How to read this")
    print(
        "  The comparison against the one-factor alternative is the informative part: a\n"
        "  two-factor model with excellent indices means little if one factor fits as well.\n"
        "  The indicators are area-level and therefore ecological. Coherence of the\n"
        "  indicators is not evidence that any individual patient is poor."
    )
    dump(result, args.json)


if __name__ == "__main__":
    main()
