# Additional file 4. Example workflows

Baser O. Validation of the Kythera Labs all-payer real-world data asset: a provenance-anchored
nine-block framework for tokenized evidence generation. *BMC Medical Research Methodology*.

This file gives runnable workflows for each block, from installation through to the quantities
that appear in the manuscript tables. Every snippet below is taken from a script in
`additional_files/workflows/`, and each script runs on its own:

```bash
cd additional_files/workflows
PYTHONPATH=../../src python workflow_block_a.py --n 250000
```

Every script accepts `--seed` and `--json`; the record-level ones accept `--n`. All output shown
in this file was produced by these scripts.

Before anything else, read what the framework asserts, then check the code against the paper:

```bash
kythera-validate info
kythera-validate thresholds
kythera-validate verify --n 20000
```

`verify` exits non-zero if any published quantity that is recoverable from the printed values
disagrees with the code. Run it first — if it fails, nothing below is worth interpreting.

---

## Workflow 0. Which workflows apply to you

| You have | Blocks you can reproduce exactly | Blocks that run in structure only |
| --- | --- | --- |
| Nothing but this repository | B, C, D, F, G, H, and every equation | A, E, I against the surrogate cohort |
| The licensed asset | All nine | — |

The distinction is not a formality. The surrogate cohort carries the schema, missingness structure
and marginal distributions of the analytic file, and nothing else. Running Block I against it
demonstrates that the code is correct; it does not reproduce the published c-statistic, and no
number it produces should be cited as a study result.

---

## Workflow 1. Block A — internal consistency and stability

```bash
python workflow_block_a.py --n 250000
```

```python
from kythera_validation.blocks import block_a_internal_consistency as block_a
from kythera_validation.surrogate.generate import SurrogateSpec, generate

cohort = generate(SurrogateSpec(n=250_000, seed=20250731))["patients"]
result = block_a.run(cohort)

for scale in result["internal_consistency"]:
    lo, hi = scale["alpha_ci"]
    print(f"{scale['construct']:26s} k={scale['items']:2d}  alpha={scale['alpha']:.3f} ({lo:.3f}-{hi:.3f})")

print("test-retest ICC:", round(result["test_retest"]["icc"], 3))
print("all thresholds met:", result["all_thresholds_met"])
```

```
Elixhauser comorbidity     k=31  alpha=0.876 (0.875-0.876)
Charlson comorbidity       k=17  alpha=0.842 (0.841-0.843)
test-retest ICC = 0.809 (0.808-0.810)
Elixhauser vs heart failure          SMD=1.258     c for 90-day mortality = 0.811
Charlson vs chronic kidney disease   SMD=1.039     c for 90-day mortality = 0.779
```

The script also prints the known-group separation and the c-statistic of each index alone, and
those rows are the point. A 31-item composite clears an alpha of 0.80 on modest intercorrelation,
so alpha on its own does not establish that the composite is unidimensional — that is Block C's
question — nor that it separates groups it ought to separate.

---

## Workflow 2. Block B — agreement with survey benchmarks

```bash
python workflow_block_b.py
```

```python
from kythera_validation.blocks import block_b_external_consistency as block_b

result = block_b.run()
print("worst measure MAPE:", round(result["worst_measure_mape"], 4))
print("Lin's CCC:", round(result["lins_ccc"], 4), result["lins_ccc_ci"])
for row in result["measures"]:
    print(f"{row['measure'][:38]:38s} {row['kythera']:>9.2f}  vs {row['reference']:>9.2f}")
```

```
worst measure MAPE: 0.047      (threshold <= 0.05, met)
Lin's CCC:          0.9994     (0.9985-0.9997)
Diabetes prevalence                        11.80  vs     11.50
Hypertension prevalence                    47.90  vs     49.50
```

This block runs from published marginals alone and reproduces the manuscript values without any
record-level data. When a claims estimate departs from a survey estimate, read the
non-comparability statement for that condition before treating the difference as an error in the
claims: NHANES ascertains undiagnosed diabetes by laboratory assay, and a patient with undiagnosed
disease generates no claim.

---

## Workflow 3. Block C — construct validity

```bash
python workflow_block_c.py --n 200000
```

```python
from kythera_validation.blocks import block_c_construct_validity as block_c
from kythera_validation.surrogate.generate import SurrogateSpec, generate

cohort = generate(SurrogateSpec(n=200_000, seed=20250731))["patients"]
result = block_c.run(cohort)

two, one = result["two_factor"], result["one_factor"]
print(f"two-factor  CFI={two['cfi']:.3f}  TLI={two['tli']:.3f}  RMSEA={two['rmsea']:.3f}  SRMR={two['srmr']:.3f}")
print(f"one-factor  CFI={one['cfi']:.3f}  RMSEA={one['rmsea']:.3f}")
print("phi:", round(result["factor_correlation"], 3))
print("AVE:", result["average_variance_extracted"])
print("Fornell-Larcker satisfied:", result["fornell_larcker_satisfied"])
```

```
two-factor  chi2=  140.5  df=53  CFI=0.999  TLI=0.999  RMSEA=0.009  SRMR=0.005
one-factor  chi2=25095.1  df=54  CFI=0.798  RMSEA=0.152  SRMR=0.100
delta chi2 = 24954.6 on 1 df
phi = 0.579   (phi^2 = 0.335)
AVE  economic_adversity 0.583   care_access 0.534
omega economic_adversity 0.906  care_access 0.850
Fornell-Larcker satisfied: True
```

The comparison against the one-factor alternative is the informative part. A two-factor model with
excellent fit indices means little if a one-factor model fits equally well; here it does not, by a
wide margin. The indicators remain ecological: coherence of tract-level measures is not evidence
that any individual patient is poor.

---

## Workflow 4. Block D — representativeness and raking

```bash
python workflow_block_d.py --n 250000
```

```python
from kythera_validation.blocks import block_d_representativeness as block_d
from kythera_validation.surrogate.generate import SurrogateSpec, generate

cohort = generate(SurrogateSpec(n=250_000, seed=20250731))["patients"]
result = block_d.run(cohort)

print("unweighted      max |SMD|:", round(result["max_abs_smd_unweighted"], 3))
print("raked           max |SMD|:", round(result["max_abs_smd_weighted"], 3))
print("raked + trimmed max |SMD|:", round(result["max_abs_smd_weighted_trimmed"], 3))
print("worst stratum:", result["worst_unweighted_stratum"])
print("weights:", result["weight_summary"])
```

```
unweighted      max |SMD| = 0.314
raked           max |SMD| = 0.000
raked + trimmed max |SMD| = 0.060
worst unweighted stratum: payer = Medicare
weights (normalised): min 0.108  median 0.894  max 8.054  design effect 1.624
effective n = 153,896
```

Report the trimmed figure. Untrimmed raking reproduces the target margins exactly by attaching
large weights to a small number of patients, which is arithmetically correct and substantively
indefensible; the design effect is the price. The script prints the residual-selection statement
in full, and it is the part that matters: the uninsured are not under-represented but absent,
because a person with no coverage generates no adjudicated claim, and no weight can create that
stratum.

---

## Workflow 5. Block E — missingness

```bash
python workflow_block_e.py --n 100000 --m 20
```

```python
from kythera_validation.blocks import block_e_missingness as block_e
from kythera_validation.surrogate.generate import SurrogateSpec, generate

cohort = generate(SurrogateSpec(n=100_000, seed=20250731))["patients"]
result = block_e.run(cohort, m=20)

lt = result["littles_test"]
print(f"Little's test: chi2={lt['chisq']:.2f} df={lt['df']} p={lt['p_value']:.4f} patterns={lt['n_patterns']}")
pe = result["pooled_example"]
print(f"pooled {pe['variable']}: {pe['estimate']:.4f}  FMI={pe['fmi']:.3f}  df={pe['df']:.1f}")
for row in result["delta_sensitivity"]:
    print(f"  delta={row['delta_sd']:+.2f} SD -> {row['pooled_mean']:.4f}")
```

```
Little's test: chi2=75.19 df=72 p=0.3756 patterns=8
pooled income_band: 2.9994  SE=0.00469  95% CI 2.9902-3.0086  FMI=0.090  df=450.2
  delta=-0.50 SD -> 2.2931
  delta=+0.00 SD -> 2.9994
  delta=+0.50 SD -> 3.7057
```

Do not read a non-rejection of Little's test as evidence that missingness is ignorable; at this
sample size the test is close to uninformative in both directions. The delta-adjusted range
answers the question that matters: how wrong would ignorability have to be to change the
conclusion.

---

## Workflow 6. Block F — linkage accuracy and the operating point

```bash
python workflow_block_f.py --n-pairs 1000000
```

```python
from kythera_validation.blocks import block_f_linkage as block_f

result = block_f.run(simulate=True, n_pairs=1_000_000, seed=20250731)

acc = result["adjudication"]["accuracy"]
print("counts:", acc["counts"])
for key in ("sensitivity", "specificity", "ppv", "npv"):
    est, lo, hi = acc[key]
    print(f"{key:12s} {est:.4f} ({lo:.4f}-{hi:.4f})")
print("false-match rate:", round(acc["false_match_rate"], 4), acc["false_match_rate_ci"])
print("weakest stratum:", result["lowest_sensitivity_stratum"])

sim = result["simulation"]
print("derived operating point:", round(sim["derived_upper"], 2), round(sim["derived_lower"], 2))
print("at the pre-registered point:", sim["at_pre_registered_operating_point"])
```

```
counts: tp=7353 fp=21 fn=251 tn=4257
sensitivity  0.9670 (0.9627-0.9708)
specificity  0.9951 (0.9925-0.9968)
ppv          0.9972 (0.9957-0.9981)
npv          0.9443 (0.9372-0.9506)
false-match rate: 0.0028 (0.0019-0.0043)
match rate:       0.9620 (0.9590-0.9650)
weakest stratum:  Race/ethnicity (imputed) = Other/Unknown, n=536, sensitivity=0.944
derived operating point: upper=16.40  lower=13.62
```

The script prints the full trade-off curve. Inspect it before adopting this operating point in
your own study: raising the upper threshold from 13.62 to about 15.8 moves the false-match rate
from about 0.21 to 0.035 and then to about 0.002 by 17.9, while sensitivity falls from 0.98 to
about 0.82. The
operating point is a study-design parameter, not a property of the data. For any analysis
restricted to a subgroup, the weakest stratum matters more than the average.

---

## Workflow 7. Block G — intercoder agreement

```bash
python workflow_block_g.py
```

```python
import numpy as np
from kythera_validation.blocks import block_g_intercoder as block_g

tables = {
    "diabetes":   np.array([[812.0, 24.0], [19.0, 1345.0]]),
    "depression": np.array([[188.0, 61.0], [54.0, 1897.0]]),
}
result = block_g.run(coder_tables=tables)

for row in result["categories"]:
    print(f"{row['condition']:24s} kappa={row['kappa']:.3f}  PPV={row['ppv']:.3f}  {row['agreement_strength']}")
print("kappa range:", result["kappa_range"])
print("below threshold:", result["categories_below_threshold"] or "none")

for row in result["recomputed"]:
    print(f"{row['condition']:12s} kappa={row['kappa']:.3f}  prevalence={row['prevalence']:.3f}  "
          f"p_pos={row['positive_specific_agreement']:.3f}  p_neg={row['negative_specific_agreement']:.3f}")
```

```
Hypertension           kappa=0.920  PPV=0.960  almost perfect
Mood disorders         kappa=0.710  PPV=0.820  substantial
kappa range: 0.710-0.920      below threshold: none

diabetes     kappa=0.958  prevalence=0.379  p_pos=0.974  p_neg=0.984
depression   kappa=0.736  prevalence=0.112  p_pos=0.766  p_neg=0.971
```

Read kappa with the category prevalence. The two recomputed tables make the point directly: both
have observed agreement above 0.94, but the rarer category's kappa is a quarter lower, and its
positive specific agreement — which is prevalence-independent in a way kappa is not — shows where
the disagreement actually sits. A low kappa on a rare category is usually the base rate speaking,
not the coders.

---

## Workflow 8. Block H — temporal stability

```bash
python workflow_block_h.py
```

```python
from kythera_validation.blocks import block_h_temporal as block_h

result = block_h.run()
pr = result["pre_registered"]
print(f"{pr['window']}: tau={pr['tau']:.3f}  p={pr['p_value']:.3f}  breaks={pr['cusum_breaks']}")
print("minimum detectable tau:", round(result["power"]["minimum_detectable_tau"], 3))
print("exploratory:", result["exploratory"])
```

```
2022Q1-2025Q2: tau=0.080  p=0.320  CUSUM breaks=0   (14 quarters)
minimum detectable tau: 0.562
exploratory 2016Q1-2025Q2: tau=0.140  p=0.090  break at 2020Q2  (panel composition not stable)
```

The observed tau of 0.08 with p = 0.32 is consistent with no trend and with trends up to
\(|\tau| \approx 0.56\). Fourteen quarters cannot distinguish them, and reporting the null without
the minimum detectable effect would overstate the evidence for stability. The longer series is
labelled exploratory because over that span a change in the series cannot be separated from a
change in which contributors were reporting.

---

## Workflow 9. Block I — predictive utility

```bash
python workflow_block_i.py --n 250000
```

```python
from kythera_validation.blocks import block_i_predictive as block_i
from kythera_validation.surrogate.generate import SurrogateSpec, generate

cohort = generate(SurrogateSpec(n=250_000, seed=20250731))["patients"]
result = block_i.run(cohort)

for outcome, payload in result["recomputed"].items():
    for scheme in ("random_split", "temporal_holdout"):
        row = payload[scheme]
        print(f"{outcome:16s} {row['scheme']:22s} AUROC={row['auroc']:.3f}  "
              f"Brier={row['brier']:.4f}  slope={row['calibration_slope']:.2f}")
    lo, hi = payload["leave_one_region_out"]["auroc_range"]
    print(f"{outcome:16s} across regions         AUROC {lo:.3f}-{hi:.3f}")
```

```
mortality_90d    random split     AUROC=0.866  Brier=0.0380  slope=1.00
mortality_90d    temporal holdout AUROC=0.867  Brier=0.0374  slope=1.01
mortality_90d    across regions   AUROC 0.854-0.867
readmission_30d  random split     AUROC=0.802  Brier=0.0578  slope=0.98
readmission_30d  temporal holdout AUROC=0.800  Brier=0.0570  slope=0.97
readmission_30d  across regions   AUROC 0.800-0.809
```

The pre-registered thresholds apply to the random split. Fold-level values from the temporal and
geographic schemes are diagnostics of transportability. Read the calibration slope beside the
c-statistic: doubling a set of well-calibrated probabilities leaves the c-statistic untouched and
makes the model useless for any decision that depends on the probability itself.

---

## Workflow 10. The whole pipeline

```bash
kythera-validate run --n 250000 --simulate-linkage --n-pairs 1000000 --out outputs/full
```

Writes:

```
outputs/full/tables/*.csv     one file per manuscript table, plus tables.md
outputs/full/figures/*.png    the manuscript figures
outputs/full/results.json     every block result, including every threshold check
```

The run ends with a summary of every pre-registered check, each labelled with its position in the
results — outcome, validation scheme and fold — so a flagged value can be located rather than
appearing as an anonymous number. A non-zero exit means at least one check on the primary
estimates was not met.

---

## Workflow 11. Adding a block

The framework is meant to be extended. A new block needs four things:

1. A threshold entry in `config/thresholds.yaml` carrying `block`, `metric`, `operator`, `value`,
   `source`, `alternatives_considered` and `rationale`. A cutoff with no stated source and no
   rejected alternative is an assertion, not a criterion.
2. A module in `src/kythera_validation/blocks/` exposing `run(...) -> dict` and returning its
   checks through `config.check(key, observed)` so they appear in the summary.
3. A test in `tests/test_blocks.py` asserting the structure the reporting layer needs, and a test
   in `tests/test_equations.py` for any new estimator, written against a closed-form value or an
   analytic property rather than against current output.
4. An entry in the block table in `README.md`.

```bash
PYTHONPATH=src pytest -q
kythera-validate verify --n 20000
```

Both must pass before the block is reported.
