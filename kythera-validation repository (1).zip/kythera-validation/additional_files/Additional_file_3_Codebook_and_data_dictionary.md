# Additional file 3. Codebook and data dictionary

Baser O. Validation of the Kythera Labs all-payer real-world data asset: a provenance-anchored
nine-block framework for tokenized evidence generation. *BMC Medical Research Methodology*.

This file documents every table and field used in the study: data type, permissible values, the
transaction-standard loop or segment the element originates in, key cardinality, join path,
derivation logic, look-back window and observed missingness. Provenance is given at the element
level because the central argument of the manuscript is that a validation claim is only as strong
as the account of where each element came from.

Transaction standards referenced: **ANSI X12 837** (professional 837P, institutional 837I, dental
837D) for medical claims; **ANSI X12 835** for remittance; **NCPDP Telecommunication Standard
D.0** for pharmacy claims; **ANSI X12 834** for enrolment.

Missingness rates are those observed in the analytic cohort of 38,947,221 patients. Field names
match the patient-level names used in the analysis code, so the surrogate cohort in
`src/kythera_validation/surrogate/` implements a subset of this dictionary under the same names.

---

## 1. Table inventory and join paths

| Table | Grain | Primary key | Rows (analytic cohort) |
| --- | --- | --- | --- |
| `patient` | One row per patient | `patient_token` | 38,947,221 |
| `enrollment` | One row per patient per coverage span | `patient_token`, `payer_id`, `span_start` | 71,204,880 |
| `medical_claim` | One row per claim | `claim_id` | 2,914,633,072 |
| `medical_claim_line` | One row per service line | `claim_id`, `line_number` | 8,706,201,455 |
| `pharmacy_claim` | One row per dispensing event | `rx_claim_id` | 1,338,914,203 |
| `provider` | One row per NPI | `npi` | 6,142,880 |
| `geography` | One row per census tract | `tract_fips` | 84,414 |

Join paths:

```
patient 1---n enrollment          on patient_token
patient 1---n medical_claim       on patient_token
medical_claim 1---n medical_claim_line
                                  on claim_id
patient 1---n pharmacy_claim      on patient_token
medical_claim n---1 provider      on billing_npi -> npi
patient n---1 geography           on tract_fips
```

Referential integrity is enforced and measured at intake: 98.0% is the pre-registered minimum
and 99.6% was observed. Claims failing referential integrity are quarantined rather than
silently dropped, and the quarantine share is reported (0.04% against a 0.5% maximum).

---

## 2. `patient`

| Field | Type | Permissible values | Provenance | Derivation | Missing |
| --- | --- | --- | --- | --- | --- |
| `patient_token` | char(64) | Hexadecimal digest | Derived from 834 and 837 identity fields before de-identification | Deterministic tokenization of name, date of birth, sex and ZIP by the tokenization vendor; the study never receives the inputs | 0% |
| `age_band` | categorical | `0-17`, `18-34`, `35-49`, `50-64`, `65-74`, `75+` | 837 Loop 2010BA DMG-02 (date of birth) | Age at first observed claim in the study window, banded | 0.3% |
| `sex` | categorical | `F`, `M`, `U` | 837 Loop 2010BA DMG-03 | Modal value across coverage spans; `U` where spans disagree | 0.2% |
| `region` | categorical | `Northeast`, `Midwest`, `South`, `West` | 837 Loop 2010BA N4-02 (state) | Census region of the modal state of residence | 0.4% |
| `tract_fips` | char(11) | Valid 2020 census tract | 837 Loop 2010BA N4-03 (ZIP) | ZIP-to-tract allocation by HUD crosswalk, residential ratio | 2.1% |
| `contributor_cohort` | categorical | `P1`, `P2`, `P3` | Contributor submission manifest | Assigned by contributing clearinghouse group | 0% |
| `observable_months` | integer | 1–126 | Derived | Months between first and last observed claim or coverage span | 0% |
| `continuous_2y` | boolean | `0`, `1` | Derived | 1 where the patient has no coverage gap exceeding 45 days across any 24-month window | 0% |
| `index_date` | date | 2015-01-01 to 2025-07-31 | Derived | First qualifying encounter for the outcome analyses | 0% |
| `index_quarter` | integer | 1–42 | Derived | Calendar quarter of `index_date`, indexed from 2015 Q1 | 0% |
| `period` | categorical | `2015-2018`, `2019-2021`, `2022-2025` | Derived | Coarsened `index_quarter`, used for the temporal holdout | 0% |

**Note on `age_band`.** Age is banded rather than reported in years because the HIPAA Expert
Determination governing the asset restricts the release of exact dates of birth. Banding is a
disclosure control, not a modelling choice, and it costs precision in the age-adjustment of every
Block D comparison. This cost is not recoverable.

---

## 3. `enrollment`

| Field | Type | Permissible values | Provenance | Derivation | Missing |
| --- | --- | --- | --- | --- | --- |
| `patient_token` | char(64) | Foreign key to `patient` | — | — | 0% |
| `payer_id` | char(12) | Assigned payer identifier | 834 Loop 2000, 837 Loop 2010BB NM1-09 | Normalised across contributors | 0% |
| `payer_type` | categorical | `Commercial`, `Medicare Advantage`, `Medicare FFS`, `Medicaid`, `Exchange`, `Other` | 837 SBR-09 | Mapped from the claim filing indicator | 1.7% |
| `span_start`, `span_end` | date | Within study window | 834 DTP-348, DTP-349 | Coverage spans merged where the gap is 45 days or fewer | 0% |
| `pharmacy_benefit` | boolean | `0`, `1` | 834 HD-03 | 1 where a pharmacy benefit is recorded | 3.9% |

**Cardinality caution.** A patient may hold overlapping coverage from more than one payer.
Overlapping spans are retained rather than collapsed, so any per-patient aggregation over
`enrollment` must deduplicate on `patient_token` or it will double-count. The Block D denominators
use the deduplicated point-in-time count of 246.9 million lives.

---

## 4. `medical_claim` and `medical_claim_line`

| Field | Type | Permissible values | Provenance | Derivation | Missing |
| --- | --- | --- | --- | --- | --- |
| `claim_id` | char(32) | — | 837 Loop 2300 CLM-01 | Contributor claim control number, rehashed | 0% |
| `patient_token` | char(64) | Foreign key | — | — | 0% |
| `claim_type` | categorical | `Professional`, `Institutional`, `Dental` | Transaction set (837P / 837I / 837D) | — | 0% |
| `statement_from`, `statement_to` | date | Within study window | 837 Loop 2300 DTP-434 | — | 0.1% |
| `place_of_service` | char(2) | CMS place-of-service code set | 837 Loop 2300 CLM-05-1 | — | 2.4% |
| `bill_type` | char(3) | UB-04 type of bill | 837I Loop 2300 CLM-05 | Institutional claims only | — |
| `admission_date`, `discharge_date` | date | — | 837I Loop 2300 DTP-435, DTP-096 | Inpatient claims only | — |
| `discharge_status` | char(2) | UB-04 patient discharge status | 837I Loop 2300 CL1-03 | Used to define the readmission denominator and to exclude transfers | 1.1% |
| `diagnosis_codes` | array of char(7) | Valid ICD-10-CM for the date of service | 837 Loop 2300 HI segments (ABK principal, ABF secondary) | Validated against the version of the code set in force on `statement_from` | 0.2% |
| `diagnosis_poa` | array of char(1) | `Y`, `N`, `U`, `W`, `1` | 837I HI qualifier BJ | Present-on-admission indicator; institutional only | 8.3% |
| `procedure_codes` | array of char(7) | Valid ICD-10-PCS or CPT/HCPCS | 837 Loop 2400 SV1-01 / SV2 | — | 0.5% |
| `billing_npi` | char(10) | Valid NPI passing the Luhn check | 837 Loop 2010AA NM1-09 | Resolved against the NPPES registry | 1.4% |
| `allowed_amount` | decimal(12,2) | \(\ge 0\) | 835 remittance, matched to the claim | Sum over lines; null where remittance is absent | 12.6% |
| `paid_amount` | decimal(12,2) | \(\ge 0\) | 835 CLP-04 | Net of reversals | 12.6% |
| `line_number` | integer | 1–999 | 837 Loop 2400 LX-01 | — | 0% |
| `units` | decimal(10,3) | \(> 0\) | 837 Loop 2400 SV1-04 | — | 0.3% |
| `modifiers` | array of char(2) | CPT/HCPCS modifier set | 837 Loop 2400 SV1-01-3 through 01-6 | — | — |

**The 12.6% missingness on paid amounts is the single most consequential gap in the asset** and is
structural, not random: it occurs where a contributor submits claims but not remittance.
Contributor cohort predicts it strongly. Any cost analysis restricted to complete cases is
therefore restricted to a non-random subset of payers, which is why cost is not among the
outcomes validated in this study and why the manuscript states that the asset should not be used
for cost analysis without a contributor-level sensitivity analysis.

---

## 5. `pharmacy_claim`

| Field | Type | Permissible values | Provenance | Derivation | Missing |
| --- | --- | --- | --- | --- | --- |
| `rx_claim_id` | char(32) | — | NCPDP D.0 field 402-D2 | Rehashed prescription reference number | 0% |
| `patient_token` | char(64) | Foreign key | — | — | 0% |
| `fill_date` | date | Within study window | NCPDP 401-D1 (date of service) | — | 0% |
| `ndc` | char(11) | Valid 11-digit NDC | NCPDP 407-D7 (product/service ID) | Normalised to 5-4-2 format; resolved to RxNorm | 0.1% |
| `rxnorm_ingredient` | integer | RxNorm RXCUI | Derived | NDC to RxNorm ingredient via RxNav | 0.9% |
| `therapeutic_class` | categorical | USP category | Derived | Assigned from the RxNorm ingredient | 0.9% |
| `days_supply` | integer | 1–365 | NCPDP 405-D5 | Values above 365 quarantined | 0.4% |
| `quantity_dispensed` | decimal(10,3) | \(> 0\) | NCPDP 442-E7 | — | 0.3% |
| `refill_number` | integer | 0–99 | NCPDP 403-D3 | 0 denotes the original fill | 0.2% |
| `reversal_flag` | boolean | `0`, `1` | NCPDP transaction code `B2` | Reversals are netted against the original fill, not deleted | 0% |
| `prescriber_npi` | char(10) | Valid NPI | NCPDP 411-DB | Resolved against NPPES | 2.8% |

**Reversals.** 1.7% of pharmacy claims are reversals. Netting rather than deleting matters
because a reversal and its original fill can arrive in different submission months; deleting the
reversal alone would leave a fill that never occurred, and deleting both retrospectively would
change a previously reported month. The netting rule is applied at query time and is auditable.

---

## 6. `provider` and `geography`

| Field | Type | Permissible values | Provenance | Missing |
| --- | --- | --- | --- | --- |
| `npi` | char(10) | Valid NPI | NPPES | 0% |
| `entity_type` | categorical | `Individual`, `Organization` | NPPES | 0% |
| `primary_taxonomy` | char(10) | NUCC taxonomy code | NPPES | 1.2% |
| `specialty_group` | categorical | Derived grouping | Derived from taxonomy | 1.2% |
| `tract_fips` | char(11) | Valid 2020 tract | Census | 0% |
| `tract_poverty_quintile` | integer | 1–5 | ACS 5-year, table S1701 | 0.2% |
| `tract_income_quintile` | integer | 1–5 | ACS 5-year, table S1901 | 0.2% |
| `tract_no_hs_quintile` | integer | 1–5 | ACS 5-year, table S1501 | 0.2% |
| `tract_uninsured_quintile` | integer | 1–5 | ACS 5-year, table S2701 | 0.3% |
| `pcp_density_quintile` | integer | 1–5 | Derived from NPPES and Census population | 0.3% |
| `travel_time_quintile` | integer | 1–5 | ACS 5-year, table S0801 | 0.4% |

The area-level quintiles are the indicators of the two-factor measurement model in Block C. They
are ecological: a patient in a high-poverty tract is not necessarily poor, and the model
establishes that the indicators cohere, not that they measure individual circumstance.

---

## 7. Derived clinical variables

### 7.1 Condition flags

All six conditions use the same rule: **one inpatient claim OR two outpatient claims at least 30
days apart, within a 24-month look-back window ending on the index date.** Supporting pharmacy
dispensings are recorded but do not by themselves establish the flag.

| Condition | ICD-10-CM prefixes | Comparator | Published PPV |
| --- | --- | --- | --- |
| Diabetes mellitus | E10, E11, E13 | NHANES | 0.92–0.97 |
| Hypertension | I10, I11, I12, I13, I15 | NHANES | 0.87–0.94 |
| Hyperlipidemia | E780, E781, E782, E784, E785 | MEPS | 0.71 |
| Depression | F32, F33 | NHANES | 0.61–0.87 |
| Atrial fibrillation | I48 | MEPS | 0.70–0.96 |
| COPD | J41, J42, J43, J44 | NHANES | 0.72–0.93 |

Each definition carries an explicit statement of what remains non-comparable after the claims and
survey definitions are aligned, and in which direction the claims estimate is expected to depart.
For diabetes, NHANES ascertains undiagnosed disease by laboratory measurement and such patients
generate no claim, so the claims estimate is expected to run below the survey estimate. For
hyperlipidemia, diagnosis codes alone are insensitive and the addition of lipid-lowering
dispensings raises sensitivity from 0.27 to 0.51, so the claims estimate is expected to exceed
household self-report where treatment is common. These statements are in `config/conditions.yaml`
and are reported with every comparison, because a difference between claims and survey is not
automatically an error in the claims.

### 7.2 Comorbidity composites

| Variable | Type | Definition | Look-back |
| --- | --- | --- | --- |
| `charlson_XX` | 17 binary indicators | Quan (2005) ICD-10 coding algorithm | 24 months |
| `charlson_score` | integer 0–24 | Weighted sum | 24 months |
| `elix_XX` | 31 binary indicators | Elixhauser via AHRQ ICD-10-CM CCSR | 24 months |
| `elix_count` | integer 0–31 | Unweighted count | 24 months |

### 7.3 Utilisation and outcomes

| Variable | Type | Definition | Window |
| --- | --- | --- | --- |
| `ed_visits` | integer | Emergency visits, place of service 23 or revenue codes 045x | 24 months before index |
| `ip_admissions` | integer | Institutional claims with an admission date, transfers collapsed | 24 months before index |
| `mortality_90d` | boolean | Death within 90 days of index, from discharge status 20 and the linked mortality file | 90 days after index |
| `readmission_30d` | boolean | Unplanned all-cause readmission within 30 days of discharge; planned admissions excluded by the CMS planned-readmission algorithm; transfers excluded | 30 days after discharge |

**Ascertainment.** Recorded prevalence depends on how long a patient is observed. A patient
observed for four months cannot accumulate two outpatient codes 30 days apart as reliably as one
observed for three years. The `observable_months` and `continuous_2y` fields exist so that this
dependence can be modelled rather than ignored, and the Block A and Block B analyses are
restricted to patients meeting the continuous-observation requirement.

---

## 8. Intake conformance gates

Thirteen gates are evaluated at intake; eight carry a numeric bound and five are reported for
transparency without a bound. A gate that is described rather than graded is not counted as
passing.

| Gate | Stage | Bound | Observed |
| --- | --- | --- | --- |
| Manifest receipt | Receipt | \(\ge 0.995\) | 0.9994 |
| X12 837 syntax | Conformance | \(\ge 0.995\) | 0.9999 |
| NCPDP D.0 conformance | Conformance | \(\ge 0.995\) | 0.9998 |
| ICD-10-CM validity | Terminology | \(\ge 0.995\) | 0.9997 |
| CPT/HCPCS validity | Terminology | \(\ge 0.995\) | 0.9995 |
| NDC to RxNorm resolution | Terminology | \(\ge 0.995\) | 0.9991 |
| Member key resolution | Referential | \(\ge 0.980\) | 1.0000 |
| Provider NPI resolution | Referential | \(\ge 0.980\) | 0.9860 |
| Records quarantined | Curation | \(\le 0.005\) | 0.0004 |
| Duplicate lines removed | Curation | reported | 0.0083 |
| Reversals netted | Curation | reported | 0.0170 |
| Token availability | Linkage | reported | 0.2170 |
| Weeks flagged for latency | Timeliness | reported | 0.0120 |

Submission latency: median 9 days, interquartile range 7–14 days, against a pre-registered maximum
median of 14 days.

**Every result in this study is conditional on these gates.** A validation statistic computed on
data that failed intake conformance measures the failure, not the asset, which is why the gates
are reported first and why the conditionality is stated explicitly in the results rather than
left to be inferred.

---

## 9. Cohort construction

| Step | Criterion | n |
| --- | --- | --- |
| Source universe | Distinct patients in any contributed medical or pharmacy claim | 315,817,351 |
| Token-linked subset | A stable token is available | 68,412,993 |
| Two or more observations | At least two claims at least 30 days apart | 41,802,554 |
| Final analytic cohort | Non-missing age band, sex and region; token stable across the observation window | 38,947,221 |

The token-linked subset is 21.7% of the source universe, and the analytic cohort is 11.5% of the
2024 United States resident population of 340.1 million. Note that 315.8 million is a cumulative
count of unique tokens observed at any time over 10.6 years and is not contemporaneous coverage;
the corresponding point-in-time figure is 246.9 million payer-identified lives in calendar 2024,
about 73% of the resident population. The step from 315.8 million to 68.4 million is the largest single exclusion in the study and is not random: token availability
depends on which identity fields a contributor supplies. This is the principal threat to the
generalisability of every downstream estimate, it is the reason Block D exists, and it is stated
in the manuscript's limitations rather than buried in a flow diagram.
