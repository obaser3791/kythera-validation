# Additional file 5. Reproduction notebook

Baser O. Validation of the Kythera Labs all-payer real-world data asset: a provenance-anchored
nine-block framework for tokenized evidence generation. *BMC Medical Research Methodology*.

The executable notebook is `notebooks/reproduction.ipynb`. This file documents what it does, what
it should print, and how to tell a genuine discrepancy from an expected one.

---

## 1. Running it

```bash
git clone https://github.com/obaser3791/kythera-validation.git
cd kythera-validation
conda env create -f environment.yml && conda activate kythera-validation
pip install -e .
jupyter lab notebooks/reproduction.ipynb
```

Or non-interactively:

```bash
jupyter nbconvert --to notebook --execute --inplace notebooks/reproduction.ipynb
```

Runtime is about six minutes on two cores at the default settings (surrogate cohort of 250,000
patients, one million candidate pairs). Every cell is driven by the single master seed 20250731,
so a rerun on the same package versions reproduces the output exactly.

---

## 2. Structure

| Section | Contents |
| --- | --- |
| 0 | Environment, package versions, master seed, and the pairwise independence assertion for every named random stream |
| 1 | Pre-registered thresholds: all 16, with source and rationale |
| 2 | Intake conformance gates and the conditionality of everything downstream |
| 3 | Cohort attrition ladder from 315,817,351 to 38,947,221 |
| 4 | Surrogate cohort construction and what it is and is not |
| 5–13 | Blocks A through I, one section each |
| 14 | The full threshold summary — 47 checks at the default settings |
| 15 | Reproducibility scope: exact, structural, and not reproducible |

---

## 3. What the notebook should print

These are the values the notebook produces at the default settings. Where a quantity is a property
of the estimator rather than of the surrogate, it is marked **exact** and any departure is a
defect. Where it is a property of the surrogate cohort, it is marked **structural** and small
departures across package versions are expected.

### Section 0 — environment and streams

```
master seed 20250731
named streams: block_i_random_split, block_e_mice, linkage_candidate_pairs
pairwise independence: True
```

**Exact.** A `False` here invalidates every downstream number. During development the split
indicator was drawn from the same seed as the surrogate data, the streams coincided, the split
stopped being independent of the outcome, and an apparent c-statistic moved by more than a tenth.
The assertion exists because that failure was silent.

### Section 1 — thresholds

Sixteen threshold records, each with its key, operator, value, source and the alternatives
considered. **Exact.**

### Section 2 — intake gates

```
gates evaluated (graded): 9
gates failing: []
submission latency: median 9 days (IQR 7-14)
```

**Exact.** Four further gates are descriptive and carry no bound; they are reported and not
counted as passing.

### Section 3 — cohort

```
315,817,351 -> 68,412,993 -> 41,802,554 -> 38,947,221
final cohort as share of the 2024 US resident population: 11.5%
```

**Exact.** The notebook also prints the caution that 315.8 million is a cumulative count of unique
tokens over 10.6 years and not contemporaneous coverage; the point-in-time figure is 246.9 million
payer-identified lives in calendar 2024.

### Section 5 — Block A

```
Elixhauser comorbidity  k=31  alpha=0.876 (0.875-0.876)
Charlson comorbidity    k=17  alpha=0.842 (0.841-0.843)
test-retest ICC(2,1) = 0.809 (0.808-0.810)
Elixhauser vs heart failure           SMD=1.258
Charlson vs chronic kidney disease    SMD=1.039
Elixhauser for 90-day mortality       c=0.811
Charlson for 90-day mortality         c=0.779
```

**Structural.** The alphas are close to the published 0.874 and 0.854 because the surrogate's
inter-item correlation structure was set from the published values, not because the surrogate
reproduces the asset.

### Section 6 — Block B

```
worst measure MAPE = 0.047   (<= 0.05, met)
Lin's CCC = 0.9994 (0.9985-0.9997)
```

**Exact.** This block reads published marginals and needs no record-level data.

### Section 7 — Block C

```
two-factor  chi2=  204.0  df=53  CFI=0.999  TLI=0.998  RMSEA=0.012  SRMR=0.006
one-factor  chi2=25085.0  df=54  CFI=0.798  RMSEA=0.152  SRMR=0.099
delta chi2 = 24881.0 on 1 df
phi = 0.588   AVE 0.580 / 0.535   omega 0.905 / 0.851   Fornell-Larcker satisfied
```

**Structural.** The fit of a correctly specified model to data generated under that model is
better than the fit reported in the manuscript, and it should be. What the section demonstrates is
that the estimator recovers the structure and decisively prefers two factors to one.

### Section 8 — Block D

```
published       max |SMD| = 0.061  (age bands), after weighting 0.020
unweighted      max |SMD| = 0.314
raked           max |SMD| = 0.000
raked + trimmed max |SMD| = 0.060
weights (normalised): min 0.108  median 0.894  max 8.054  design effect 1.624
```

**Structural** for the recomputed rows; the published maximum and the post-weighting figure are
**exact** and are read from the configuration.

### Section 9 — Block E

```
Little's MCAR test: chi2=69.73  df=72  p=0.5540  patterns=8
pooled income_band 2.9938 (SE 0.00451)  FMI=0.021  df=9289.1   (5 imputations)
delta -0.50 SD -> 2.2886    +0.00 SD -> 2.9938    +0.50 SD -> 3.6991
```

**Structural.** Read the delta range, not the test. Little's test on a complete frame returns
chi-square 0 on 1 degree of freedom with p = 1, which is a property of the test and not a finding.

### Section 10 — Block F

```
counts: tp=7353 fp=21 fn=251 tn=4257
sensitivity 0.9670 (0.9627-0.9708)   specificity 0.9951
ppv         0.9972                    npv         0.9443
false-match rate 0.0028 (0.0019-0.0043)
match rate 0.9620 (0.9590-0.9650)
weakest stratum: Race/ethnicity (imputed) = Other/Unknown, n=536, sensitivity=0.944
difficult-scenario floor: 0.918
pre-registered operating point: upper=16.40  lower=13.62
derived from the simulated distribution: upper=16.40  lower=13.62
  at the pre-registered point  FMR=0.0032  sensitivity=0.825  review share=0.262
```

**Exact** for the adjudicated accuracy, which is computed from the released aggregate 2x2 tables.
**Structural** for the simulated candidate-pair distribution, where the derived thresholds
recover the pre-registered operating point to two decimal places.

### Section 11 — Block G

```
overall kappa = 0.840 (0.830-0.850)
kappa range across 10 categories: 0.710-0.920
categories below threshold: none
```

**Exact.**

### Section 12 — Block H

```
2022Q1-2025Q2: tau=0.080  p=0.320  CUSUM breaks=0  (14 quarters)
minimum detectable tau = 0.562
exploratory 2015Q1-2025Q2: tau=0.140  p=0.090  break at 2020Q2
```

**Exact.**

### Section 13 — Block I

```
mortality_90d    random split      AUROC=0.866 (0.861-0.872)  Brier=0.0380  slope=1.00
mortality_90d    temporal holdout  AUROC=0.867 (0.862-0.872)  Brier=0.0373  slope=1.01
mortality_90d    across regions    AUROC 0.854-0.867          slope 0.94-1.00
readmission_30d  random split      AUROC=0.802 (0.796-0.808)  Brier=0.0578  slope=0.98
readmission_30d  temporal holdout  AUROC=0.800 (0.794-0.805)  Brier=0.0570  slope=0.97
readmission_30d  across regions    AUROC 0.800-0.809          slope 0.99-1.03
```

**Structural.** These are the surrogate's numbers. They are close to the manuscript's because the
surrogate's outcome model was parameterised from the published discrimination, and they are not
evidence about the asset. Any value cited from this section would be a citation of the surrogate.

### Section 14 — threshold summary

Every pre-registered check in one table, each row labelled with its position in the results —
block, outcome, validation scheme and fold — so a flagged value can be located. At the default
settings 47 checks are evaluated and none is unmet.

---

## 4. Diagnosing a discrepancy

| What you see | What it means |
| --- | --- |
| A quantity marked **exact** differs | A defect. Run `PYTHONPATH=src pytest -q` and `kythera-validate verify --n 20000`; one of them should locate it. |
| A quantity marked **structural** differs in the third decimal | Expected across numpy, scipy or scikit-learn versions. Compare against `environment.yml`. |
| A quantity marked **structural** differs in the first decimal | Not expected. Check `--n` and `--seed` first, then the stream-independence assertion in section 0. |
| Stream independence is `False` | Stop. Nothing downstream is interpretable. |
| `verify` exits non-zero | The code and the published tables disagree. That is the condition the command exists to detect. |

---

## 5. What the notebook does not do

It does not reproduce the published values of Blocks A, E and I, and it says so in each section
rather than in a footnote. Those blocks require record-level data under a licence, and the
surrogate cohort exists to demonstrate that the code is complete and correct, not to stand in for
the asset. Section 15 restates the three-way scope — exact, structural, and not reproducible
outside the licensed environment — so that a reader who runs only the notebook does not leave with
the impression that the study has been replicated.
