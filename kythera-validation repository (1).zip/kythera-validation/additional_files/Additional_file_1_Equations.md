# Additional file 1. Estimators, variance formulae and pre-specified thresholds

Baser O. Validation of the Kythera Labs all-payer real-world data asset: a provenance-anchored
nine-block framework for tokenized evidence generation. *BMC Medical Research Methodology*.

This file states every estimator used in the study in full notation, together with its variance
or interval formula, its degrees of freedom where applicable, the pre-specified acceptance
threshold for the block in which it is used, and a worked numerical example computed from values
that appear in the manuscript. Each equation is implemented in
`src/kythera_validation/equations.py`; the function name is given beside each heading so that the
notation and the code can be read against one another.

Throughout, \(n\) is the number of units contributing to the estimate, \(k\) the number of items
or fields, and \(z_{0.975} = 1.959964\).

---

## Block A — Internal consistency and stability

### Equation 1. Cronbach's alpha (`cronbach_alpha`)

For a composite of \(k\) items with item variances \(s_i^2\) and total-score variance
\(s_T^2\),

\[
\alpha = \frac{k}{k-1}\left(1 - \frac{\sum_{i=1}^{k} s_i^2}{s_T^2}\right).
\]

The confidence interval uses the Feldt transformation, in which

\[
\frac{1-\alpha}{1-\hat\alpha} \sim F_{\nu_1,\nu_2}, \qquad \nu_1 = n-1, \quad \nu_2 = (n-1)(k-1),
\]

giving

\[
\left[\,1 - (1-\hat\alpha)\,F_{1-\alpha/2}(\nu_1,\nu_2),\;\;
1 - (1-\hat\alpha)\,F_{\alpha/2}(\nu_1,\nu_2)\,\right].
\]

**Pre-specified threshold.** \(\alpha \ge 0.80\). The 0.80 boundary is the conventional
requirement for group-level research use; 0.90 applies to individual-level decisions and 0.70 is
a scale-development boundary. Both alternatives were considered and rejected at
pre-registration.

**Worked example.** The Elixhauser composite comprises \(k = 31\) indicators. With
\(\sum s_i^2 = 4.118\) and \(s_T^2 = 24.61\),

\[
\alpha = \frac{31}{30}\left(1 - \frac{4.118}{24.61}\right) = 1.0333 \times 0.8327 = 0.8605.
\]

The manuscript reports 0.874 for this composite in the analytic cohort, with the interval
0.873–0.875 at \(n = 38{,}947{,}221\). At that sample size the interval is narrow enough that the
point estimate carries the interpretation, which is why the threshold is stated on the point
estimate rather than on the lower bound.

**Interpretation limit.** Alpha is a function of the number of items as well as their
intercorrelation. A 31-item composite will exceed 0.80 even with modest inter-item correlation,
so alpha is reported here alongside the average inter-item correlation and is not treated as
evidence that the composite measures a single construct. That question is Block C's.

### Equation 2. Two-way random-effects intraclass correlation (`icc_two_way_random`)

For \(n\) subjects rated on \(k\) occasions, with mean squares \(\text{MS}_R\) between subjects,
\(\text{MS}_C\) between occasions and \(\text{MS}_E\) residual,

\[
\mathrm{ICC}(2,1) = \frac{\text{MS}_R - \text{MS}_E}{\text{MS}_R + (k-1)\text{MS}_E + \frac{k}{n}(\text{MS}_C - \text{MS}_E)}.
\]

The interval is obtained from the \(F\) distribution on \(\nu_1 = n-1\) and
\(\nu_2 = (n-1)(k-1)\) degrees of freedom.

**Pre-specified threshold.** \(\mathrm{ICC} \ge 0.70\). Alternatives of 0.75 and 0.80 were
rejected because a twelve-month test-retest window captures genuine clinical change as well as
coding noise, and a higher threshold would penalise the former.

**Worked example.** With \(\text{MS}_R = 3.412\), \(\text{MS}_C = 0.021\), \(\text{MS}_E = 0.361\), \(k = 2\) and
\(n = 250{,}000\):

\[
\mathrm{ICC} = \frac{3.412 - 0.361}{3.412 + 0.361 + \frac{2}{250000}(0.021-0.361)}
= \frac{3.051}{3.773} = 0.8087,
\]

against the 0.808 reported in the manuscript.

### Equation 3. Positive specific agreement (`component_agreement`)

For two sources classifying the same units,

\[
\mathrm{PSA} = \frac{2a}{2a + b + c},
\]

where \(a\) is the count of units positive in both, and \(b\) and \(c\) the discordant counts.
The Wilson interval is applied on the effective denominator \(2a+b+c\).

**Why this and not simple agreement.** For a condition with 4% prevalence, two sources that
both record no cases agree on 96% of units and have measured nothing. Positive specific
agreement discards the concordant negatives and is therefore the quantity that can fail.

---

## Block B — External consistency

### Equation 4. Mean absolute percentage error (`mape`)

Against a survey benchmark \(r_j\) over \(J\) strata,

\[
\mathrm{MAPE} = \frac{1}{J}\sum_{j=1}^{J} \left| \frac{o_j - r_j}{r_j} \right|.
\]

**Pre-specified threshold.** \(\mathrm{MAPE} \le 0.05\). 0.03 lies inside the sampling error of
the benchmarks themselves; 0.10 would accept differences large enough to change a policy
conclusion.

**Worked example.** Diabetes prevalence, claims 0.1042 against NHANES 0.1080; hypertension
0.3121 against 0.3220; hyperlipidemia 0.3384 against 0.3260. The absolute relative errors are
0.0352, 0.0307 and 0.0380, giving \(\mathrm{MAPE} = 0.0346\) for these three strata; the
manuscript's stratified mean over all comparisons is 0.047.

### Equation 5. Lin's concordance correlation coefficient (`lins_ccc`)

\[
\rho_c = \frac{2\,s_{xy}}{s_x^2 + s_y^2 + (\bar x - \bar y)^2}.
\]

The interval uses the Fisher z transformation of \(\rho_c\) with Lin's asymptotic variance,

\[
\hat\sigma^2_{z} = \frac{1}{n-2}\left[
\frac{(1-\rho^2)\rho_c^2}{(1-\rho_c^2)\rho^2}
+ \frac{2\rho_c^3(1-\rho_c)u^2}{\rho(1-\rho_c^2)^2}
- \frac{\rho_c^4 u^4}{2\rho^2(1-\rho_c^2)^2}\right],
\qquad u = \frac{\bar x - \bar y}{\sqrt{s_x s_y}},
\]

where \(\rho\) is the Pearson correlation. At exact agreement the variance is undefined and the
interval collapses to the point estimate; the implementation returns that rather than a missing
value.

**Pre-specified threshold.** \(\rho_c \ge 0.90\). 0.95 was judged too strict given known
construct differences between claims and survey measurement.

**Why not the Pearson correlation.** A systematic bias of any magnitude leaves the Pearson
correlation at unity. Lin's coefficient penalises departure from the 45-degree line, which is
the property required of a benchmark comparison.

### Equation 6. Standardized mean difference (`standardized_mean_difference`)

For continuous measures,

\[
d = \frac{\bar x - \bar y}{\sqrt{(s_x^2 + s_y^2)/2}},
\]

and for a binary measure with proportions \(p_x, p_y\),

\[
d = \frac{p_x - p_y}{\sqrt{[p_x(1-p_x) + p_y(1-p_y)]/2}}.
\]

The sign is discarded; the threshold is stated on the absolute value.

**Pre-specified threshold.** \(|d| < 0.10\) after weighting. 0.05 is unattainable for
area-level income measures and 0.25 would leave differences that alter national estimates.

**Worked example.** Cohort aged 65 and over 0.212 against an ACS target of 0.178:

\[
|d| = \frac{|0.212 - 0.178|}{\sqrt{(0.212 \times 0.788 + 0.178 \times 0.822)/2}}
= \frac{0.034}{\sqrt{0.1567}} = 0.0859.
\]

---

## Block D — Representativeness

### Equation 7. Raking to external margins (`raking_weights`)

Given \(M\) margins with target proportions \(t_{m\ell}\) for level \(\ell\) of margin \(m\),
iterative proportional fitting updates weights by

\[
w_i^{(s+1)} = w_i^{(s)} \times \frac{t_{m\ell}}{\hat p^{(s)}_{m\ell}},
\qquad
\hat p^{(s)}_{m\ell} = \frac{\sum_{i: x_{im}=\ell} w_i^{(s)}}{\sum_i w_i^{(s)}},
\]

cycling over margins until \(\max_{m,\ell} |\hat p_{m\ell} - t_{m\ell}| < 10^{-10}\). Weights are
trimmed to \([0.2, 5.0]\) after convergence.

**Design effect and effective sample size.** Trimming costs precision, and the cost is
reported:

\[
\mathrm{DEFF} = \frac{n \sum_i w_i^2}{\left(\sum_i w_i\right)^2},
\qquad n_{\text{eff}} = \frac{n}{\mathrm{DEFF}}.
\]

**Worked example.** Untrimmed raking reduces the largest absolute standardized difference from
0.317 to below \(10^{-3}\), reproducing the ACS margins to numerical tolerance. Trimming at
\([0.2, 5.0]\) leaves a maximum of 0.064 — still inside the 0.10 criterion, and the honest
figure to report, because untrimmed weights would attach implausible influence to a small number
of patients.

---

## Block E — Missingness

### Equation 8. Little's test of missingness completely at random (`littles_mcar_test`)

For \(P\) observed missingness patterns with \(n_p\) units in pattern \(p\), observed variables
\(O_p\), pattern means \(\bar y_p\) and maximum-likelihood estimates \(\hat\mu, \hat\Sigma\),

\[
d^2 = \sum_{p=1}^{P} n_p \,(\bar y_p - \hat\mu_{O_p})^{\top}
\hat\Sigma_{O_p}^{-1} (\bar y_p - \hat\mu_{O_p})
\;\sim\; \chi^2_{\nu},
\qquad \nu = \sum_{p=1}^{P} |O_p| - q,
\]

where \(q\) is the number of variables.

**Interpretation limit.** A test that does not reject is not evidence that data are missing
completely at random; at \(n\) in the tens of millions it is close to uninformative in the other
direction, since trivial departures reject. The test is reported for completeness and the
substantive argument rests on the delta-adjusted sensitivity analysis.

### Equation 9. Rubin's pooling rules (`rubin_pool`)

Across \(m\) imputations with estimates \(\hat\theta_\ell\) and variances \(U_\ell\),

\[
\bar\theta = \frac{1}{m}\sum_{\ell=1}^{m}\hat\theta_\ell,
\qquad
\bar U = \frac{1}{m}\sum_{\ell=1}^{m} U_\ell,
\qquad
B = \frac{1}{m-1}\sum_{\ell=1}^{m} (\hat\theta_\ell - \bar\theta)^2,
\]

\[
T = \bar U + \left(1 + \frac{1}{m}\right) B,
\qquad
\lambda = \frac{(1 + 1/m)B}{T},
\qquad
\mathrm{FMI} = \lambda + \frac{2}{\nu + 3}\,(1-\lambda),
\]

with Barnard-Rubin degrees of freedom

\[
\nu = \left(\frac{1}{\nu_m} + \frac{1}{\nu_{obs}}\right)^{-1},
\qquad
\nu_m = (m-1)\lambda^{-2},
\qquad
\nu_{obs} = \frac{\nu_{com}+1}{\nu_{com}+3}\,\nu_{com}(1-\lambda).
\]

**Pre-specified threshold.** Pooled \(\mathrm{FMI} \le 0.30\).

**Worked example.** With \(m = 20\), \(\bar\theta = 0.1042\), \(\bar U = 2.71\times10^{-9}\) and
\(B = 3.55\times10^{-10}\): \(T = 2.747\times10^{-9}\), \(\lambda = 0.1357\), and
\(\mathrm{FMI} = 0.138\), inside the manuscript's reported range of 0.111–0.140.

---

## Block F — Linkage

### Equation 10. Fellegi-Sunter agreement weight (`fellegi_sunter_weight`)

For fields \(i = 1,\dots,k\) with agreement indicator \(\gamma_i\), match probability \(m_i\) and
chance-agreement probability \(u_i\), the total weight is

\[
w = \sum_{i=1}^{k} \gamma_i \log_2\!\frac{m_i}{u_i}
+ (1-\gamma_i) \log_2\!\frac{1-m_i}{1-u_i}.
\]

A pair is declared a link when \(w \ge T_\mu\), a non-link when \(w < T_\lambda\), and referred
for clerical review when \(T_\lambda \le w < T_\mu\).

**Worked example.** Agreement on the date-of-birth hash, with \(m = 0.981\) and \(u = 0.0007\),
earns \(\log_2(0.981/0.0007) = 10.45\) bits. Agreement on sex, with \(m = 0.996\) and
\(u = 0.501\), earns \(\log_2(0.996/0.501) = 0.99\) bits. The ratio is the reason the schedule
cannot rest on demographic fields of low entropy.

### Equation 11. Threshold derivation

The upper threshold is the smallest \(T_\mu\) satisfying the pre-registered constraint on the
false-match rate,

\[
T_\mu = \min\left\{ t : \frac{\#\{\text{non-matches}: w \ge t\}}{\#\{w \ge t\}} \le \varepsilon
\right\}, \qquad \varepsilon = 0.005,
\]

and the lower threshold is the largest \(T_\lambda\) retaining the target sensitivity,

\[
T_\lambda = \max\left\{ t : \frac{\#\{\text{matches}: w \ge t\}}{\#\{\text{matches}\}} \ge \pi
\right\}, \qquad \pi = 0.95.
\]

Derived from the simulated weight distribution this yields \(T_\mu = 16.40\) and
\(T_\lambda = 13.62\), which are the values used throughout. The curve is steep near the
operating point — moving \(T_\mu\) from 16.40 to 16.00 raises the false-match rate from 0.0029 to
0.035 — so the thresholds are reported to two decimal places and the sensitivity of the
operating point to their placement is reported with them.

### Equation 12. Linkage accuracy (`linkage_accuracy`)

From the adjudicated two-by-two table,

\[
\mathrm{Se} = \frac{\text{TP}}{\text{TP}+\text{FN}}, \quad
\mathrm{Sp} = \frac{\text{TN}}{\text{TN}+\text{FP}}, \quad
\mathrm{PPV} = \frac{\text{TP}}{\text{TP}+\text{FP}}, \quad
\mathrm{NPV} = \frac{\text{TN}}{\text{TN}+\text{FN}},
\]

with the false-match rate \(1 - \mathrm{PPV}\). All intervals are Wilson score intervals,

\[
\frac{\hat p + \frac{z^2}{2n} \pm z\sqrt{\frac{\hat p(1-\hat p)}{n} + \frac{z^2}{4n^2}}}
{1 + \frac{z^2}{n}}.
\]

**Pre-specified thresholds.** Match rate \(\ge 0.90\); false-match rate \(\le 0.005\).

**Worked example.** The adjudicated table is \(\text{TP} = 7{,}353\), \(\text{FP} = 21\), \(\text{FN} = 251\),
\(\text{TN} = 4{,}257\). Then \(\mathrm{Se} = 7353/7604 = 0.9670\) (0.963–0.971),
\(\mathrm{Sp} = 4257/4278 = 0.9951\), \(\mathrm{PPV} = 7353/7374 = 0.99715\), and the false-match
rate is 0.00285, inside the 0.005 constraint.

### Equation 13. Match rate (`match_rate`)

\[
\hat r = \frac{L}{E},
\]

the linked count over the eligible count, with a Wilson interval. For \(L = 68{,}412{,}993\) and
\(E = 71{,}114{,}000\), \(\hat r = 0.9620\).

---

## Block G — Intercoder agreement

### Equation 14. Cohen's kappa (`cohens_kappa`)

With observed agreement \(p_o\) and chance agreement \(p_e = \sum_j p_{j\cdot}p_{\cdot j}\),

\[
\kappa = \frac{p_o - p_e}{1 - p_e},
\qquad
\widehat{\mathrm{Var}}(\kappa) = \frac{p_o(1-p_o)}{n(1-p_e)^2}
\]

for the simple case, with the full Fleiss-Cohen-Everitt expression used for the reported
intervals.

**Pre-specified threshold.** \(\kappa \ge 0.61\), the Landis-Koch substantial-agreement
boundary. 0.81 was rejected because fifth-character ICD-10-CM specificity is not reliably
recoverable from note text.

**Worked example.** A category with \(p_o = 0.90\) and marginals \((0.45, 0.55)\) has
\(p_e = 0.45^2 + 0.55^2 = 0.505\) and \(\kappa = 0.395/0.495 = 0.798\).

**The base-rate problem, stated.** Hold observed agreement at 0.90 and make the condition rare:
with marginals \((0.10, 0.90)\), \(p_e = 0.82\) and \(\kappa\) falls to 0.444 on identical
agreement. Kappa is therefore reported beside positive predictive value and the category
prevalence, and a low kappa on a rare category is not read as poor coding.

---

## Block H — Temporal stability

### Equation 15. Mann-Kendall trend test (`mann_kendall`)

\[
S = \sum_{i<j} \text{sgn}\,(x_j - x_i),
\qquad
\tau = \frac{2S}{n(n-1)},
\qquad
\mathrm{Var}(S) = \frac{n(n-1)(2n+5) - \sum_g t_g(t_g-1)(2t_g+5)}{18},
\]

with \(z = (S - \text{sgn}\,(S))/\sqrt{\mathrm{Var}(S)}\).

**Pre-specified threshold.** \(|\tau| \le 0.20\). 0.10 was rejected as over-sensitive to the
2020–2021 pandemic shock.

**Minimum detectable effect.** A null result is reported with the effect the design could have
found. At 80% power and two-sided \(\alpha = 0.05\) with \(n = 14\) quarters,

\[
\tau_{\min} = \frac{(z_{0.975} + z_{0.80})\sqrt{\mathrm{Var}(S)}}{n(n-1)/2}
= 0.562.
\]

The observed \(\tau = 0.08\) with \(p = 0.32\) is therefore consistent with no monotone trend
**and** with trends up to \(|\tau| \approx 0.56\); the series cannot distinguish them. Reporting
the first without the second would overstate what fourteen quarters can establish.

### Equation 16. CUSUM change detection (`cusum`)

On standardised observations \(z_t\) with reference value \(\kappa\) and decision interval
\(h\),

\[
C_t^{+} = \text{max}(0,\; C_{t-1}^{+} + z_t - \kappa),
\qquad
C_t^{-} = \text{max}(0,\; C_{t-1}^{-} - z_t - \kappa),
\]

flagging \(t\) when \(\text{max}(C_t^+, C_t^-) > h\). Here \(\kappa = 0.5\) and \(h = 5.0\), the
conventional pairing for detecting a one-standard-deviation shift.

---

## Block I — Predictive utility

### Equation 17. Area under the ROC curve, calibration, and the Brier score

The c-statistic is the Mann-Whitney statistic scaled to the number of discordant pairs
(`auroc`),

\[
\mathrm{AUROC} = \frac{1}{n_1 n_0}\sum_{i:y_i=1}\sum_{j:y_j=0}
\left[\mathbb{1}(p_i > p_j) + \tfrac12 \mathbb{1}(p_i = p_j)\right],
\]

with the DeLong interval. Calibration is assessed by the intercept and slope of

\[
\text{logit}\,(y) = \alpha + \beta \text{logit}\,(\hat p),
\]

where \(\beta = 1\) and \(\alpha = 0\) denote calibration in the large and in the small, and by
the Brier score (`brier_and_calibration`)

\[
\mathrm{BS} = \frac{1}{n}\sum_{i=1}^{n}(\hat p_i - y_i)^2,
\qquad
\mathrm{BS}_{\text{scaled}} = 1 - \frac{\mathrm{BS}}{\bar y(1-\bar y)}.
\]

**Pre-specified thresholds.** \(\mathrm{AUROC} \ge 0.75\) and \(\mathrm{BS} \le 0.20\) for the
primary random-split estimate. Values from the temporal holdout and the leave-one-region-out
folds are reported as diagnostics and are not subject to the pre-registered criterion, because
the criterion was registered on the primary estimate.

**Why all three are reported.** Any strictly monotone transformation of \(\hat p\) leaves the
c-statistic unchanged while destroying calibration. Doubling a set of well-calibrated
probabilities preserves the AUROC exactly and roughly doubles the Brier score. A model can
therefore discriminate perfectly and be useless for any decision that depends on the predicted
probability itself — which is most decisions in health economics. Discrimination alone is not
evidence of data validity, and this study does not treat it as such.

---

## Summary of pre-specified thresholds

| Key | Block | Metric | Criterion | Source of the cutoff |
| --- | --- | --- | --- | --- |
| `A_cronbach_alpha` | A | Cronbach's alpha | \(\ge 0.80\) | Cronbach 1951; Nunnally & Bernstein 1994 |
| `A_test_retest_icc` | A | Two-way random ICC | \(\ge 0.70\) | Nunnally & Bernstein 1994 |
| `B_mape` | B | MAPE against survey benchmark | \(\le 0.05\) | Strength-of-agreement convention |
| `B_lins_ccc` | B | Lin's concordance | \(\ge 0.90\) | Lin 1989; McBride 2005 |
| `C_cfi` | C | Comparative fit index | \(\ge 0.95\) | Hu & Bentler 1999 |
| `C_tli` | C | Tucker-Lewis index | \(\ge 0.95\) | Hu & Bentler 1999 |
| `C_rmsea` | C | RMSEA | \(\le 0.06\) | Hu & Bentler 1999 |
| `C_srmr` | C | SRMR | \(\le 0.08\) | Hu & Bentler 1999 |
| `D_abs_smd` | D | Absolute SMD against ACS | \(< 0.10\) | Austin 2011 |
| `E_pooled_fmi` | E | Pooled fraction of missing information | \(\le 0.30\) | Rubin 1987; White et al. 2011 |
| `F_match_rate` | F | Tokenized match rate | \(\ge 0.90\) | Fellegi & Sunter 1969; Winkler 2006 |
| `F_false_match_rate` | F | False-match rate | \(\le 0.005\) | Pre-registered linkage constraint |
| `G_cohens_kappa` | G | Cohen's kappa per category | \(\ge 0.61\) | Landis & Koch 1977 |
| `H_abs_tau` | H | Absolute Kendall tau | \(\le 0.20\) | Trend-stability convention |
| `I_auroc` | I | AUROC, primary split | \(\ge 0.75\) | Hosmer & Lemeshow 2000 |
| `I_brier` | I | Brier score | \(\le 0.20\) | Steyerberg et al. 2010 |

Each threshold, its literature source, the alternatives considered at pre-registration and the
reason the chosen value was preferred are declared in `config/thresholds.yaml` and printed by
`kythera-validate thresholds`.
