# Additional file 2. Methodological appendix

Baser O. Validation of the Kythera Labs all-payer real-world data asset: a provenance-anchored
nine-block framework for tokenized evidence generation. *BMC Medical Research Methodology*.

This file gives the estimation settings, sampling frames, protocols and diagnostics that are
summarised in the manuscript. It is written so that a reader who disagrees with a choice can see
exactly what was chosen and what the alternative would have been.

---

## 1. Confirmatory factor analysis (Block C)

### 1.1 Estimator and rationale

All indicators are ordinal quintiles, so the model is fitted to a matrix of polychoric
correlations by weighted least squares with mean- and variance-adjusted test statistics (WLSMV).
Maximum likelihood on Pearson correlations was rejected: treating five-category ordinal
indicators as continuous attenuates loadings and inflates the chi-square statistic, and the
attenuation is largest where the marginal distributions are most skewed, which is precisely
where the tract-level poverty indicators sit.

| Setting | Value |
| --- | --- |
| Estimator | WLSMV |
| Input matrix | Polychoric correlations |
| Scaling | Factor variances fixed at unity, loadings free |
| Cross-loadings | None permitted |
| Correlated residuals | None permitted |
| Factor correlation | Freely estimated |
| Estimation sample | 200,000 patients drawn at random from the analytic cohort |
| Missing data | Pairwise deletion for the correlation matrix; all indicators are area-level and complete for 99.7% of patients |

Fitting the model on a random subsample rather than on all 38.9 million patients is deliberate.
At the full sample size every model is rejected by the chi-square test regardless of substantive
adequacy, and the fit indices become numerically unstable in the fourth decimal place while
carrying no additional information. The subsample is large enough that the loadings are
determined to three decimal places.

### 1.2 Polychoric correlation estimation

Each pairwise polychoric correlation is obtained by two-step estimation: thresholds are fixed
from the univariate marginal cumulative proportions, then the correlation is estimated by
maximising the bivariate ordinal likelihood. The bivariate normal rectangle probabilities use
the Sheppard identity with 24-node Gauss-Legendre quadrature, and the correlation is found by
bounded least squares on \((-0.999, 0.999)\).

An earlier implementation used a derivative-free search. It converged inconsistently when a
marginal category held less than 1% of the sample, because the likelihood surface is nearly flat
there. The bounded least-squares formulation removed that behaviour, and the change altered no
reported correlation by more than 0.002.

### 1.3 Model comparison

The two-factor model is compared against a one-factor alternative in which all indicators load
on a single general factor. Discriminant validity is assessed by the Fornell-Larcker criterion:
the average variance extracted for each factor must exceed the squared factor correlation.

| Quantity | Two-factor | One-factor |
| --- | --- | --- |
| CFI | 0.995 | 0.790 |
| TLI | 0.994 | — |
| RMSEA | 0.025 | — |
| SRMR | 0.012 | — |
| Factor correlation | 0.571–0.593 | not applicable |

The factor correlation is well below the 0.85 boundary at which two factors would be
indistinguishable, and the average variance extracted for both factors exceeds its square. The
one-factor model is decisively worse on every index.

### 1.4 What this does and does not establish

The model demonstrates that the area-level indicators behave as two coherent dimensions. It does
not establish that those dimensions measure economic adversity and care access as a health
economist would define them at the individual level. Area-level measures are ecological
proxies; a patient in a high-poverty tract is not necessarily poor. This limitation is stated in
the manuscript and is not resolved by any fit index.

---

## 2. Probabilistic linkage (Block F)

### 2.1 Weight schedule

| Element | *m* | *u* | Availability | Agreement weight (bits) |
| --- | --- | --- | --- | --- |
| Surname hash | 0.972 | 0.0031 | 0.991 | 8.29 |
| Given-name hash | 0.948 | 0.0104 | 0.973 | 6.51 |
| Date-of-birth hash | 0.981 | 0.0007 | 0.996 | 10.45 |
| Sex | 0.996 | 0.501 | 0.998 | 0.99 |
| ZIP5 hash | 0.842 | 0.0009 | 0.857 | 9.87 |
| SSN last-four hash | 0.713 | 0.0001 | 0.412 | 12.80 |

The \(m\) probabilities are estimated by expectation-maximisation on the candidate-pair set; the
\(u\) probabilities are computed from the marginal frequency distribution of each hashed element
in the source universe. The prior match odds are set to 0.001, reflecting the blocking design
rather than the population prevalence of true matches.

Two properties of this schedule govern everything downstream. Agreement on sex is worth about one
bit and cannot carry a linkage decision. The SSN last-four hash is the most informative element
and is available for only 41.2% of records, so the effective weight distribution is bimodal:
pairs with the element available separate cleanly, and pairs without it concentrate near the
review band.

### 2.2 Blocking passes

| Pass | Blocking key | Purpose |
| --- | --- | --- |
| 1 | `token_1` — name + date of birth + sex | Highest-specificity pass; captures pairs with a complete identifier set |
| 2 | `token_2` — surname + date of birth + ZIP5 | Recovers pairs where the given name is recorded inconsistently |
| 3 | `token_4` — date of birth + sex + ZIP3 | Coarse geographic pass; recovers interstate moves at the cost of a much larger candidate set, which is why it is applied late and why its pairs carry the lowest prior |
| 4 | `token_5` — surname + given-name initial + date of birth | Recovers pairs where the ZIP code changed and the given name was truncated or abbreviated by the contributor |

Passes are applied in sequence and candidate pairs are deduplicated across passes. The
multi-pass design exists because any single blocking key discards true matches that disagree on
the key itself, and the direction of that loss is not random: a single-key design on surname
would systematically drop patients whose surname changed, which is not independent of sex or
marital status. The passes as implemented are listed in
`src/kythera_validation/linkage/fellegi_sunter.py` and are printed by
`kythera-validate info`.

### 2.3 Threshold derivation

Thresholds were derived from the weight distribution rather than adopted from convention, subject
to the pre-registered constraint that the false-match rate not exceed 0.005. This yields
\(T_\mu = 16.40\) and \(T_\lambda = 13.62\). At that operating point, on the candidate-pair
distribution: false-match rate 0.0029, sensitivity 0.82, clerical-review share 0.26.

The trade-off is steep and is reported as such. Lowering \(T_\mu\) from 16.40 to 16.00 raises the
false-match rate from 0.0029 to 0.035 — an order of magnitude for a 2.4% change in the
threshold. Any study using this asset for outcome linkage should therefore treat the operating
point as a study-design parameter and not as a property of the data.

### 2.4 Adjudication sampling frame and blinding

| Element | Specification |
| --- | --- |
| Frame | All candidate pairs surviving any blocking pass |
| Stratification | By blocking pass, by weight decile, and by SSN-element availability |
| Sample size | 11,882 pairs |
| Oversampling | The clerical-review band was oversampled fourfold relative to its share of the candidate set |
| Adjudicators | Two trained abstractors working independently |
| Blinding | Adjudicators saw the underlying record attributes but not the computed weight, not the decision, and not the pass that generated the pair |
| Disagreement | Resolved by a third adjudicator; the rate of referral was 3.4% |
| Reference standard | Consensus adjudication of the record pair |

Oversampling the review band is the reason the reported false-match rate is credible. Sampling
in proportion to the candidate set would place almost the entire sample in a region where every
pair is obviously a non-match, and the resulting interval on the false-match rate would be wide
where it matters and narrow where it does not. All reported rates are weighted back to the
candidate-set composition.

Blinding to the computed weight matters for the same reason. An adjudicator who can see that a
pair scored 22 bits is not an independent reference standard for whether that pair is a match.

### 2.5 Reported strata

Accuracy is reported overall, by blocking pass, by weight decile, by SSN availability, and for
four difficult scenarios constructed in advance: common surname with common date of birth;
recent address change; twin or same-household same-date-of-birth pairs; and paediatric records
with incomplete name fields. The stratum with the lowest sensitivity is named in the manuscript
rather than left for the reader to locate, because an overall sensitivity of 0.967 is compatible
with a subgroup in which linkage fails often enough to bias a study restricted to that subgroup.

---

## 3. Multiple imputation (Block E)

### 3.1 Model

| Setting | Value |
| --- | --- |
| Method | Multiple imputation by chained equations |
| Imputations | 20 |
| Iterations per imputation | 10 |
| Continuous variables | Predictive mean matching, 5 donors |
| Binary variables | Logistic regression |
| Unordered categorical | Multinomial logistic regression |
| Predictor set | Fixed across variables: age band, sex, region, contributor cohort, period, observability months, Charlson score, and the outcome indicators |
| Design matrix | Categorical predictors label-encoded; all predictors standardised |
| Pooling | Rubin's rules with Barnard-Rubin degrees of freedom |

Standardising the design matrix and fixing the predictor set reduced runtime from about 164
seconds to about 3.5 seconds per pooled estimate without altering the pooled point estimates
beyond the fourth decimal place. The reason is conditioning: the unstandardised matrix mixed
counts in the thousands with indicators in \(\{0,1\}\), and the iterative solver spent most of
its work on that scaling rather than on the imputation.

Outcome indicators are included as predictors in the imputation model. Omitting them would bias
associations between the imputed variables and the outcomes towards zero, which is the standard
result and the reason the practice is recommended despite appearing circular.

### 3.2 Convergence diagnostics

Convergence was assessed by trace plots of the imputed means and variances across the ten
iterations for each of the 20 chains, and by the Gelman-Rubin statistic computed across chains.
All monitored quantities gave \(\hat R < 1.01\). No chain showed drift or periodicity over the
final five iterations.

### 3.3 Sensitivity to departures from ignorability

Because Little's test is close to uninformative at this sample size in both directions, the
substantive argument rests on a delta-adjustment sensitivity analysis: imputed values are shifted
by \(\delta\) standard deviations, with \(\delta \in \{-0.5, -0.2, 0, 0.2, 0.5\}\), and every
reported estimate is recomputed. The manuscript reports the range. This answers the question a
reader should actually ask — how wrong would the ignorability assumption have to be to change the
conclusion — rather than whether a test rejected.

---

## 4. Predictive models (Block I)

### 4.1 Specifications and hyperparameter grids

| Model | Grid |
| --- | --- |
| Penalised logistic regression | L2 penalty *C* ∈ {0.01, 0.1, 1, 10}; LBFGS; 2,000 iterations |
| Gradient-boosted trees | Depth \(\in \{2,3,4\}\); learning rate \(\in \{0.05, 0.1\}\); 100–400 estimators; subsample \(\in \{0.8, 1.0\}\) |
| Random forest | 300 trees; minimum leaf size \(\in \{5, 20, 50\}\) |

Selection is by five-fold cross-validation **within the training partition only**, on the area
under the ROC curve. The test partition is used once, for the reported estimate.

### 4.2 Validation schemes

| Scheme | Definition |
| --- | --- |
| Random split | 70% training, 30% test, drawn from a named random stream independent of the data-generating stream |
| Temporal holdout | Trained on index events through 2022, tested on 2023 onward |
| Leave-one-region-out | Trained on all census regions but one, tested on the held-out region; repeated for each region |

The pre-registered AUROC and Brier thresholds apply to the primary random-split estimate. The
temporal and geographic schemes are reported as diagnostics of transportability; a fold-level
value below the threshold indicates that the model transports imperfectly to that period or
region, which is a finding about generalisation and not a failure of the pre-registered
criterion.

### 4.3 Leakage controls

- No feature is computed from any observation on or after the index date.
- The outcome window is fixed at 90 days for mortality and 30 days for readmission, and features
  are drawn from the 24 months preceding the index date only.
- Cost and utilisation features exclude the index encounter itself.
- Patients are assigned to exactly one partition; no patient contributes to both training and
  test in any scheme.
- Preprocessing statistics — means, standard deviations, imputation donors, encoder levels — are
  estimated on the training partition and applied to the test partition, never re-estimated.
- The split indicator is drawn from a named random stream. This is a substantive control, not
  hygiene: during development the split was drawn from the same seed as the surrogate data, the
  two streams coincided, the split stopped being independent of the outcome, and an apparent
  c-statistic moved by more than a tenth without raising anything.

### 4.4 What Block I establishes

That the asset carries signal sufficient to support prediction at the reported level, under the
stated leakage controls. Discrimination is a property of a modelling task on these data, not a
validity coefficient for the data. A c-statistic can be raised by a variable that is a proxy for
the outcome's ascertainment rather than its occurrence, and it is unchanged by any monotone
distortion of the predicted probabilities. Calibration and the Brier score are therefore reported
beside it, and none of the three is offered as evidence that a diagnosis code means what it
appears to mean.

---

## 5. Reproducibility scope

This section states plainly what a reader can and cannot reproduce, because the alternative is to
imply more than the repository delivers.

### 5.1 Fully reproducible from public inputs

- All seventeen estimators in `equations.py`, with the worked examples in Additional file 1.
- The NHANES, MEPS and ACS comparison targets, which are public.
- **Block B** (external consistency), **Block C** (construct validity), **Block D**
  (representativeness) and **Block H** (temporal stability). These operate on published
  marginals and summary statistics rather than record-level data, and run to the reported values
  from the configuration files alone.
- The cohort attrition ladder, the intake conformance gates, and every pre-registered threshold
  check that is a function of published counts.

Command: `kythera-validate verify --n 20000`, which fails if the code and the published tables
disagree.

### 5.2 Reproducible in structure only, against the surrogate cohort

- **Block A** (internal consistency), **Block E** (missingness) and **Block I** (predictive
  utility) require record-level data. They are executed against a surrogate cohort carrying the
  schema, missingness structure and marginal distributions of the analytic file.
- Running them demonstrates that the code is complete and correct and that each block returns
  what the tables require. It does **not** reproduce the published point estimates. The
  surrogate's parameters were set to match published marginals; they were not derived from the
  licensed file, and no output from the surrogate should be cited as a study result.

Command: `kythera-validate run --n 250000 --simulate-linkage --n-pairs 1000000`.

### 5.3 Not reproducible outside the licensed environment

- The **Block F adjudication file** and the **Block G intercoder assignments** contain protected
  health information and cannot be released under the data use agreement or under the HIPAA
  Expert Determination governing the asset.
- They are published instead as de-identified aggregate classification tables — the two-by-two
  tables by stratum and the per-category agreement tables. These are sufficient to recompute
  every accuracy statistic, interval and threshold check reported in the manuscript, and
  insufficient to reconstruct any individual record.
- The source universe itself is licensed. Investigators with an executed agreement can obtain
  the analytic specification from the author and reproduce the full pipeline in the licensed
  environment.

### 5.4 Fixed seeds and named streams

Every run is determined by a single seed, 20250731, and every stochastic step derives its own
stream from that seed and a purpose string. A run therefore reproduces exactly while no two
streams coincide. The independence of every named stream is asserted by a test.
