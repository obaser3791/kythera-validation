# Changelog

Notable changes to this repository. Versions follow the manuscript: 1.x accompanied the original
submission, 2.0.0 accompanies the revision.

## 2.0.0 — 2026-08-24

Revision submitted to *BMC Medical Research Methodology*. Every change below answers a specific
reviewer point or a defect found while answering one.

### Added

- **Blocks H and I.** Temporal stability by Mann-Kendall and CUSUM, with the minimum detectable
  Kendall tau reported alongside the observed value, so a null trend is interpretable rather
  than merely unrejected. Predictive utility with three validation schemes - random split,
  temporal holdout, and leave-one-region-out - reporting discrimination, calibration slope and
  intercept, and the Brier score together.
- **Derived linkage thresholds.** The upper and lower Fellegi-Sunter cut-offs are now derived
  from the weight distribution subject to the pre-registered false-match constraint, and the
  full threshold curve is reported, rather than the operating point being asserted.
- **A minimum detectable effect for every null finding.** A test that fails to reject is
  reported with the effect size the design could have detected at 80% power.
- **The residual non-comparability of every claims-survey comparison.** Each condition
  definition now states what remains different after the definitions are aligned, and in which
  direction the claims estimate is expected to depart from the survey estimate.
- **Named random streams** (`rngs.py`). Every stochastic step draws from a stream derived from
  the run seed and a purpose string.
- **A test suite** of 110 tests covering the estimators, the configuration, the linkage
  machinery, the random streams, each block, and the command-line interface.
- **Five additional files** and an end-to-end reproduction notebook.
- **A stated reproducibility scope**, distinguishing what is reproducible from public inputs,
  what is reproducible in structure only against the surrogate cohort, and what cannot leave the
  licensed environment.

### Changed

- **The pre-registered thresholds now carry their provenance.** Each of the sixteen cut-offs
  records its literature source, the alternatives considered at pre-registration, and why the
  chosen value was preferred. Nine thresholds previously stated a source but no rationale.
- **Discrimination is no longer presented as evidence of data validity.** Block I states
  explicitly that a c-statistic measures the signal available for a prediction task and is not
  a validity coefficient for the asset.
- **Linkage accuracy is reported by stratum, and the weakest stratum is named.** An overall
  sensitivity can conceal a subgroup in which linkage performs poorly.
- **Intercoder agreement is reported with positive predictive value beside kappa**, because
  kappa is depressed by low prevalence at constant observed agreement.
- **Cohort attrition** is reported as a ladder in which every step names the criterion that
  produced it.
- The polychoric correlation estimator uses a Gauss-Legendre bivariate normal integral with the
  Sheppard identity and bounded least squares, replacing a derivative-free search that
  converged inconsistently at extreme thresholds.
- Block E imputation standardises the design matrix and fixes the predictor set, reducing
  runtime from about 164 seconds to about 3.5 seconds without changing the pooled estimates.

### Fixed

- **A random-stream collision.** The train-test split indicator was drawn from the same seed as
  the surrogate data. The two streams coincided, the split ceased to be independent of the
  outcome, and an apparent c-statistic moved by more than a tenth. The failure raised nothing
  and produced plausible numbers. All streams are now named and a test asserts their
  independence.
- **Lin's concordance interval at exact agreement.** The asymptotic variance divides by
  1 - rho_c squared and returned a missing value where the measures agreed exactly. It now
  returns a collapsed interval, so nothing blank propagates into a table.
- **The standardized mean difference** rejected record-level binary indicators and accepted
  only proportions. It now accepts either.
- The threshold summary now identifies each check by its position in the results - outcome,
  validation scheme and fold - so a flagged value can be located instead of appearing as an
  anonymous number.
- Two editorial defects in the manuscript: a revision-memo sentence left in the Results, and a
  reference to an additional file that does not exist.

## 1.0.0 — 2026-06

Original submission. Blocks A through G, the seventeen estimators, the intake conformance gates,
the cohort ladder and the reporting layer.
