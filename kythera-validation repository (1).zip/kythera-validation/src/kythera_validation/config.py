"""Loading of the pre-registered configuration and the reported reference values.

Every threshold, condition definition and factor specification used anywhere in the
package is read from ``config/*.yaml`` rather than written into code, so that the
pre-registered plan is a single auditable artefact and no module can quietly apply a
different cutoff from the one stated in the manuscript.
"""

from __future__ import annotations

import functools
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

PACKAGE_ROOT = Path(__file__).resolve().parent
REPO_ROOT = PACKAGE_ROOT.parents[1]
CONFIG_DIR = REPO_ROOT / "config"

_OPERATORS = {
    ">=": lambda x, t: x >= t,
    "<=": lambda x, t: x <= t,
    ">": lambda x, t: x > t,
    "<": lambda x, t: x < t,
}


@dataclass(frozen=True)
class Threshold:
    """One pre-registered acceptance criterion."""

    key: str
    block: str
    metric: str
    operator: str
    value: float
    source: str = ""
    alternatives_considered: tuple[float, ...] = ()
    rationale: str = ""

    def passes(self, observed: float) -> bool:
        return bool(_OPERATORS[self.operator](observed, self.value))

    def verdict(self, observed: float) -> str:
        return "pass" if self.passes(observed) else "FAIL"

    def describe(self, observed: float) -> str:
        return (
            f"Block {self.block} | {self.metric}: observed {observed:.4g} "
            f"vs pre-registered {self.operator} {self.value:g} -> {self.verdict(observed)}"
        )


def _read_yaml(name: str) -> dict[str, Any]:
    path = CONFIG_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"configuration file not found: {path}")
    with path.open() as handle:
        return yaml.safe_load(handle)


@functools.lru_cache(maxsize=None)
def load_thresholds() -> dict[str, Threshold]:
    raw = _read_yaml("thresholds.yaml")
    out: dict[str, Threshold] = {}
    for key, spec in raw["thresholds"].items():
        out[key] = Threshold(
            key=key,
            block=str(spec["block"]),
            metric=str(spec["metric"]),
            operator=str(spec["operator"]),
            value=float(spec["value"]),
            source=str(spec.get("source", "")),
            alternatives_considered=tuple(spec.get("alternatives_considered", ()) or ()),
            rationale=str(spec.get("rationale", "")),
        )
    return out


@functools.lru_cache(maxsize=None)
def load_study_parameters() -> dict[str, Any]:
    return _read_yaml("thresholds.yaml")["study"]


@functools.lru_cache(maxsize=None)
def load_provenance_thresholds() -> dict[str, float]:
    return _read_yaml("thresholds.yaml")["provenance_thresholds"]


@functools.lru_cache(maxsize=None)
def load_conditions() -> dict[str, Any]:
    return _read_yaml("conditions.yaml")


@functools.lru_cache(maxsize=None)
def load_cfa_model() -> dict[str, Any]:
    return _read_yaml("cfa_model.yaml")


@functools.lru_cache(maxsize=None)
def load_reported_values() -> dict[str, Any]:
    """Values as printed in the manuscript, used by the test suite as fixed targets."""
    return _read_yaml("reported_values.yaml")


def thresholds_for_block(block: str) -> dict[str, Threshold]:
    return {k: t for k, t in load_thresholds().items() if t.block.upper() == block.upper()}


def check(key: str, observed: float) -> dict[str, Any]:
    """Evaluate one observed statistic against its pre-registered threshold."""
    t = load_thresholds()[key]
    return {
        "key": key,
        "block": t.block,
        "metric": t.metric,
        "observed": float(observed),
        "operator": t.operator,
        "threshold": t.value,
        "passes": t.passes(observed),
        "source": t.source,
    }
