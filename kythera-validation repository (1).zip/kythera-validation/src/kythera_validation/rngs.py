"""Independent random streams derived from one run seed.

One seed per run is what makes a run reproducible. One seed used for two purposes is a defect,
because the two streams then coincide: if the train-test split indicator is drawn from the same
seed as the data, the split is no longer independent of the outcome. That is not a hypothetical
- during development, reusing a single seed this way moved an apparent c-statistic by more than
a tenth, in the flattering direction for some outcomes and the unflattering direction for
others.

Every stochastic step in this package therefore asks for a stream by name. The run seed still
determines everything, so a run reproduces exactly, but no two named streams are the same
sequence.
"""

from __future__ import annotations

import zlib

import numpy as np

DEFAULT_SEED = 20250731


def stream(seed: int, purpose: str) -> np.random.Generator:
    """Return the generator for one named purpose under a given run seed."""
    if not purpose:
        raise ValueError("a purpose string is required; an unnamed stream defeats the point")
    spawn_key = (zlib.crc32(purpose.encode("utf-8")),)
    return np.random.default_rng(np.random.SeedSequence(entropy=int(seed), spawn_key=spawn_key))


def streams(seed: int, *purposes: str) -> tuple[np.random.Generator, ...]:
    """Return several independent named streams at once."""
    return tuple(stream(seed, purpose) for purpose in purposes)


def are_independent(seed: int, first: str, second: str, *, n: int = 4096) -> bool:
    """Check that two named streams are not the same sequence.

    A test in the suite calls this. It is cheap, and a silent stream collision is the kind of
    defect that produces plausible numbers rather than an error.
    """
    a = stream(seed, first).random(n)
    b = stream(seed, second).random(n)
    return bool(not np.allclose(a, b) and abs(float(np.corrcoef(a, b)[0, 1])) < 0.1)
