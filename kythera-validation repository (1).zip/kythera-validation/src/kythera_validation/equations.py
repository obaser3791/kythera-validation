"""The seventeen pre-registered estimating equations (Eq. 1 - Eq. 17).

Each function corresponds one-to-one with a numbered equation in Additional file 1 and is
the single implementation used by the block modules, so no block re-derives an estimator
locally. Every function is pure, takes arrays or scalars, and returns either a float or a
small dataclass; nothing here touches the file system, the configuration, or the data
layer. That separation is what makes the equations independently testable, and the test
suite in ``tests/test_equations.py`` checks each one against a closed-form or published
worked example rather than against the output of this code.

Notation follows the manuscript: ``n`` is the number of units, ``k`` the number of items,
``x`` an observed vector, ``p`` a proportion, and ``z`` the standard normal deviate for a
two-sided 95 per cent interval (1.959964).

Nothing in this module knows about the Kythera asset specifically. The equations are
generic and would apply to any claims resource evaluated under the same framework.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy import linalg, stats

Z95 = float(stats.norm.ppf(0.975))

__all__ = [
    "Z95",
    "Interval",
    "ConfusionMatrix",
    "FitIndices",
    "cronbach_alpha",              # Eq. 1
    "icc_two_way_random",          # Eq. 2
    "mape",                        # Eq. 3
    "lins_ccc",                    # Eq. 4
    "standardized_mean_difference",  # Eq. 5
    "raking_weights",              # Eq. 6
    "sem_fit_indices",             # Eq. 7
    "littles_mcar_test",           # Eq. 8
    "rubin_pool",                  # Eq. 9
    "fellegi_sunter_weight",       # Eq. 10
    "match_rate",                  # Eq. 11
    "linkage_accuracy",            # Eq. 12
    "cohens_kappa",                # Eq. 13
    "mann_kendall",                # Eq. 14
    "cusum",                       # Eq. 15
    "auroc",                       # Eq. 16
    "brier_and_calibration",       # Eq. 17
    "wilson_interval",
    "fisher_z_interval",
]


# --------------------------------------------------------------------------------------
# Small return types
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Interval:
    """A point estimate with a two-sided 95 per cent interval."""

    estimate: float
    lower: float
    upper: float

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.estimate, self.lower, self.upper)

    def __str__(self) -> str:  # pragma: no cover - presentation only
        return f"{self.estimate:.3f} ({self.lower:.3f}-{self.upper:.3f})"


@dataclass(frozen=True)
class ConfusionMatrix:
    tp: int
    fp: int
    fn: int
    tn: int

    @property
    def n(self) -> int:
        return self.tp + self.fp + self.fn + self.tn


@dataclass
class FitIndices:
    chisq: float
    df: int
    cfi: float
    tli: float
    rmsea: float
    rmsea_ci: tuple[float, float]
    srmr: float
    baseline_chisq: float = field(default=float("nan"))
    baseline_df: int = field(default=0)

    @property
    def chisq_over_df(self) -> float:
        return self.chisq / self.df if self.df else float("nan")


# --------------------------------------------------------------------------------------
# Interval helpers used by several equations
# --------------------------------------------------------------------------------------
def wilson_interval(successes: int, n: int, z: float = Z95) -> tuple[float, float]:
    """Wilson score interval for a binomial proportion.

    Preferred to the Wald interval throughout, because several linkage strata have
    proportions close to one where the Wald interval overshoots the parameter space.
    """
    if n <= 0:
        return (float("nan"), float("nan"))
    p = successes / n
    denom = 1.0 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def fisher_z_interval(r: float, n: int, z: float = Z95) -> tuple[float, float]:
    """Interval for a correlation-type statistic via the Fisher z transformation."""
    if n <= 3 or abs(r) >= 1:
        return (float("nan"), float("nan"))
    zeta = np.arctanh(r)
    se = 1.0 / np.sqrt(n - 3)
    return (float(np.tanh(zeta - z * se)), float(np.tanh(zeta + z * se)))


# --------------------------------------------------------------------------------------
# Eq. 1 - Cronbach's alpha (Block A)
# --------------------------------------------------------------------------------------
def cronbach_alpha(items: np.ndarray, ci: bool = True) -> Interval:
    r"""Cronbach's alpha for a person-by-item matrix.

    .. math::
        \alpha = \frac{k}{k-1}\left(1 - \frac{\sum_{j=1}^{k} s_j^2}{s_T^2}\right)

    ``items`` is ``n x k`` with one row per patient and one column per component
    indicator of the composite index. The interval is the Feldt exact interval based on
    the F distribution, which is preferred over a normal approximation because several
    indices here have a small number of components.

    Alpha is a lower bound on reliability under essential tau-equivalence, and for
    binary comorbidity flags it behaves as the Kuder-Richardson formula 20 coefficient.
    It is reported as evidence about the internal coherence of a derived index, not
    about the accuracy of any individual recorded diagnosis.
    """
    x = np.asarray(items, dtype=float)
    if x.ndim != 2:
        raise ValueError("items must be a two-dimensional person-by-item array")
    n, k = x.shape
    if k < 2:
        raise ValueError("Cronbach's alpha requires at least two items")
    item_var = x.var(axis=0, ddof=1).sum()
    total_var = x.sum(axis=1).var(ddof=1)
    if total_var <= 0:
        raise ValueError("total score has zero variance; alpha is undefined")
    alpha = (k / (k - 1.0)) * (1.0 - item_var / total_var)
    if not ci:
        return Interval(float(alpha), float("nan"), float("nan"))
    df1, df2 = n - 1, (n - 1) * (k - 1)
    lo = 1.0 - (1.0 - alpha) * stats.f.ppf(0.975, df1, df2)
    hi = 1.0 - (1.0 - alpha) * stats.f.ppf(0.025, df1, df2)
    return Interval(float(alpha), float(lo), float(hi))


# --------------------------------------------------------------------------------------
# Eq. 2 - Two-way random-effects intraclass correlation, ICC(2,1) (Block A)
# --------------------------------------------------------------------------------------
def icc_two_way_random(ratings: np.ndarray, ci: bool = True) -> Interval:
    r"""ICC(2,1) for repeated measurement of the same subjects.

    .. math::
        \mathrm{ICC}(2,1) = \frac{MS_R - MS_E}
        {MS_R + (m-1)MS_E + \frac{m}{n}\,(MS_C - MS_E)}

    ``ratings`` is ``n x m`` with one row per patient and one column per occasion; here
    the occasions are two non-overlapping twelve-month windows, so the statistic is a
    test-retest coefficient. Both subject and occasion effects are treated as random,
    which is the correct model when the windows are exchangeable draws from the study
    period rather than fixed conditions of interest.
    """
    x = np.asarray(ratings, dtype=float)
    if x.ndim != 2 or x.shape[1] < 2:
        raise ValueError("ratings must be n x m with m >= 2")
    n, m = x.shape
    grand = x.mean()
    ms_rows = m * ((x.mean(axis=1) - grand) ** 2).sum() / (n - 1)
    ms_cols = n * ((x.mean(axis=0) - grand) ** 2).sum() / (m - 1)
    resid = x - x.mean(axis=1, keepdims=True) - x.mean(axis=0, keepdims=True) + grand
    ms_err = (resid**2).sum() / ((n - 1) * (m - 1))
    denom = ms_rows + (m - 1) * ms_err + (m / n) * (ms_cols - ms_err)
    icc = (ms_rows - ms_err) / denom if denom != 0 else float("nan")
    if not ci:
        return Interval(float(icc), float("nan"), float("nan"))
    f_obs = ms_rows / ms_err if ms_err > 0 else float("inf")
    df1, df2 = n - 1, (n - 1) * (m - 1)
    fl = f_obs / stats.f.ppf(0.975, df1, df2)
    fu = f_obs / stats.f.ppf(0.025, df1, df2)
    lo = (fl - 1.0) / (fl + (m - 1))
    hi = (fu - 1.0) / (fu + (m - 1))
    return Interval(float(icc), float(max(-1.0, lo)), float(min(1.0, hi)))


# --------------------------------------------------------------------------------------
# Eq. 3 - Mean absolute percentage error (Block B)
# --------------------------------------------------------------------------------------
def mape(observed: np.ndarray, reference: np.ndarray) -> float:
    r"""Mean absolute percentage error against an external benchmark.

    .. math::
        \mathrm{MAPE} = \frac{1}{J}\sum_{j=1}^{J}
        \left|\frac{\hat\theta_j - \theta_j^{\mathrm{ref}}}{\theta_j^{\mathrm{ref}}}\right|

    Returned as a proportion, not a percentage. The reference values are survey
    estimates carrying their own sampling and self-report error, so MAPE measures
    external consistency between two imperfect measurement systems and is not a bias
    estimate against a gold standard.
    """
    obs = np.asarray(observed, dtype=float)
    ref = np.asarray(reference, dtype=float)
    if obs.shape != ref.shape:
        raise ValueError("observed and reference must have the same shape")
    if np.any(ref == 0):
        raise ValueError("reference values must be non-zero for a percentage error")
    return float(np.mean(np.abs((obs - ref) / ref)))


# --------------------------------------------------------------------------------------
# Eq. 4 - Lin's concordance correlation coefficient (Block B)
# --------------------------------------------------------------------------------------
def lins_ccc(x: np.ndarray, y: np.ndarray, ci: bool = True) -> Interval:
    r"""Lin's concordance correlation coefficient.

    .. math::
        \rho_c = \frac{2\,s_{xy}}{s_x^2 + s_y^2 + (\bar x - \bar y)^2}

    Unlike Pearson's correlation, this penalises departure from the 45-degree line, so a
    resource that tracks the shape of the benchmark but sits systematically above it is
    correctly scored down. The interval uses the Fisher z transformation of the
    coefficient with Lin's asymptotic variance.
    """
    a = np.asarray(x, dtype=float)
    b = np.asarray(y, dtype=float)
    if a.shape != b.shape or a.size < 3:
        raise ValueError("x and y must have identical shape and at least three elements")
    n = a.size
    ma, mb = a.mean(), b.mean()
    va = a.var(ddof=0)
    vb = b.var(ddof=0)
    cov = ((a - ma) * (b - mb)).mean()
    denom = va + vb + (ma - mb) ** 2
    ccc = 2 * cov / denom if denom > 0 else float("nan")
    if not ci:
        return Interval(float(ccc), float("nan"), float("nan"))
    pearson = cov / np.sqrt(va * vb) if va > 0 and vb > 0 else float("nan")
    if not np.isfinite(pearson) or abs(ccc) >= 1 - 1e-12 or abs(pearson) < 1e-12:
        # Exact agreement, or a degenerate margin: Lin's asymptotic variance is undefined
        # there because it divides by 1 - rho_c^2. Returning the point estimate with a
        # degenerate interval is the honest answer; a silent nan would propagate into tables.
        return Interval(float(ccc), float(ccc), float(ccc))
    u = (ma - mb) / np.sqrt(np.sqrt(va * vb)) if va > 0 and vb > 0 else float("nan")
    var_z = (
        (1 - pearson**2) * ccc**2 / ((1 - ccc**2) * pearson**2)
        + 2 * ccc**3 * (1 - ccc) * u**2 / (pearson * (1 - ccc**2) ** 2)
        - ccc**4 * u**4 / (2 * pearson**2 * (1 - ccc**2) ** 2)
    ) / (n - 2)
    se_z = np.sqrt(max(var_z, 0.0))
    zeta = np.arctanh(ccc)
    return Interval(
        float(ccc), float(np.tanh(zeta - Z95 * se_z)), float(np.tanh(zeta + Z95 * se_z))
    )


# --------------------------------------------------------------------------------------
# Eq. 5 - Standardized mean difference (Blocks A, D and the generalisability appraisal)
# --------------------------------------------------------------------------------------
def standardized_mean_difference(
    x: np.ndarray | float,
    y: np.ndarray | float,
    *,
    binary: bool = False,
    sd_x: float | None = None,
    sd_y: float | None = None,
) -> float:
    r"""Absolute standardized mean difference between two groups.

    For continuous measures,

    .. math::
        d = \frac{\bar x - \bar y}{\sqrt{(s_x^2 + s_y^2)/2}}

    and for a binary measure with proportions :math:`p_x, p_y`,

    .. math::
        d = \frac{p_x - p_y}{\sqrt{[p_x(1-p_x) + p_y(1-p_y)]/2}}.

    Summary statistics may be supplied directly through ``sd_x`` and ``sd_y``, which is
    how Table 6 is computed from published marginals rather than from record-level data.
    The sign is discarded: the pre-registered threshold is on the absolute value.
    """
    if binary:
        # Accept either proportions or record-level 0/1 indicators.
        px = float(np.asarray(x, dtype=float).mean())
        py = float(np.asarray(y, dtype=float).mean())
        pooled = np.sqrt((px * (1 - px) + py * (1 - py)) / 2.0)
        return float("nan") if pooled == 0 else float(abs(px - py) / pooled)
    if sd_x is not None and sd_y is not None:
        mx, my = float(x), float(y)
        pooled = np.sqrt((sd_x**2 + sd_y**2) / 2.0)
        return float("nan") if pooled == 0 else float(abs(mx - my) / pooled)
    a = np.asarray(x, dtype=float)
    b = np.asarray(y, dtype=float)
    pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2.0)
    return float("nan") if pooled == 0 else float(abs(a.mean() - b.mean()) / pooled)


# --------------------------------------------------------------------------------------
# Eq. 6 - Raking to external margins (Block D)
# --------------------------------------------------------------------------------------
def raking_weights(
    design: np.ndarray,
    targets: list[np.ndarray],
    *,
    max_iter: int = 200,
    tol: float = 1e-10,
    trim: tuple[float, float] | None = (0.2, 5.0),
) -> np.ndarray:
    r"""Iterative proportional fitting of unit weights to external margins.

    At iteration :math:`t` and for margin :math:`m`,

    .. math::
        w_i^{(t+1)} = w_i^{(t)} \cdot
        \frac{T_{m,c(i)}}{\sum_{j: c(j)=c(i)} w_j^{(t)}}

    ``design`` is ``n x M`` of integer category codes, one column per raking margin, and
    ``targets`` is a list of ``M`` arrays of target population shares summing to one.
    Weights are trimmed to the supplied bounds after convergence and renormalised, which
    caps the influence of any single small cell; the manuscript reports the untrimmed
    and trimmed weighted estimates side by side so the effect of trimming is visible.
    """
    codes = np.asarray(design)
    if codes.ndim != 2 or codes.shape[1] != len(targets):
        raise ValueError("design must be n x M with one target vector per column")
    n = codes.shape[0]
    w = np.ones(n, dtype=float)
    for _ in range(max_iter):
        w_prev = w.copy()
        for m, target in enumerate(targets):
            t = np.asarray(target, dtype=float)
            t = t / t.sum()
            col = codes[:, m]
            for c in range(t.size):
                mask = col == c
                current = w[mask].sum()
                if current > 0:
                    w[mask] *= (t[c] * n) / current
        if np.max(np.abs(w - w_prev)) < tol:
            break
    if trim is not None:
        lo, hi = trim
        w = np.clip(w, lo, hi)
    return w * (n / w.sum())


# --------------------------------------------------------------------------------------
# Eq. 7 - Structural-equation fit indices (Block C)
# --------------------------------------------------------------------------------------
def sem_fit_indices(
    observed: np.ndarray,
    implied: np.ndarray,
    n: int,
    n_params: int,
    *,
    structure: str = "covariance",
) -> FitIndices:
    r"""Global fit of a covariance-structure model.

    The maximum-likelihood discrepancy is

    .. math::
        F = \log|\Sigma(\hat\theta)| - \log|S|
            + \mathrm{tr}\!\left(S\,\Sigma(\hat\theta)^{-1}\right) - p,
        \qquad \chi^2 = (n-1)F,

    from which

    .. math::
        \mathrm{RMSEA} = \sqrt{\frac{\max(\chi^2 - df,\,0)}{df\,(n-1)}}, \qquad
        \mathrm{CFI} = 1 - \frac{\max(\chi^2 - df,\,0)}{\max(\chi^2_B - df_B,\,0)},

    with the independence model as the baseline :math:`B`, and

    .. math::
        \mathrm{SRMR} = \sqrt{\frac{2}{p(p+1)}
        \sum_{i \le j}\left(\frac{s_{ij} - \sigma_{ij}}
        {\sqrt{s_{ii}s_{jj}}}\right)^2}.

    At the sample sizes used here the chi-square statistic is not interpretable as a
    test, which is why it is reported only as a ratio to its degrees of freedom and the
    conclusion rests on the incremental and absolute indices together with the nested
    comparison.
    """
    s = np.asarray(observed, dtype=float)
    sigma = np.asarray(implied, dtype=float)
    p = s.shape[0]
    if s.shape != sigma.shape or s.shape[0] != s.shape[1]:
        raise ValueError("observed and implied must be square matrices of equal shape")
    # A model fitted to a correlation matrix has p(p-1)/2 non-redundant elements, because
    # the unit diagonal is fixed rather than estimated; a covariance model has p(p+1)/2.
    if structure == "correlation":
        df = p * (p - 1) // 2 - n_params
    elif structure == "covariance":
        df = p * (p + 1) // 2 - n_params
    else:
        raise ValueError("structure must be 'correlation' or 'covariance'")
    if df <= 0:
        raise ValueError("model is not over-identified; df must be positive")

    def discrepancy(target: np.ndarray) -> float:
        sign_t, logdet_t = np.linalg.slogdet(target)
        sign_s, logdet_s = np.linalg.slogdet(s)
        if sign_t <= 0 or sign_s <= 0:
            raise ValueError("matrices must be positive definite")
        return float(logdet_t - logdet_s + np.trace(s @ linalg.inv(target)) - p)

    chisq = (n - 1) * discrepancy(sigma)
    baseline = np.diag(np.diag(s))
    baseline_chisq = (n - 1) * discrepancy(baseline)
    baseline_df = p * (p - 1) // 2

    d_model = max(chisq - df, 0.0)
    d_base = max(baseline_chisq - baseline_df, 0.0)
    cfi = 1.0 - d_model / d_base if d_base > 0 else 1.0
    tli_num = baseline_chisq / baseline_df - chisq / df
    tli_den = baseline_chisq / baseline_df - 1.0
    tli = tli_num / tli_den if tli_den != 0 else float("nan")
    rmsea = np.sqrt(d_model / (df * (n - 1)))

    # Ninety per cent interval for RMSEA by inverting the non-central chi-square.
    def _ncp_bound(q: float) -> float:
        lo, hi = 0.0, max(chisq * 4.0, 1.0)
        for _ in range(200):
            mid = (lo + hi) / 2
            if stats.ncx2.cdf(chisq, df, mid) > q:
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2

    lam_u = _ncp_bound(0.05)
    lam_l = _ncp_bound(0.95)
    rmsea_ci = (
        float(np.sqrt(max(lam_l, 0.0) / (df * (n - 1)))),
        float(np.sqrt(max(lam_u, 0.0) / (df * (n - 1)))),
    )

    sd = np.sqrt(np.diag(s))
    scale = np.outer(sd, sd)
    resid = (s - sigma) / scale
    iu = np.triu_indices(p)
    srmr = float(np.sqrt((resid[iu] ** 2).sum() * 2.0 / (p * (p + 1))))

    return FitIndices(
        chisq=float(chisq),
        df=int(df),
        cfi=float(min(max(cfi, 0.0), 1.0)),
        tli=float(min(max(tli, 0.0), 1.0)),
        rmsea=float(rmsea),
        rmsea_ci=rmsea_ci,
        srmr=srmr,
        baseline_chisq=float(baseline_chisq),
        baseline_df=int(baseline_df),
    )


# --------------------------------------------------------------------------------------
# Eq. 8 - Little's test of the missing-completely-at-random hypothesis (Block E)
# --------------------------------------------------------------------------------------
def littles_mcar_test(frame: np.ndarray) -> dict[str, float]:
    r"""Little's likelihood-ratio test for MCAR.

    .. math::
        d^2 = \sum_{j=1}^{J} n_j\,
        (\bar y_j - \hat\mu_j)^{\top}\hat\Sigma_j^{-1}(\bar y_j - \hat\mu_j)
        \;\sim\; \chi^2_{\sum_j p_j - p}

    where :math:`j` indexes the distinct missingness patterns, :math:`\bar y_j` the
    observed-variable means within pattern :math:`j`, and :math:`\hat\mu, \hat\Sigma`
    the maximum-likelihood estimates from the expectation-maximisation fit to all cases.

    Returns the statistic, its degrees of freedom, the p-value and the number of distinct
    missingness patterns contributing to it. At the sample sizes used here the test rejects
    on trivial departures, so it is reported for completeness and the substantive
    argument rests on the pattern of missingness by variable origin and on the fraction
    of missing information, not on this p-value.
    """
    y = np.asarray(frame, dtype=float)
    if y.ndim != 2:
        raise ValueError("frame must be two-dimensional")
    n, p = y.shape
    observed = ~np.isnan(y)

    # Rows are grouped by missingness pattern once, and every subsequent operation works on
    # patterns rather than rows. There are at most a few hundred distinct patterns however
    # many millions of rows there are, so the expectation-maximisation fit and the test
    # statistic both cost time in the number of patterns and not in the sample size.
    codes = np.packbits(observed, axis=1)
    _, pattern_index, inverse = np.unique(codes, axis=0, return_index=True, return_inverse=True)
    inverse = inverse.ravel()
    pattern_masks = observed[pattern_index]
    pattern_rows = [np.flatnonzero(inverse == k) for k in range(pattern_masks.shape[0])]

    # Expectation-maximisation for the mean vector and covariance under normality.
    mu = np.nanmean(y, axis=0)
    sigma = np.ma.cov(np.ma.masked_invalid(y), rowvar=False).filled(np.nan)
    sigma = np.where(np.isnan(sigma), 0.0, sigma)
    sigma += np.eye(p) * 1e-8
    filled = np.zeros_like(y)
    for _ in range(100):
        mu_old, sigma_old = mu.copy(), sigma.copy()
        correction = np.zeros((p, p))
        for mask, rows in zip(pattern_masks, pattern_rows, strict=True):
            if rows.size == 0:
                continue
            o = mask
            m = ~mask
            block = y[rows]
            if not o.any():
                filled[rows] = mu
                correction += sigma * rows.size
                continue
            filled[np.ix_(rows, np.where(o)[0])] = block[:, o]
            if m.any():
                s_oo = sigma[np.ix_(o, o)]
                s_mo = sigma[np.ix_(m, o)]
                beta = s_mo @ linalg.pinv(s_oo)
                filled[np.ix_(rows, np.where(m)[0])] = mu[m] + (block[:, o] - mu[o]) @ beta.T
                resid = sigma[np.ix_(m, m)] - beta @ sigma[np.ix_(o, m)]
                idx = np.where(m)[0]
                correction[np.ix_(idx, idx)] += resid * rows.size
        mu = filled.mean(axis=0)
        centred = filled - mu
        sigma = (centred.T @ centred + correction) / n
        sigma += np.eye(p) * 1e-10
        if np.max(np.abs(mu - mu_old)) < 1e-8 and np.max(np.abs(sigma - sigma_old)) < 1e-8:
            break

    d2 = 0.0
    total_pj = 0
    n_patterns = 0
    for mask, rows in zip(pattern_masks, pattern_rows, strict=True):
        pj = int(mask.sum())
        if pj == 0 or rows.size == 0:
            continue
        n_patterns += 1
        total_pj += pj
        ybar = y[np.ix_(rows, np.where(mask)[0])].mean(axis=0)
        diff = ybar - mu[mask]
        s_jj = sigma[np.ix_(mask, mask)]
        d2 += rows.size * float(diff @ linalg.pinv(s_jj) @ diff)

    df = max(total_pj - p, 1)
    return {
        "chisq": float(d2),
        "df": int(df),
        "p_value": float(stats.chi2.sf(d2, df)),
        "n_patterns": int(n_patterns),
    }


# --------------------------------------------------------------------------------------
# Eq. 9 - Rubin's rules and the fraction of missing information (Block E)
# --------------------------------------------------------------------------------------
def rubin_pool(estimates: np.ndarray, variances: np.ndarray) -> dict[str, float]:
    r"""Pool multiply imputed estimates and return the fraction of missing information.

    .. math::
        \bar Q = \frac{1}{m}\sum_{l=1}^{m} \hat Q_l, \qquad
        \bar U = \frac{1}{m}\sum_{l=1}^{m} U_l, \qquad
        B = \frac{1}{m-1}\sum_{l=1}^{m}(\hat Q_l - \bar Q)^2,

    .. math::
        T = \bar U + \left(1 + \frac{1}{m}\right)B, \qquad
        \lambda = \frac{(1 + 1/m)B}{T}, \qquad
        \mathrm{FMI} = \frac{\lambda + 2/(\nu + 3)}{1 + \lambda}

    with Barnard-Rubin degrees of freedom. The pre-registered threshold in Block E is on
    the pooled FMI, which is the quantity that governs how much information the
    imputation model had to supply.
    """
    q = np.asarray(estimates, dtype=float)
    u = np.asarray(variances, dtype=float)
    if q.shape != u.shape or q.size < 2:
        raise ValueError("estimates and variances must match and have m >= 2")
    m = q.size
    qbar = float(q.mean())
    ubar = float(u.mean())
    b = float(q.var(ddof=1))
    t = ubar + (1 + 1 / m) * b
    lam = ((1 + 1 / m) * b) / t if t > 0 else 0.0
    nu_old = (m - 1) / lam**2 if lam > 0 else np.inf
    fmi = (lam + 2 / (nu_old + 3)) / (1 + lam) if np.isfinite(nu_old) else lam
    se = np.sqrt(t)
    return {
        "estimate": qbar,
        "within_variance": ubar,
        "between_variance": b,
        "total_variance": float(t),
        "se": float(se),
        "df": float(nu_old),
        "lambda": float(lam),
        "fmi": float(fmi),
        "ci_lower": float(qbar - Z95 * se),
        "ci_upper": float(qbar + Z95 * se),
    }


# --------------------------------------------------------------------------------------
# Eq. 10 - Fellegi-Sunter agreement weight (Block F)
# --------------------------------------------------------------------------------------
def fellegi_sunter_weight(
    agreement: np.ndarray,
    m_probs: np.ndarray,
    u_probs: np.ndarray,
) -> np.ndarray:
    r"""Log-likelihood-ratio match weight for a candidate record pair.

    .. math::
        w = \sum_{f=1}^{F}
        \left[\gamma_f \log_2 \frac{m_f}{u_f}
        + (1-\gamma_f)\log_2 \frac{1-m_f}{1-u_f}\right]

    where :math:`\gamma_f` indicates field-level agreement, :math:`m_f` is the
    probability of agreement given a true match and :math:`u_f` the probability of
    agreement given a non-match. Conditional independence across fields is assumed, and
    that assumption is the reason the false-match rate is also verified against blinded
    adjudication rather than read off the model.
    """
    gamma = np.asarray(agreement, dtype=float)
    m = np.asarray(m_probs, dtype=float)
    u = np.asarray(u_probs, dtype=float)
    if not (m.shape == u.shape == gamma.shape[-1:]):
        raise ValueError("m_probs and u_probs must match the field dimension of agreement")
    if np.any((m <= 0) | (m >= 1) | (u <= 0) | (u >= 1)):
        raise ValueError("m and u probabilities must lie strictly inside (0, 1)")
    agree_w = np.log2(m / u)
    disagree_w = np.log2((1 - m) / (1 - u))
    return np.asarray(gamma @ agree_w + (1 - gamma) @ disagree_w, dtype=float)


# --------------------------------------------------------------------------------------
# Eq. 11 - Match rate (Block F)
# --------------------------------------------------------------------------------------
def match_rate(linked: int, eligible: int) -> Interval:
    r"""Proportion of eligible records that resolve to a linked entity.

    .. math::
        \mathrm{MR} = \frac{\#\{\text{records linked}\}}{\#\{\text{records eligible}\}}

    Reported with a Wilson interval. A high match rate is a coverage statement and says
    nothing on its own about whether the links are correct, which is why it is always
    reported alongside Eq. 12.
    """
    if eligible <= 0:
        raise ValueError("eligible must be positive")
    if not 0 <= linked <= eligible:
        raise ValueError("linked must lie between zero and eligible")
    lo, hi = wilson_interval(linked, eligible)
    return Interval(linked / eligible, lo, hi)


# --------------------------------------------------------------------------------------
# Eq. 12 - Linkage accuracy against blinded adjudication (Block F)
# --------------------------------------------------------------------------------------
def linkage_accuracy(cm: ConfusionMatrix) -> dict[str, Interval | float]:
    r"""Sensitivity, specificity, predictive values and the false-match rate.

    .. math::
        \mathrm{Se} = \frac{TP}{TP+FN}, \quad
        \mathrm{Sp} = \frac{TN}{TN+FP}, \quad
        \mathrm{PPV} = \frac{TP}{TP+FP}, \quad
        \mathrm{NPV} = \frac{TN}{TN+FN},

    .. math::
        \mathrm{FMR} = \frac{FP}{TP+FP} = 1 - \mathrm{PPV}.

    The false-match rate is defined on accepted links, not on all candidate pairs, so it
    answers the question an analyst actually faces: given that a link was accepted, how
    often is it wrong. Because the adjudication frame is enriched relative to the
    production candidate set, predictive values apply to that frame and are not
    transportable to a different match-prevalence setting without re-weighting.
    """
    se_lo, se_hi = wilson_interval(cm.tp, cm.tp + cm.fn)
    sp_lo, sp_hi = wilson_interval(cm.tn, cm.tn + cm.fp)
    ppv_lo, ppv_hi = wilson_interval(cm.tp, cm.tp + cm.fp)
    npv_lo, npv_hi = wilson_interval(cm.tn, cm.tn + cm.fn)
    fmr_lo, fmr_hi = wilson_interval(cm.fp, cm.tp + cm.fp)
    return {
        "sensitivity": Interval(cm.tp / (cm.tp + cm.fn), se_lo, se_hi),
        "specificity": Interval(cm.tn / (cm.tn + cm.fp), sp_lo, sp_hi),
        "ppv": Interval(cm.tp / (cm.tp + cm.fp), ppv_lo, ppv_hi),
        "npv": Interval(cm.tn / (cm.tn + cm.fn), npv_lo, npv_hi),
        "false_match_rate": Interval(cm.fp / (cm.tp + cm.fp), fmr_lo, fmr_hi),
        "prevalence": (cm.tp + cm.fn) / cm.n,
    }


# --------------------------------------------------------------------------------------
# Eq. 13 - Cohen's kappa (Blocks A and G)
# --------------------------------------------------------------------------------------
def cohens_kappa(
    table: np.ndarray,
    *,
    weights: str | None = None,
    ci: bool = True,
) -> Interval:
    r"""Chance-corrected agreement between two raters.

    .. math::
        \kappa = \frac{p_o - p_e}{1 - p_e}, \qquad
        p_o = \sum_i p_{ii}, \qquad p_e = \sum_i p_{i\cdot}p_{\cdot i}

    ``weights`` may be ``None`` for unweighted agreement, ``"linear"`` or
    ``"quadratic"`` for ordinal categories. The interval uses the standard delta-method
    variance. Kappa depends on the marginal prevalence of each category, so a low value
    in a rare category reflects the base rate as much as the coding, which is why
    positive predictive value is reported next to it in Table 15.
    """
    t = np.asarray(table, dtype=float)
    if t.ndim != 2 or t.shape[0] != t.shape[1]:
        raise ValueError("table must be a square contingency matrix")
    n = t.sum()
    if n <= 0:
        raise ValueError("contingency table is empty")
    p = t / n
    row = p.sum(axis=1)
    col = p.sum(axis=0)
    k = t.shape[0]
    if weights is None:
        w = 1.0 - np.eye(k)
    else:
        i, j = np.indices((k, k))
        if weights == "linear":
            w = np.abs(i - j) / (k - 1)
        elif weights == "quadratic":
            w = ((i - j) / (k - 1)) ** 2
        else:
            raise ValueError("weights must be None, 'linear' or 'quadratic'")
    po = 1.0 - float((w * p).sum())
    pe = 1.0 - float((w * np.outer(row, col)).sum())
    kappa = (po - pe) / (1.0 - pe) if pe < 1 else float("nan")
    if not ci:
        return Interval(float(kappa), float("nan"), float("nan"))
    wbar_r = (w * col[None, :]).sum(axis=1)
    wbar_c = (w * row[:, None]).sum(axis=0)
    term = sum(
        p[i, j] * (w[i, j] - (wbar_r[i] + wbar_c[j]) * (1 - kappa)) ** 2
        for i in range(k)
        for j in range(k)
    )
    var = (term - (pe - (1 - pe) * kappa) ** 2) / (n * (1 - pe) ** 2)
    se = np.sqrt(max(var, 0.0))
    return Interval(float(kappa), float(kappa - Z95 * se), float(kappa + Z95 * se))


# --------------------------------------------------------------------------------------
# Eq. 14 - Mann-Kendall trend test (Block H)
# --------------------------------------------------------------------------------------
def mann_kendall(series: np.ndarray) -> dict[str, float]:
    r"""Non-parametric test for monotone trend in a short quarterly series.

    .. math::
        S = \sum_{i<j}\mathrm{sgn}(x_j - x_i), \qquad
        \tau = \frac{2S}{n(n-1)},

    .. math::
        \mathrm{Var}(S) = \frac{n(n-1)(2n+5) - \sum_g t_g(t_g-1)(2t_g+5)}{18},
        \qquad Z = \frac{S - \mathrm{sgn}(S)}{\sqrt{\mathrm{Var}(S)}}

    with the tie correction over groups of equal values. Distribution-free, which suits a
    14-point series of standardised residuals where normality cannot be assessed.
    """
    x = np.asarray(series, dtype=float)
    n = x.size
    if n < 4:
        raise ValueError("Mann-Kendall requires at least four observations")
    s = float(sum(np.sign(x[j] - x[i]) for i in range(n - 1) for j in range(i + 1, n)))
    tau = 2.0 * s / (n * (n - 1))
    _, counts = np.unique(x, return_counts=True)
    tie_term = float(sum(c * (c - 1) * (2 * c + 5) for c in counts if c > 1))
    var_s = (n * (n - 1) * (2 * n + 5) - tie_term) / 18.0
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    return {
        "s": s,
        "tau": float(tau),
        "var_s": float(var_s),
        "z": float(z),
        "p_value": float(2 * stats.norm.sf(abs(z))),
        "n": int(n),
    }


# --------------------------------------------------------------------------------------
# Eq. 15 - Cumulative-sum structural-break detection (Block H)
# --------------------------------------------------------------------------------------
def cusum(series: np.ndarray, *, threshold: float = 5.0, drift: float = 0.5) -> dict:
    r"""Two-sided tabular CUSUM on standardised residuals.

    .. math::
        C_t^{+} = \max\!\left(0,\; C_{t-1}^{+} + z_t - k\right), \qquad
        C_t^{-} = \max\!\left(0,\; C_{t-1}^{-} - z_t - k\right)

    with a break flagged whenever either statistic exceeds the decision interval
    :math:`h`. Defaults of :math:`k = 0.5` and :math:`h = 5` give an in-control average
    run length of roughly 465 quarters for standardised input, so a flag over a 14-point
    series is not a chance excursion.
    """
    x = np.asarray(series, dtype=float)
    sd = x.std(ddof=1)
    z = (x - x.mean()) / sd if sd > 0 else np.zeros_like(x)
    cp = np.zeros(z.size)
    cn = np.zeros(z.size)
    breaks: list[int] = []
    for t in range(z.size):
        prev_p = cp[t - 1] if t else 0.0
        prev_n = cn[t - 1] if t else 0.0
        cp[t] = max(0.0, prev_p + z[t] - drift)
        cn[t] = max(0.0, prev_n - z[t] - drift)
        if cp[t] > threshold or cn[t] > threshold:
            breaks.append(t)
            cp[t] = cn[t] = 0.0
    return {
        "cusum_positive": cp,
        "cusum_negative": cn,
        "break_indices": breaks,
        "n_breaks": len(breaks),
        "threshold": threshold,
        "drift": drift,
    }


# --------------------------------------------------------------------------------------
# Eq. 16 - Area under the ROC curve with a DeLong interval (Block I)
# --------------------------------------------------------------------------------------
def auroc(y_true: np.ndarray, y_score: np.ndarray, ci: bool = True) -> Interval:
    r"""Area under the receiver-operating-characteristic curve.

    Computed as the Mann-Whitney statistic with mid-ranks for ties,

    .. math::
        \mathrm{AUROC} = \frac{\sum_{i \in D} r_i - n_D(n_D+1)/2}{n_D\,n_{\bar D}},

    and the interval from the DeLong structural components,

    .. math::
        \mathrm{Var} = \frac{s_{10}}{n_D} + \frac{s_{01}}{n_{\bar D}},

    which is the correct variance for a single curve on paired placement values and does
    not require the binormal assumption.
    """
    y = np.asarray(y_true).astype(int)
    s = np.asarray(y_score, dtype=float)
    if y.shape != s.shape:
        raise ValueError("y_true and y_score must have the same shape")
    pos = s[y == 1]
    neg = s[y == 0]
    n1, n0 = pos.size, neg.size
    if n1 == 0 or n0 == 0:
        raise ValueError("both outcome classes must be present")
    ranks = stats.rankdata(np.concatenate([pos, neg]))
    a = (ranks[:n1].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0)
    if not ci:
        return Interval(float(a), float("nan"), float("nan"))
    # DeLong structural components (placement values).
    v10 = np.array([(np.sum(neg < p) + 0.5 * np.sum(neg == p)) / n0 for p in pos])
    v01 = np.array([(np.sum(pos > q) + 0.5 * np.sum(pos == q)) / n1 for q in neg])
    var = v10.var(ddof=1) / n1 + v01.var(ddof=1) / n0
    se = np.sqrt(max(var, 0.0))
    return Interval(float(a), float(max(0.0, a - Z95 * se)), float(min(1.0, a + Z95 * se)))


# --------------------------------------------------------------------------------------
# Eq. 17 - Brier score and calibration in the large and in the small (Block I)
# --------------------------------------------------------------------------------------
def brier_and_calibration(y_true: np.ndarray, y_prob: np.ndarray) -> dict[str, float]:
    r"""Brier score with its Murphy decomposition and the calibration line.

    .. math::
        \mathrm{BS} = \frac{1}{n}\sum_{i=1}^{n}(\hat p_i - y_i)^2,

    and the calibration intercept :math:`\alpha` and slope :math:`\beta` from

    .. math::
        \mathrm{logit}\,\Pr(Y_i = 1) = \alpha + \beta\,\mathrm{logit}(\hat p_i),

    fitted by Newton-Raphson. A slope below one indicates predictions that are too
    extreme; an intercept below zero indicates systematic over-prediction of risk. The
    scaled Brier score is reported relative to the Brier score of the outcome prevalence,
    so it is comparable across outcomes with different base rates.
    """
    y = np.asarray(y_true, dtype=float)
    p = np.asarray(y_prob, dtype=float)
    if y.shape != p.shape:
        raise ValueError("y_true and y_prob must have the same shape")
    p = np.clip(p, 1e-12, 1 - 1e-12)
    brier = float(np.mean((p - y) ** 2))
    base = float(y.mean())
    brier_ref = base * (1 - base)
    scaled = 1.0 - brier / brier_ref if brier_ref > 0 else float("nan")

    lp = np.log(p / (1 - p))
    x = np.column_stack([np.ones_like(lp), lp])
    beta = np.zeros(2)
    for _ in range(100):
        eta = x @ beta
        mu = 1.0 / (1.0 + np.exp(-eta))
        w = np.clip(mu * (1 - mu), 1e-12, None)
        grad = x.T @ (y - mu)
        hess = x.T @ (x * w[:, None])
        step = linalg.solve(hess, grad, assume_a="pos")
        beta = beta + step
        if np.max(np.abs(step)) < 1e-10:
            break
    return {
        "brier": brier,
        "brier_reference": float(brier_ref),
        "brier_scaled": float(scaled),
        "calibration_intercept": float(beta[0]),
        "calibration_slope": float(beta[1]),
        "observed_rate": base,
        "predicted_rate": float(p.mean()),
    }
