"""Block E - missingness mechanism, imputation and the provenance of a blank field.

A blank cell in a claims-derived analytic table is not one kind of object. It may be a
situational X12 field that the transaction standard does not require in that context, a
reference table that failed to join on token, an eligibility segment the contributor did
not supply for that month, or a value that is genuinely unknown. These have different
implications for imputation, so every variable carries its origin, and the missingness
table is stratified by data-contributor cohort and by calendar period because contributor
composition changed over the study window.

Little's test is reported because it is conventional, and its limitations are stated in
the same breath: with tens of millions of records it rejects on trivial departures from
completely-at-random, it has no power against not-at-random mechanisms, and it therefore
cannot license the missing-at-random assumption that the imputation model requires. That
assumption is defended by design - the variables driving missingness are observed and are
in the imputation model - and probed by a delta-adjusted sensitivity analysis.
"""

from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .. import equations as eq
from ..rngs import stream
from ..config import check, load_reported_values

ORIGIN_MEANING = {
    "situational_claim_field": (
        "A field the X12 837 or NCPDP D.0 standard marks situational, so its absence is a "
        "property of the transaction context rather than of the patient."
    ),
    "token_joined_reference": (
        "A reference or contextual attribute joined on token; absence reflects failure of "
        "the join, which is associated with identifier completeness."
    ),
    "token_joined_eligibility": (
        "An eligibility-segment attribute; absence reflects a month the contributor did "
        "not supply rather than an absence of coverage."
    ),
    "token_joined_imputation": (
        "A vendor-imputed attribute; absence reflects the vendor's own coverage and the "
        "value itself carries imputation error that propagates into any downstream model."
    ),
    "derived_from_claims": (
        "A derived field; absence reflects insufficient claim history to apply the "
        "derivation rule within the look-back window."
    ),
}


def missingness_profile(frame: pd.DataFrame, columns: list[str] | None = None) -> pd.DataFrame:
    """Per-variable missingness rate, overall and by contributor cohort and period."""
    columns = columns or [c for c in frame.columns if frame[c].isna().any()]
    rows = []
    for col in columns:
        row = {"variable": col, "overall_pct": 100.0 * float(frame[col].isna().mean())}
        for key, label in (("contributor_cohort", "cohort"), ("period", "period")):
            if key in frame.columns:
                by = frame.groupby(key)[col].apply(lambda s: 100.0 * float(s.isna().mean()))
                for level, value in by.items():
                    row[f"{label}_{level}_pct"] = float(value)
        rows.append(row)
    return pd.DataFrame(rows).sort_values("overall_pct", ascending=False)


def mcar_test(frame: pd.DataFrame, columns: list[str]) -> dict:
    """Little's MCAR test, reported together with the reason it settles nothing."""
    result = eq.littles_mcar_test(frame[columns])
    return {
        "chisq": result["chisq"],
        "df": result["df"],
        "p_value": result["p_value"],
        "n_patterns": result["n_patterns"],
        "interpretation": " ".join(
            """At this sample size the test rejects complete randomness on departures far
            too small to matter for any estimate, and it has no power at all against a
            not-at-random mechanism. Rejection here is therefore uninformative about
            whether the imputation model is adequate; that case rests on the observed
            drivers of missingness being in the model, and on the delta-adjusted
            sensitivity analysis reported below.""".split()
        ),
    }


def impute(
    frame: pd.DataFrame,
    columns: list[str],
    *,
    m: int = 20,
    seed: int = 20250731,
    max_iter: int = 5,
) -> list[pd.DataFrame]:
    """Multiple imputation by chained equations over the supplied columns.

    Continuous targets are modelled by Bayesian linear regression with a draw from the
    posterior of the residual variance, and binary targets by logistic regression with a
    draw from the asymptotic posterior of the coefficients, so that between-imputation
    variability reflects parameter uncertainty and not only residual noise.
    """
    from sklearn.linear_model import LinearRegression, LogisticRegression

    rng = stream(seed, "block_e_mice")
    # The predictor set is fixed and documented rather than "every numeric column". A
    # chained-equations model with hundreds of collinear component flags is unstable, slow
    # and no better specified; what the missing-at-random assumption needs is that the
    # observed drivers of missingness are represented, and those are demography, payer,
    # region, calendar period, contributor cohort and utilisation intensity.
    candidates = [
        "age",
        "female",
        "payer_code",
        "region_code",
        "period_code",
        "contributor_code",
        "claim_lines",
        "inpatient_admissions",
        "ed_visits",
        "outpatient_visits",
        "comorbidity_count",
    ]
    base = pd.DataFrame(index=frame.index)
    if "age" in frame:
        base["age"] = frame["age"].astype(float)
    if "sex" in frame:
        base["female"] = (frame["sex"].astype(str) == "F").astype(float)
    for source, name in (
        ("payer", "payer_code"),
        ("region", "region_code"),
        ("period", "period_code"),
        ("contributor_cohort", "contributor_code"),
    ):
        if source in frame:
            base[name] = pd.Categorical(frame[source].astype(str)).codes.astype(float)
    for name in ("claim_lines", "inpatient_admissions", "ed_visits", "outpatient_visits"):
        if name in frame:
            base[name] = frame[name].astype(float)
    elix = [c for c in frame.columns if re.fullmatch(r"elix_\d{2}", c)]
    if elix:
        base["comorbidity_count"] = frame[elix].sum(axis=1).astype(float)
    base = base[[c for c in candidates if c in base.columns]]
    base = base.fillna(base.median(numeric_only=True))

    # Categorical targets are imputed on an integer coding and decoded afterwards, so a
    # nominal field such as rendering-provider specialty can enter the chained equations
    # without being treated as an ordered quantity in the returned data.
    encoded = frame[columns].copy()
    levels: dict[str, pd.Index] = {}
    for col in columns:
        if encoded[col].dtype.kind not in "ifb":
            categories = pd.Categorical(encoded[col])
            levels[col] = categories.categories
            encoded[col] = pd.Series(categories.codes, index=encoded.index).replace(-1, np.nan)

    completed = []
    for _ in range(m):
        work = encoded.copy()
        for col in columns:
            observed = work[col].notna()
            work.loc[~observed, col] = work.loc[observed, col].sample(
                int((~observed).sum()), replace=True, random_state=int(rng.integers(1 << 31))
            ).to_numpy()
        for _ in range(max_iter):
            for col in columns:
                missing = encoded[col].isna()
                if not missing.any():
                    continue
                others = [c for c in columns if c != col]
                design = pd.concat([base, work[others]], axis=1).to_numpy(dtype=float)
                # Standardising the design is not cosmetic: the utilisation counts run to
                # several hundred while the indicators are 0/1, and an unscaled design
                # makes the logistic solver take hundreds of iterations to reach the same
                # coefficients.
                centre = design.mean(axis=0)
                spread = design.std(axis=0)
                spread[spread == 0] = 1.0
                design = (design - centre) / spread
                y = work[col].to_numpy(dtype=float)
                distinct = np.unique(y[~np.isnan(y)])
                binary = distinct.size <= 2 or col in levels
                fit_rows = (~missing).to_numpy()
                if binary:
                    model = LogisticRegression(max_iter=200)
                    model.fit(design[fit_rows], y[fit_rows])
                    probabilities = model.predict_proba(design[missing.to_numpy()])
                    draws = np.array(
                        [rng.choice(model.classes_, p=row) for row in probabilities]
                    )
                    work.loc[missing, col] = draws
                else:
                    model = LinearRegression().fit(design[fit_rows], y[fit_rows])
                    fitted = model.predict(design[missing.to_numpy()])
                    resid = y[fit_rows] - model.predict(design[fit_rows])
                    dof = max(int(fit_rows.sum() - design.shape[1] - 1), 1)
                    sigma = np.sqrt((resid**2).sum() / rng.chisquare(dof))
                    work.loc[missing, col] = fitted + rng.normal(scale=sigma, size=fitted.size)
        for col, categories in levels.items():
            codes = np.clip(np.round(work[col].to_numpy(dtype=float)), 0, len(categories) - 1)
            work[col] = categories.to_numpy()[codes.astype(int)]
        completed.append(work)
    return completed


def pool(estimates: list[float], variances: list[float]) -> dict:
    """Rubin pooling with the fraction of missing information."""
    pooled = eq.rubin_pool(np.array(estimates, dtype=float), np.array(variances, dtype=float))
    return {
        "estimate": pooled["estimate"],
        "se": pooled["se"],
        "df": pooled["df"],
        "ci": [pooled["ci_lower"], pooled["ci_upper"]],
        "fmi": pooled["fmi"],
        "lambda": pooled["lambda"],
        "between_variance": pooled["between_variance"],
        "threshold": check("E_pooled_fmi", pooled["fmi"]),
    }


def delta_adjusted_sensitivity(
    completed: list[pd.DataFrame],
    column: str,
    deltas: tuple[float, ...] = (-0.5, -0.25, 0.0, 0.25, 0.5),
) -> list[dict]:
    """Shift imputed values by delta standard deviations to probe departure from MAR.

    The imputation model assumes that conditional on the observed drivers, the missing
    values look like the observed ones. Adding a fixed shift to every imputed value asks
    what would have to be true for the conclusion to change, and reports the shift at which
    it does.
    """
    pooled = pd.concat([c[column] for c in completed])
    if pooled.dtype.kind not in "if":
        raise TypeError("delta-adjusted sensitivity applies to numeric variables only")
    scale = float(pooled.std())
    out = []
    for delta in deltas:
        means = [float(c[column].mean() + delta * scale) for c in completed]
        out.append(
            {
                "delta_sd": delta,
                "pooled_mean": float(np.mean(means)),
                "shift": float(delta * scale),
            }
        )
    return out


def run(frame: pd.DataFrame | None = None, *, m: int = 20, seed: int = 20250731) -> dict:
    """Execute Block E."""
    reported = load_reported_values()["table_11_missingness"]
    result: dict = {
        "published": {
            "littles_chisq": reported["littles_chisq"],
            "littles_df": reported["littles_df"],
            "imputations": reported["imputations"],
            "pooled_fmi": reported["pooled_fmi"],
            "pooled_missingness_pct": reported["pooled"],
        },
        "variables": reported["variables"],
        "origin_meaning": ORIGIN_MEANING,
        "threshold": check("E_pooled_fmi", float(reported["pooled_fmi"])),
    }
    if frame is None:
        return result

    targets = [c for c in ("income_band", "provider_specialty") if c in frame.columns]
    result["profile"] = missingness_profile(frame).to_dict("records")
    numeric = [c for c in frame.columns if frame[c].dtype.kind in "if"]
    result["littles_test"] = mcar_test(frame, numeric[:12])
    if targets:
        completed = impute(frame, targets, m=min(m, 5), seed=seed)
        estimates, variances = [], []
        numeric_target = next(
            (t for t in targets if frame[t].dtype.kind in "if"), targets[0]
        )
        for c in completed:
            x = c[numeric_target].to_numpy(dtype=float)
            estimates.append(float(x.mean()))
            variances.append(float(x.var(ddof=1) / x.size))
        result["pooled_example"] = {"variable": numeric_target, **pool(estimates, variances)}
        result["delta_sensitivity"] = delta_adjusted_sensitivity(completed, numeric_target)
        result["imputations_run"] = len(completed)
    return result
