"""Block A - internal consistency and alternative reliability evidence.

Alpha answers one narrow question: do the component flags of a derived index covary as a
single dimension. It says nothing about whether any individual diagnosis code is correct,
and a high alpha is partly a consequence of having many items. Block A therefore reports
four further statistics beside it - a test-retest coefficient over two non-overlapping
twelve-month windows, agreement of each component against an independent reference
definition, separation between clinically defined known groups, and discrimination of the
index for a downstream outcome - so that reliability is not confused with validity.
"""

from __future__ import annotations

import re

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check


_ITEM_SUFFIX = re.compile(r"^\d{2}$")


def _item_columns(frame: pd.DataFrame, prefix: str) -> list[str]:
    """Component flag columns for an index.

    Only the two-digit component flags are treated as items. Derived summaries built from
    the same flags, such as the per-window counts used for the test-retest coefficient,
    are excluded, because including a total alongside its own components would inflate
    alpha mechanically.
    """
    return sorted(
        c for c in frame.columns if c.startswith(prefix) and _ITEM_SUFFIX.match(c[len(prefix):])
    )


def internal_consistency(frame: pd.DataFrame, prefix: str, label: str) -> dict:
    """Alpha with its Feldt interval for one multi-item composite index."""
    cols = _item_columns(frame, prefix)
    if len(cols) < 2:
        raise ValueError(f"no multi-item index found for prefix {prefix!r}")
    items = frame[cols].to_numpy(dtype=float)
    alpha = eq.cronbach_alpha(items)
    return {
        "construct": label,
        "items": len(cols),
        "n": int(items.shape[0]),
        "alpha": alpha.estimate,
        "alpha_ci": [alpha.lower, alpha.upper],
        "threshold": check("A_cronbach_alpha", alpha.estimate),
    }


def test_retest(frame: pd.DataFrame, first: str, second: str) -> dict:
    """ICC(2,1) across two non-overlapping observation windows."""
    ratings = frame[[first, second]].dropna().to_numpy(dtype=float)
    icc = eq.icc_two_way_random(ratings)
    return {
        "icc": icc.estimate,
        "icc_ci": [icc.lower, icc.upper],
        "n": int(ratings.shape[0]),
        "threshold": check("A_test_retest_icc", icc.estimate),
    }


def component_agreement(frame: pd.DataFrame, prefix: str, reference_prefix: str) -> dict:
    """Median component-level kappa against an independent reference definition.

    Each component flag of the index is cross-tabulated against the corresponding flag
    from the reference definition, and the median kappa across components is reported.
    The median rather than the mean is used because the distribution across components is
    skewed by rare conditions where kappa is unstable.
    """
    kappas = []
    for col in _item_columns(frame, prefix):
        ref = col.replace(prefix, reference_prefix, 1)
        if ref not in frame.columns:
            continue
        table = pd.crosstab(frame[col], frame[ref]).to_numpy(dtype=float)
        if table.shape == (2, 2):
            kappas.append(eq.cohens_kappa(table, ci=False).estimate)
    return {"component_kappas": kappas, "median_kappa": float(np.median(kappas)) if kappas else float("nan")}


def known_group_separation(frame: pd.DataFrame, score: str, group: str) -> dict:
    """Standardized difference in the index between a clinically defined contrast.

    A reliable index that cannot separate groups known on clinical grounds to differ in
    morbidity would be internally coherent and substantively useless, which is why this
    statistic is reported next to alpha rather than in place of it.
    """
    high = frame.loc[frame[group] == 1, score].to_numpy(dtype=float)
    low = frame.loc[frame[group] == 0, score].to_numpy(dtype=float)
    return {
        "smd": eq.standardized_mean_difference(high, low),
        "n_high": int(high.size),
        "n_low": int(low.size),
        "mean_high": float(high.mean()),
        "mean_low": float(low.mean()),
    }


def discrimination(frame: pd.DataFrame, score: str, outcome: str) -> dict:
    """C-statistic of the index alone for a downstream outcome."""
    sub = frame[[score, outcome]].dropna()
    a = eq.auroc(sub[outcome].to_numpy(), sub[score].to_numpy())
    return {"c_statistic": a.estimate, "c_ci": [a.lower, a.upper], "n": int(len(sub))}


def run(frame: pd.DataFrame) -> dict:
    """Execute the whole of Block A on a patient-level frame."""
    indices = [("elix_", "Elixhauser comorbidity"), ("charlson_", "Charlson comorbidity")]
    results = {"internal_consistency": [internal_consistency(frame, p, lab) for p, lab in indices]}

    scored = frame.copy()
    scored["elix_score"] = scored[_item_columns(scored, "elix_")].sum(axis=1)
    scored["charlson_score"] = scored[_item_columns(scored, "charlson_")].sum(axis=1)

    results["component_agreement"] = {
        "Elixhauser components vs reference definition": component_agreement(
            scored, "elix_", "elixref_"
        )
    }
    results["test_retest"] = test_retest(scored, "elix_count_window1", "elix_count_window2")
    results["known_group"] = {
        "Elixhauser vs heart failure": known_group_separation(scored, "elix_score", "heart_failure"),
        "Charlson vs chronic kidney disease": known_group_separation(scored, "charlson_score", "ckd"),
    }
    results["discrimination"] = {
        "Elixhauser for 90-day mortality": discrimination(scored, "elix_score", "mortality_90d"),
        "Charlson for 90-day mortality": discrimination(scored, "charlson_score", "mortality_90d"),
    }
    results["all_thresholds_met"] = all(
        r["threshold"]["passes"] for r in results["internal_consistency"]
    ) and results["test_retest"]["threshold"]["passes"]
    return results
