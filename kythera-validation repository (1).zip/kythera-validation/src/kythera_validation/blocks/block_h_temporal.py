"""Block H - temporal stability, and why the pre-registered window is short.

The pre-registered analysis covers fourteen quarters from 2022Q1 to 2025Q2. That window is
chosen because the data-contributor panel is close to stable across it. Extending the series
back to 2016 mixes two different signals: change in the population's care patterns, and
change in which contributors were supplying data. The longer series is therefore reported as
exploratory, and the structural break it identifies in 2020Q2 is what one would expect from
the suspension of elective care rather than a property of the data asset.

A non-significant Mann-Kendall statistic is not evidence of stability. With fourteen
quarterly observations the test has low power against a gradual drift, so the trend test is
reported with its detectable-effect size, and a cumulative-sum chart is used to look for the
abrupt shifts that a rank-correlation trend test is not designed to detect.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check, load_reported_values

PANEL_COMPOSITION_CAVEAT = " ".join(
    """Any quarter-to-quarter change in a claims series has two candidate explanations that
    the series alone cannot separate: the population changed, or the set of contributors
    reporting on it changed. Restricting the pre-registered window to the period of stable
    panel composition removes the second explanation by design. The exploratory series is
    reported because readers will want the longer view, and it is labelled exploratory because
    over that span the second explanation cannot be ruled out.""".split()
)


def detectable_trend(n_periods: int, *, alpha: float = 0.05, power: float = 0.80) -> dict:
    """Smallest Kendall tau this many periods can detect, at the stated power.

    The variance of Kendall's tau under the null is :math:`2(2n+5)/[9n(n-1)]`, so the
    detectable value at the conventional significance level and power is

    .. math:: \\tau_{\\min} = (z_{1-\\alpha/2} + z_{\\text{power}})\\sqrt{\\frac{2(2n+5)}{9n(n-1)}}.

    Reporting it turns "no significant trend" into a bounded statement about how large a drift
    would have escaped detection.
    """
    from scipy import stats

    z_alpha = float(stats.norm.ppf(1 - alpha / 2))
    z_power = float(stats.norm.ppf(power))
    sd = float(np.sqrt(2 * (2 * n_periods + 5) / (9 * n_periods * (n_periods - 1))))
    return {
        "n_periods": n_periods,
        "null_sd_of_tau": sd,
        "minimum_detectable_tau": (z_alpha + z_power) * sd,
        "interpretation": " ".join(
            """A trend smaller than the minimum detectable value would not have reached
            significance in this series, so the absence of a significant trend bounds the
            drift rather than excluding it.""".split()
        ),
    }


def quarterly_series(frame: pd.DataFrame, value: str, period: str = "quarter") -> pd.Series:
    """Aggregate a patient-level frame to a quarterly mean series."""
    return frame.groupby(period)[value].mean().sort_index()


def run(series: pd.Series | None = None) -> dict:
    """Execute Block H."""
    reported = load_reported_values()["block_h_temporal"]
    result: dict = {
        "pre_registered": {
            "window": reported["window"],
            "quarters": int(reported["quarters"]),
            "tau": float(reported["mann_kendall_tau"]),
            "p_value": float(reported["p_value"]),
            "cusum_breaks": int(reported["cusum_breaks"]),
            "threshold": check("H_abs_tau", abs(float(reported["mann_kendall_tau"]))),
        },
        "exploratory": {
            "window": reported["exploratory_window"],
            "tau": float(reported["exploratory_tau"]),
            "p_value": float(reported["exploratory_p"]),
            "break_quarter": reported["exploratory_break"],
            "status": "exploratory; panel composition not stable across this window",
        },
        "power": detectable_trend(int(reported["quarters"])),
        "panel_composition_caveat": PANEL_COMPOSITION_CAVEAT,
    }

    if series is not None:
        values = np.asarray(series.to_numpy(), dtype=float)
        mk = eq.mann_kendall(values)
        cs = eq.cusum(values)
        result["recomputed"] = {
            "n": int(values.size),
            "tau": mk["tau"],
            "p_value": mk["p_value"],
            "s_statistic": mk["s"],
            "z": mk["z"],
            "cusum_break_indices": cs["break_indices"],
            "cusum_breaks_detected": cs["n_breaks"],
            "cusum_max_positive": float(np.max(cs["cusum_positive"])),
            "cusum_max_negative": float(np.max(cs["cusum_negative"])),
            "threshold": check("H_abs_tau", abs(mk["tau"])),
        }
    return result
