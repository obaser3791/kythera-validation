"""Block D - representativeness and the limits of what post-stratification can fix.

Post-stratification on age, sex, region and payer mix removes observable differences in
those margins. It does not remove differences in the unobserved determinants of appearing
in a claims file at all, and it cannot recover the uninsured, who are absent from the
source universe by construction rather than under-represented within it. Block D therefore
reports the achieved balance and, next to it, an explicit statement of the residual
selection that weighting leaves untouched, so that a table of small standardised
differences is not read as evidence of national representativeness.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check, load_reported_values

RESIDUAL_SELECTION = " ".join(
    """Weighting equalises the marginal distributions used to construct the weights. It
    leaves three sources of selection in place. First, the uninsured are not
    under-represented but absent, because a person with no coverage generates no
    adjudicated claim, and no weight can create that stratum. Second, coverage varies by
    payer and by state in ways that are correlated with health status conditional on age,
    sex and region, so within-cell composition still differs from the national population.
    Third, appearing in the linked cohort requires a token match, which depends on the
    completeness of the identifiers a data contributor supplies, and that completeness is
    itself associated with care setting and socio-economic position. Estimates from this
    cohort therefore describe the commercially and publicly insured population that
    generates adjudicated claims, and generalising beyond it requires an argument about
    these three mechanisms rather than an appeal to the balance table.""".split()
)

# External population margins used for post-stratification. Age and sex are taken from the
# American Community Survey; the payer distribution is taken from MEPS insurance-coverage
# tables for the same period. Levels match the coding used by the surrogate generator.
EXTERNAL_MARGINS: dict[str, dict[str, float]] = {
    "age_band": {"<18": 0.222, "18-44": 0.361, "45-64": 0.247, "65-74": 0.098, "75+": 0.072},
    "sex": {"F": 0.508, "M": 0.492},
    "region": {
        "Northeast": 0.174,
        "Midwest": 0.208,
        "South": 0.384,
        "West": 0.204,
        "Other": 0.030,
    },
    "payer": {"Commercial": 0.512, "Medicare": 0.262, "Medicaid": 0.226},
}


def balance_table(
    frame: pd.DataFrame,
    margins: dict[str, dict[str, float]] = EXTERNAL_MARGINS,
    weights: np.ndarray | None = None,
) -> pd.DataFrame:
    """Standardised differences against external margins, one row per stratum.

    Every level of every stratifying variable is treated as a binary indicator, which is
    the standard handling of a categorical variable in a balance table and keeps all rows
    on a single scale.
    """
    w = np.ones(len(frame)) if weights is None else np.asarray(weights, dtype=float)
    w = w / w.sum()
    rows = []
    for variable, targets in margins.items():
        if variable not in frame.columns:
            continue
        values = frame[variable].astype(str).to_numpy()
        for level, target in targets.items():
            observed = float(w[values == str(level)].sum())
            rows.append(
                {
                    "variable": variable,
                    "level": str(level),
                    "cohort_pct": 100.0 * observed,
                    "target_pct": 100.0 * float(target),
                    "abs_smd": eq.standardized_mean_difference(
                        observed, float(target), binary=True
                    ),
                }
            )
    return pd.DataFrame(rows)


def _codes(frame: pd.DataFrame, margins: dict[str, dict[str, float]]) -> tuple[np.ndarray, list]:
    """Integer category codes and matching target share vectors for the raking step."""
    used = [v for v in margins if v in frame.columns]
    design = np.empty((len(frame), len(used)), dtype=int)
    targets = []
    for col, variable in enumerate(used):
        levels = list(margins[variable])
        lookup = {str(level): i for i, level in enumerate(levels)}
        design[:, col] = frame[variable].astype(str).map(lookup).to_numpy()
        share = np.array([float(margins[variable][level]) for level in levels], dtype=float)
        targets.append(share / share.sum())
    return design, targets


def run(
    frame: pd.DataFrame | None = None,
    *,
    margins: dict[str, dict[str, float]] = EXTERNAL_MARGINS,
    max_iter: int = 200,
) -> dict:
    """Execute Block D, raking the cohort to the external margins."""
    reported = load_reported_values()["block_d_representativeness"]
    published_max = float(reported["max_abs_smd"])
    result: dict = {
        "published_max_abs_smd": published_max,
        "published_max_abs_smd_variable": reported["max_abs_smd_variable"],
        "published_max_abs_smd_after_weighting": float(reported["max_abs_smd_after_weighting"]),
        "strata_evaluated": int(reported["strata_evaluated"]),
        "threshold": check("D_abs_smd", published_max),
        "external_margins": margins,
        "residual_selection": RESIDUAL_SELECTION,
    }
    if frame is None:
        return result

    unweighted = balance_table(frame, margins)
    design, targets = _codes(frame, margins)
    # Untrimmed weights are the ones that reproduce the margins; trimming caps influence
    # at the cost of leaving a small residual imbalance. Both are reported, as in the
    # manuscript, so the cost of trimming is visible rather than absorbed.
    weights = eq.raking_weights(design, targets, max_iter=max_iter, trim=None)
    trimmed = eq.raking_weights(design, targets, max_iter=max_iter, trim=(0.2, 5.0))
    weighted = balance_table(frame, margins, weights=weights)
    weighted_trimmed = balance_table(frame, margins, weights=trimmed)
    normalised = weights / weights.mean()

    result.update(
        {
            "n": int(len(frame)),
            "unweighted": unweighted.to_dict("records"),
            "weighted": weighted.to_dict("records"),
            "max_abs_smd_unweighted": float(unweighted["abs_smd"].max()),
            "max_abs_smd_weighted": float(weighted["abs_smd"].max()),
            "max_abs_smd_weighted_trimmed": float(weighted_trimmed["abs_smd"].max()),
            "weighted_trimmed": weighted_trimmed.to_dict("records"),
            "worst_unweighted_stratum": unweighted.loc[
                unweighted["abs_smd"].idxmax(), ["variable", "level"]
            ].to_dict(),
            "weight_summary": {
                "min": float(normalised.min()),
                "median": float(np.median(normalised)),
                "max": float(normalised.max()),
                # Kish's effective-sample-size ratio: the factor by which variance is
                # inflated by unequal weighting.
                "design_effect": float(1.0 + normalised.var()),
                "effective_n": float(weights.sum() ** 2 / np.square(weights).sum()),
            },
            "recomputed_threshold": check("D_abs_smd", float(weighted["abs_smd"].max())),
        }
    )
    return result
