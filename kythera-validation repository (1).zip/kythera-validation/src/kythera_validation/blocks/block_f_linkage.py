"""Block F - linkage quality, reported as a stratified result rather than a headline rate.

Three statements are kept apart throughout this block. The match rate is a coverage
statement: what share of eligible records resolved to an entity. The false-match rate is a
precision statement on accepted links. Sensitivity is a recall statement, and it can only be
estimated because pairs below the lower cut-off were sampled into the adjudication frame as
well. A pipeline can report a high match rate while missing a large share of true matches,
and that possibility is why all three are reported together with the stratified breakdown.
"""

from __future__ import annotations

import pandas as pd

from ..config import check, load_reported_values
from ..linkage import adjudication, fellegi_sunter


def run(*, simulate: bool = False, n_pairs: int = 500_000, seed: int = 20250731) -> dict:
    """Execute Block F.

    With ``simulate=False`` the adjudicated results are assembled from the recorded values.
    With ``simulate=True`` the candidate-pair generator is run as well and the threshold
    derivation is exercised end to end, which is what the reproduction notebook does.
    """
    reported = load_reported_values()["table_12_linkage_overall"]
    result: dict = {
        "match_rate": {
            "rate": float(reported["match_rate"]),
            "ci": [float(x) for x in reported["match_rate_ci"]],
            "threshold": check("F_match_rate", float(reported["match_rate"])),
        },
        "blocking_passes": list(fellegi_sunter.BLOCKING_PASSES),
        "weight_schedule": fellegi_sunter.WeightSchedule().table().to_dict("records"),
        "operating_point": {
            "upper": fellegi_sunter.WeightSchedule().upper,
            "lower": fellegi_sunter.WeightSchedule().lower,
        },
        "adjudication": adjudication.run(),
        "tokenization_trade_off": " ".join(
            """Because a token is a keyed hash, agreement is exact or it is nothing. Every
            disagreement that classical linkage would resolve with string similarity becomes
            an exact disagreement here, so tokenized linkage buys a low false-match rate at
            the cost of missed matches, and the missed matches are concentrated exactly where
            identifier completeness is lowest. The stratified table below is therefore the
            result, and the overall rate is a summary of it rather than a substitute for
            it.""".split()
        ),
    }

    strata = pd.DataFrame(result["adjudication"]["stratified"])
    result["lowest_sensitivity_stratum"] = strata.loc[
        strata["sensitivity"].idxmin(), ["variable", "level", "n", "sensitivity"]
    ].to_dict()

    if simulate:
        schedule = fellegi_sunter.WeightSchedule()
        pairs = fellegi_sunter.simulate_candidate_pairs(
            n_pairs, prevalence=float(reported["true_match_prevalence"]), seed=seed
        )
        matched = pairs.loc[pairs["is_match"], "weight"].to_numpy()
        unmatched = pairs.loc[~pairs["is_match"], "weight"].to_numpy()
        upper, lower = fellegi_sunter.derive_thresholds(matched, unmatched)
        result["simulation"] = {
            "n_pairs": int(n_pairs),
            "derived_upper": upper,
            "derived_lower": lower,
            "at_pre_registered_operating_point": fellegi_sunter.operating_characteristics(
                pairs, schedule
            ),
            "at_derived_operating_point": fellegi_sunter.operating_characteristics(
                pairs, fellegi_sunter.WeightSchedule(upper=upper, lower=lower)
            ),
            "mean_weight_by_pass": pairs.groupby("blocking_pass")["weight"].mean().to_dict(),
            "threshold_curve": fellegi_sunter.threshold_curve(pairs).to_dict("records"),
        }
    return result
