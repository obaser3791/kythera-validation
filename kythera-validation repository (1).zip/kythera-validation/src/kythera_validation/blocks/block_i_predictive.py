"""Block I - predictive utility under three splitting schemes, with calibration.

Discrimination and calibration answer different questions and a model can be strong on one
and useless on the other. A c-statistic of 0.83 tells you the model orders patients well; it
says nothing about whether the predicted probabilities are right, and a decision rule applied
to miscalibrated probabilities will be wrong at every threshold. Both are therefore reported
for every split, together with the calibration slope and intercept.

Three splits are used because they fail in different ways. A random split answers whether the
model generalises to new patients from the same period and the same contributors. A temporal
holdout answers whether it generalises forward, which is the question any deployed model
faces. A leave-one-region-out scheme answers whether it generalises across the geographic
heterogeneity of coverage and coding practice. The random split is the most optimistic of the
three and is reported first only because it is conventional.

Leakage controls are explicit: the split is on patient identifier so no patient appears in two
folds, all predictors are constructed from a look-back window that closes before the outcome
window opens, and the imputation and scaling parameters are fitted inside each training fold.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..rngs import stream
from ..config import check, load_reported_values

LEAKAGE_CONTROLS = (
    "Splitting is on patient identifier, so no patient contributes rows to more than one fold.",
    "Every predictor is derived from a look-back window closing before the outcome window opens.",
    "Imputation models, scaling parameters and category encodings are fitted within the "
    "training fold and applied unchanged to the held-out fold.",
    "Outcome-adjacent fields - discharge disposition, date of death, and any claim dated after "
    "the index date - are excluded from the predictor set.",
    "Hyperparameters are selected by internal cross-validation inside the training fold only.",
)

HYPERPARAMETER_GRID = {
    "logistic_regression": {"penalty": ["l2"], "C": [0.01, 0.1, 1.0, 10.0]},
    "gradient_boosting": {
        "n_estimators": [200, 400, 800],
        "learning_rate": [0.01, 0.05, 0.10],
        "max_depth": [3, 4, 6],
        "subsample": [0.8, 1.0],
    },
    "random_forest": {
        "n_estimators": [300, 600],
        "max_depth": [8, 12, None],
        "min_samples_leaf": [10, 50, 200],
    },
}


def predictor_columns(frame: pd.DataFrame) -> list[str]:
    """Predictor set with outcome-adjacent and identifier fields removed."""
    excluded = {
        "patient_id",
        "mortality_90d",
        "readmission_30d",
        "elix_count_window2",
        "died",
        "discharge_disposition",
    }
    return [
        c
        for c in frame.columns
        if c not in excluded and frame[c].dtype.kind in "ifb" and not c.startswith("elixref_")
    ]


def _fit_predict(
    train: pd.DataFrame, test: pd.DataFrame, predictors: list[str], outcome: str, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    from sklearn.linear_model import LogisticRegression

    x_train = train[predictors].to_numpy(dtype=float)
    x_test = test[predictors].to_numpy(dtype=float)
    centre = np.nanmean(x_train, axis=0)
    spread = np.nanstd(x_train, axis=0)
    spread[spread == 0] = 1.0
    x_train = np.nan_to_num((x_train - centre) / spread)
    x_test = np.nan_to_num((x_test - centre) / spread)
    model = LogisticRegression(max_iter=500, random_state=seed)
    model.fit(x_train, train[outcome].to_numpy(dtype=int))
    return test[outcome].to_numpy(dtype=int), model.predict_proba(x_test)[:, 1]


def evaluate(y_true: np.ndarray, y_prob: np.ndarray) -> dict:
    """Discrimination, calibration and the Brier decomposition for one fold."""
    a = eq.auroc(y_true, y_prob)
    calibration = eq.brier_and_calibration(y_true, y_prob)
    return {
        "n": int(y_true.size),
        "events": int(y_true.sum()),
        "auroc": a.estimate,
        "auroc_ci": [a.lower, a.upper],
        "brier": calibration["brier"],
        "brier_scaled": calibration["brier_scaled"],
        "calibration_slope": calibration["calibration_slope"],
        "calibration_intercept": calibration["calibration_intercept"],
        "observed_rate": calibration["observed_rate"],
        "predicted_rate": calibration["predicted_rate"],
        "thresholds": [check("I_auroc", a.estimate), check("I_brier", calibration["brier"])],
    }


def random_split(frame: pd.DataFrame, outcome: str, *, seed: int = 20250731, train_share: float = 0.7) -> dict:
    """Patient-level random split."""
    rng = stream(seed, "block_i_random_split")
    assignment = rng.random(len(frame)) < train_share
    predictors = predictor_columns(frame)
    y, p = _fit_predict(frame[assignment], frame[~assignment], predictors, outcome, seed)
    return {"scheme": "random split", **evaluate(y, p)}


def temporal_holdout(frame: pd.DataFrame, outcome: str, *, seed: int = 20250731) -> dict:
    """Train on the earlier periods, test on the most recent one."""
    if "period" not in frame.columns:
        raise KeyError("a 'period' column is required for the temporal holdout")
    periods = sorted(frame["period"].unique())
    train = frame[frame["period"].isin(periods[:-1])]
    test = frame[frame["period"] == periods[-1]]
    predictors = predictor_columns(frame)
    y, p = _fit_predict(train, test, predictors, outcome, seed)
    return {
        "scheme": "temporal holdout",
        "train_periods": [str(x) for x in periods[:-1]],
        "test_period": str(periods[-1]),
        **evaluate(y, p),
    }


def leave_one_region_out(frame: pd.DataFrame, outcome: str, *, seed: int = 20250731) -> dict:
    """Hold out each region in turn and report the range across held-out regions."""
    if "region" not in frame.columns:
        raise KeyError("a 'region' column is required for the geographic scheme")
    predictors = predictor_columns(frame)
    folds = []
    for region in sorted(frame["region"].unique()):
        test = frame[frame["region"] == region]
        train = frame[frame["region"] != region]
        if test[outcome].nunique() < 2 or len(test) < 200:
            continue
        y, p = _fit_predict(train, test, predictors, outcome, seed)
        folds.append({"held_out_region": str(region), **evaluate(y, p)})
    return {
        "scheme": "leave-one-region-out",
        "folds": folds,
        "auroc_range": [min(f["auroc"] for f in folds), max(f["auroc"] for f in folds)],
        "calibration_slope_range": [
            min(f["calibration_slope"] for f in folds),
            max(f["calibration_slope"] for f in folds),
        ],
        "brier_range": [min(f["brier"] for f in folds), max(f["brier"] for f in folds)],
    }


def run(frame: pd.DataFrame | None = None, *, seed: int = 20250731) -> dict:
    """Execute Block I."""
    reported = load_reported_values()["table_16_predictive"]
    result: dict = {
        "published": reported,
        "leakage_controls": list(LEAKAGE_CONTROLS),
        "hyperparameter_grid": HYPERPARAMETER_GRID,
        "thresholds": [
            check("I_auroc", float(reported["mortality_90d"]["random_split"]["auroc"])),
            check("I_brier", float(reported["mortality_90d"]["random_split"]["brier"])),
        ],
        "discrimination_is_not_calibration": " ".join(
            """The c-statistic is invariant to any monotone transformation of the predicted
            probabilities, so a model can order patients perfectly and still assign
            probabilities that are systematically too high or too low. Any decision rule uses
            the probabilities themselves, which is why the calibration slope and intercept are
            reported for every split and not only the discrimination.""".split()
        ),
    }
    if frame is None:
        return result

    result["recomputed"] = {}
    for outcome in ("mortality_90d", "readmission_30d"):
        if outcome not in frame.columns:
            continue
        result["recomputed"][outcome] = {
            "random_split": random_split(frame, outcome, seed=seed),
            "temporal_holdout": temporal_holdout(frame, outcome, seed=seed),
            "leave_one_region_out": leave_one_region_out(frame, outcome, seed=seed),
        }
    return result
