"""Block C - construct validity of the social-determinants layer.

The two-factor model is fitted to the polychoric correlation matrix of twelve binary and
ordinal indicators. Acceptable global fit at this sample size is a weak test on its own,
because with a large n the chi-square statistic rejects on negligible misspecification
while the incremental indices are almost insensitive to it. Block C therefore reports the
loadings, the factor correlation, the Fornell-Larcker discriminant check and the nested
comparison against the pre-specified one-factor alternative alongside the fit indices,
and the conclusion rests on all of them together.

Seven of the twelve indicators are census-tract contextual measures, so the factors
describe neighbourhood social context. Reading them as individual attributes would be an
ecological inference the design does not support.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import optimize, stats

from .. import equations as eq
from ..config import check, load_cfa_model


def polychoric_correlation(x: pd.Series, y: pd.Series) -> float:
    """Two-step polychoric correlation between two ordered categorical variables.

    Thresholds are estimated from the univariate marginals, then the latent correlation is
    obtained by maximising the bivariate normal likelihood of the contingency table with
    the thresholds held fixed. This is the standard two-step estimator and is what makes
    the correlation matrix an admissible input to a WLSMV fit of ordinal indicators.
    """
    a = pd.Categorical(x.dropna())
    joint = pd.crosstab(x, y).to_numpy(dtype=float)
    if joint.shape[0] < 2 or joint.shape[1] < 2:
        return float("nan")
    n = joint.sum()
    row_cum = np.cumsum(joint.sum(axis=1) / n)[:-1]
    col_cum = np.cumsum(joint.sum(axis=0) / n)[:-1]
    tau_r = np.concatenate([[-np.inf], stats.norm.ppf(np.clip(row_cum, 1e-9, 1 - 1e-9)), [np.inf]])
    tau_c = np.concatenate([[-np.inf], stats.norm.ppf(np.clip(col_cum, 1e-9, 1 - 1e-9)), [np.inf]])
    del a

    def neg_log_lik(rho_arr: np.ndarray) -> float:
        rho = float(np.clip(rho_arr[0], -0.999, 0.999))
        total = 0.0
        for i in range(joint.shape[0]):
            for j in range(joint.shape[1]):
                if joint[i, j] == 0:
                    continue
                p = (
                    _bvn_cdf(tau_r[i + 1], tau_c[j + 1], rho)
                    - _bvn_cdf(tau_r[i], tau_c[j + 1], rho)
                    - _bvn_cdf(tau_r[i + 1], tau_c[j], rho)
                    + _bvn_cdf(tau_r[i], tau_c[j], rho)
                )
                total += joint[i, j] * np.log(max(p, 1e-12))
        return -total

    res = optimize.minimize_scalar(
        lambda r: neg_log_lik(np.array([r])), bounds=(-0.99, 0.99), method="bounded"
    )
    return float(res.x)


_GL_NODES, _GL_WEIGHTS = np.polynomial.legendre.leggauss(24)


def _bvn_cdf(h: float, k: float, rho: float) -> float:
    r"""Standard bivariate normal distribution function.

    Evaluated through the Sheppard identity

    .. math::
        \Phi_2(h,k,\rho) = \Phi(h)\Phi(k)
        + \int_0^{\rho} \frac{1}{2\pi\sqrt{1-r^2}}
          \exp\!\left(-\frac{h^2 - 2rhk + k^2}{2(1-r^2)}\right)\,dr

    with 24-node Gauss-Legendre quadrature on the integral, which is accurate to better
    than 1e-10 over the range of thresholds encountered here and fast enough to be called
    inside the polychoric likelihood for every cell of every indicator pair.
    """
    if np.isneginf(h) or np.isneginf(k):
        return 0.0
    if np.isposinf(h) and np.isposinf(k):
        return 1.0
    if np.isposinf(h):
        return float(stats.norm.cdf(k))
    if np.isposinf(k):
        return float(stats.norm.cdf(h))
    base = float(stats.norm.cdf(h) * stats.norm.cdf(k))
    if abs(rho) < 1e-12:
        return base
    r = 0.5 * rho * (_GL_NODES + 1.0)
    w = 0.5 * rho * _GL_WEIGHTS
    one_minus = 1.0 - r ** 2
    density = np.exp(-(h ** 2 - 2 * r * h * k + k ** 2) / (2 * one_minus)) / (
        2 * np.pi * np.sqrt(one_minus)
    )
    return float(base + np.dot(w, density))


def implied_correlation(loadings: np.ndarray, assignment: np.ndarray, phi: np.ndarray) -> np.ndarray:
    """Model-implied correlation matrix for a congeneric factor model.

    .. math:: \\Sigma = \\Lambda \\Phi \\Lambda^{\\top} + \\Theta

    with the residual diagonal set so that every implied variance is one, which is the
    standardised solution reported in the manuscript.
    """
    p = loadings.size
    lam = np.zeros((p, phi.shape[0]))
    lam[np.arange(p), assignment] = loadings
    common = lam @ phi @ lam.T
    theta = np.diag(1.0 - np.diag(common))
    return common + theta


def fit_two_factor(observed: np.ndarray, n: int) -> dict:
    """Fit the pre-specified two-factor model and the nested one-factor alternative.

    Both models are fitted by minimising the off-diagonal residuals of the standardised
    implied correlation matrix under bound constraints, which is the least-squares
    counterpart of the WLSMV fit used on the licensed data and is what makes the fit
    reproducible without a proprietary structural-equation package. Fit indices are then
    computed from the maximum-likelihood discrepancy at the fitted solution, so the
    reported CFI, TLI, RMSEA and SRMR are on the usual scale.
    """
    cfa = load_cfa_model()
    names, loadings, assignment = [], [], []
    for f_idx, key in enumerate(("economic_adversity", "care_access")):
        for item in cfa["factors"][key]["indicators"]:
            names.append(item["name"])
            loadings.append(float(item["loading"]))
            assignment.append(f_idx)
    lam0 = np.array(loadings)
    asg = np.array(assignment)
    iu = np.triu_indices(observed.shape[0], k=1)

    # Start values: loadings from the configuration, factor correlation from the mean
    # cross-factor correlation divided by the mean product of the loadings involved, which
    # is the method-of-moments estimate of phi and puts the optimiser on the right sign.
    cross = np.array(
        [observed[i, j] for i, j in zip(*iu, strict=True) if asg[i] != asg[j]], dtype=float
    )
    prod = np.array(
        [lam0[i] * lam0[j] for i, j in zip(*iu, strict=True) if asg[i] != asg[j]], dtype=float
    )
    phi0 = float(np.clip((cross / prod).mean(), -0.95, 0.95))

    def residuals(theta: np.ndarray) -> np.ndarray:
        lam = theta[:-1]
        phi = theta[-1]
        sigma = implied_correlation(lam, asg, np.array([[1.0, phi], [phi, 1.0]]))
        return (observed - sigma)[iu]

    bounds = (
        np.concatenate([np.full(lam0.size, 0.05), [-0.95]]),
        np.concatenate([np.full(lam0.size, 0.98), [0.95]]),
    )
    res = optimize.least_squares(
        residuals, np.concatenate([lam0, [phi0]]), bounds=bounds, xtol=1e-12, ftol=1e-12
    )
    lam_hat = res.x[:-1]
    phi_hat = float(res.x[-1])
    sigma = implied_correlation(lam_hat, asg, np.array([[1.0, phi_hat], [phi_hat, 1.0]]))
    two = eq.sem_fit_indices(observed, sigma, n, lam_hat.size + 1, structure="correlation")

    def residuals1(theta: np.ndarray) -> np.ndarray:
        sigma1 = implied_correlation(theta, np.zeros_like(asg), np.array([[1.0]]))
        return (observed - sigma1)[iu]

    res1 = optimize.least_squares(
        residuals1,
        lam0,
        bounds=(np.full(lam0.size, 0.05), np.full(lam0.size, 0.98)),
        xtol=1e-12,
        ftol=1e-12,
    )
    lam1 = res1.x
    sigma1 = implied_correlation(lam1, np.zeros_like(asg), np.array([[1.0]]))
    one = eq.sem_fit_indices(observed, sigma1, n, lam1.size, structure="correlation")

    ave, omega = {}, {}
    for f_idx, key in enumerate(("economic_adversity", "care_access")):
        sel = lam_hat[asg == f_idx]
        ave[key] = float(np.mean(sel ** 2))
        omega[key] = float(sel.sum() ** 2 / (sel.sum() ** 2 + (1 - sel ** 2).sum()))

    return {
        "indicators": names,
        "loadings": {k: float(v) for k, v in zip(names, lam_hat, strict=True)},
        "factor_correlation": phi_hat,
        "average_variance_extracted": ave,
        "composite_reliability_omega": omega,
        "fornell_larcker_satisfied": bool(all(v > phi_hat ** 2 for v in ave.values())),
        "two_factor": {
            "chisq": two.chisq,
            "df": two.df,
            "chisq_over_df": two.chisq_over_df,
            "cfi": two.cfi,
            "tli": two.tli,
            "rmsea": two.rmsea,
            "rmsea_ci": list(two.rmsea_ci),
            "srmr": two.srmr,
        },
        "one_factor": {
            "chisq": one.chisq,
            "df": one.df,
            "cfi": one.cfi,
            "tli": one.tli,
            "rmsea": one.rmsea,
            "srmr": one.srmr,
        },
        "delta_chisq": float(one.chisq - two.chisq),
        "delta_df": int(one.df - two.df),
        "two_factor_retained": bool(two.cfi > one.cfi and two.rmsea < one.rmsea),
        "thresholds": [
            check("C_cfi", two.cfi),
            check("C_tli", two.tli),
            check("C_rmsea", two.rmsea),
            check("C_srmr", two.srmr),
        ],
    }


def run(frame: pd.DataFrame, *, sample: int = 20000, seed: int = 20250731) -> dict:
    """Execute Block C on the indicator columns of a patient-level frame."""
    cfa = load_cfa_model()
    cols = [
        item["name"]
        for key in ("economic_adversity", "care_access")
        for item in cfa["factors"][key]["indicators"]
    ]
    available = [c for c in cols if c in frame.columns]
    sub = frame[available].dropna()
    if len(sub) > sample:
        sub = sub.sample(sample, random_state=seed)
    p = len(available)
    corr = np.eye(p)
    for i in range(p):
        for j in range(i + 1, p):
            r = polychoric_correlation(sub[available[i]], sub[available[j]])
            corr[i, j] = corr[j, i] = 0.0 if np.isnan(r) else r
    # Ridge the matrix so it is positive definite despite estimation noise in the
    # pairwise polychoric step, which is the standard remedy for a two-step estimator.
    eigenvalues = np.linalg.eigvalsh(corr)
    if eigenvalues.min() <= 1e-6:
        corr = (corr + np.eye(p) * (abs(eigenvalues.min()) + 1e-3)) / (1 + abs(eigenvalues.min()) + 1e-3)
    result = fit_two_factor(corr, len(sub))
    result["n"] = int(len(sub))
    result["observed_correlation"] = corr.tolist()
    return result
