"""Block G - intercoder reliability of the condition definitions.

Two coders applied each written condition definition independently to the same claim
histories, and kappa measures how reproducibly the definition can be applied. The quantity
being measured is the clarity of the definition, not the truth of the diagnosis: a definition
can be applied with near-perfect agreement and still identify the wrong patients, which is
why the positive predictive value against the reference standard is reported in the same
table.

Kappa is sensitive to the marginal prevalence of the category. For the two lowest-agreement
categories - substance use disorder and mood disorders - the prevalence is low and the
definitions rest on codes that are recorded inconsistently across care settings, so the
proportion of specific agreement is reported alongside kappa to separate the effect of
prevalence from the effect of genuine ambiguity in the definition.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check, load_conditions, load_reported_values


def specific_agreement(table: np.ndarray) -> dict:
    """Positive and negative specific agreement for a 2x2 coder-by-coder table.

    .. math::
        p_{\\text{pos}} = \\frac{2a}{2a + b + c}, \\qquad
        p_{\\text{neg}} = \\frac{2d}{2d + b + c}

    These are prevalence-independent in a way kappa is not. When kappa is low and positive
    specific agreement is high, the coders were agreeing about a rare category and kappa is
    being pulled down by the marginal distribution rather than by ambiguity in the wording.
    """
    a, b, c, d = float(table[0, 0]), float(table[0, 1]), float(table[1, 0]), float(table[1, 1])
    return {
        "positive_specific_agreement": (2 * a) / (2 * a + b + c) if (2 * a + b + c) else float("nan"),
        "negative_specific_agreement": (2 * d) / (2 * d + b + c) if (2 * d + b + c) else float("nan"),
        "observed_agreement": (a + d) / (a + b + c + d),
        "prevalence": (a + (b + c) / 2) / (a + b + c + d),
    }


def kappa_table(reported: dict | None = None) -> pd.DataFrame:
    """Per-category kappa, predictive value and accuracy, ordered as reported."""
    reported = reported or load_reported_values()["table_15_intercoder"]
    frame = pd.DataFrame(reported["categories"])
    frame["agreement_strength"] = pd.cut(
        frame["kappa"],
        bins=[-np.inf, 0.40, 0.60, 0.80, 1.0],
        labels=["fair or worse", "moderate", "substantial", "almost perfect"],
    ).astype(str)
    frame["meets_threshold"] = [check("G_cohens_kappa", k)["passes"] for k in frame["kappa"]]
    return frame


def reconcile_with_definitions() -> pd.DataFrame:
    """Join each coded category to the written definition the coders were applying.

    A reliability coefficient is uninterpretable without the text that produced it, so the
    rule, the code list and the published predictive value travel with the coefficient.
    """
    conditions = load_conditions()
    rows = []
    for entry in conditions.get("intercoder_categories", []):
        key = str(entry["key"])
        spec = conditions["conditions"].get(key, {})
        rows.append(
            {
                "condition": entry["label"],
                "config_key": key,
                "encounters_coded": entry.get("encounters"),
                "rule": spec.get("rule"),
                "icd10_codes": ", ".join(spec.get("icd10", [])[:6]),
                "supporting_rx": spec.get("supporting_rx"),
                "published_ppv": entry.get("published_ppv") or spec.get("published_ppv"),
            }
        )
    frame = pd.DataFrame(rows)
    return frame.astype(object).where(frame.notna(), None)


def run(coder_tables: dict[str, np.ndarray] | None = None) -> dict:
    """Execute Block G.

    ``coder_tables`` maps a condition name to its 2x2 coder-by-coder count table. When it is
    supplied, kappa and both specific-agreement proportions are recomputed from the tables;
    otherwise the recorded per-category values are assembled.
    """
    reported = load_reported_values()["table_15_intercoder"]
    frame = kappa_table(reported)
    result = {
        "overall": {
            "kappa": float(reported["overall"]["kappa"]),
            "kappa_ci": [float(x) for x in reported["overall"]["kappa_ci"]],
            "ppv": float(reported["overall"]["ppv"]),
            "sensitivity": float(reported["overall"]["sensitivity"]),
            "specificity": float(reported["overall"]["specificity"]),
            "threshold": check("G_cohens_kappa", float(reported["overall"]["kappa"])),
        },
        "categories": frame.to_dict("records"),
        "kappa_range": [float(frame["kappa"].min()), float(frame["kappa"].max())],
        "categories_below_threshold": frame.loc[~frame["meets_threshold"], "condition"].tolist(),
        "definitions": reconcile_with_definitions().to_dict("records"),
    }

    if coder_tables:
        recomputed = []
        for condition, table in coder_tables.items():
            array = np.asarray(table, dtype=float)
            kappa = eq.cohens_kappa(array)
            recomputed.append(
                {
                    "condition": condition,
                    "kappa": kappa.estimate,
                    "kappa_ci": [kappa.lower, kappa.upper],
                    **specific_agreement(array),
                }
            )
        result["recomputed"] = recomputed
    return result
