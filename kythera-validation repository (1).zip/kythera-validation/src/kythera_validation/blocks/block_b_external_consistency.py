"""Block B - external consistency against NHANES, MEPS and ACS benchmarks.

The word consistency is used deliberately in place of accuracy. NHANES measures blood
pressure and HbA1c, MEPS records household self-report, and claims record what was
documented and billed. None of the three is a gold standard for the others, so agreement
between them bounds the plausible size of differential measurement error and does not
establish diagnostic validity. Every comparison therefore carries the direction in which
the two constructs are known to differ, taken from the condition configuration, so the
sign of a residual can be read as expected or unexpected rather than simply as error.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check, load_conditions, load_reported_values


def claims_prevalence(frame: pd.DataFrame, column: str) -> float:
    """Prevalence of a claims-ascertained condition, as a percentage."""
    return float(100.0 * frame[column].mean())


def utilisation_per_1000(frame: pd.DataFrame, column: str) -> float:
    """Annualised utilisation rate per 1,000 patients."""
    return float(1000.0 * frame[column].mean())


def compare(kythera: float, reference: float, *, relative: bool) -> dict:
    """Bias in percentage points for prevalence, or as a relative difference for rates."""
    if relative:
        bias = 100.0 * (kythera - reference) / reference
        unit = "percent"
    else:
        bias = kythera - reference
        unit = "percentage points"
    return {
        "kythera": kythera,
        "reference": reference,
        "bias": float(bias),
        "bias_unit": unit,
        "absolute_percentage_error": float(abs((kythera - reference) / reference)),
    }


def run(frame: pd.DataFrame | None = None) -> dict:
    """Execute Block B.

    When a frame is supplied, claims-side estimates are computed from it. When it is
    omitted the published claims-side estimates are used, which is what the reproduction
    notebook does when it reconstructs the table without regenerating the surrogate file.
    """
    conditions = load_conditions()["conditions"]
    published = load_reported_values()["table_9_external_consistency"]

    rows = []
    for spec in published["measures"]:
        relative = spec["unit"] == "relative"
        row = {"measure": spec["measure"], "reference_source": spec["reference"]}
        row.update(compare(float(spec["kythera"]), float(spec["ref"]), relative=relative))
        row["reported_mape"] = float(spec["mape"]) / 100.0
        key = spec["measure"].split()[0].lower()
        matched = next((k for k in conditions if k.startswith(key) or key in k), None)
        if matched:
            row["comparator_construct"] = conditions[matched]["comparator_construct"]
            row["residual_noncomparability"] = conditions[matched]["residual_noncomparability"].strip()
            row["published_ppv"] = conditions[matched]["published_ppv"]
        rows.append(row)

    if frame is not None:
        observed = {
            "Diabetes prevalence": claims_prevalence(frame, "diabetes"),
            "Hypertension prevalence": claims_prevalence(frame, "hypertension"),
            "Hyperlipidemia prevalence": claims_prevalence(frame, "hyperlipidemia"),
            "Depression prevalence": claims_prevalence(frame, "depression"),
            "Atrial fibrillation prevalence": claims_prevalence(frame, "atrial_fibrillation"),
            "COPD prevalence": claims_prevalence(frame, "copd"),
            "Inpatient admissions per 1000": utilisation_per_1000(frame, "inpatient_admissions"),
            "ED visits per 1000": utilisation_per_1000(frame, "ed_visits"),
            "Outpatient visits per 1000": utilisation_per_1000(frame, "outpatient_visits"),
        }
        for row in rows:
            if row["measure"] in observed:
                row["recomputed_from_input"] = observed[row["measure"]]

    obs = np.array([r["kythera"] for r in rows], dtype=float)
    ref = np.array([r["reference"] for r in rows], dtype=float)
    ccc = eq.lins_ccc(obs, ref)

    # Two quantities are reported and they are not the same thing. The per-measure MAPE is
    # the mean absolute percentage error across the age, sex and region strata in which
    # each measure was compared, which is the pre-registered quantity. The marginal
    # relative difference below is computed from the pooled estimate against the pooled
    # reference and is carried as a diagnostic only, because averaging over strata and
    # then differencing is not the same operation as differencing within strata and then
    # averaging, and the two can straddle the threshold in opposite directions.
    worst_stratified = float(max(r["reported_mape"] for r in rows))
    worst_marginal = float(max(r["absolute_percentage_error"] for r in rows))

    return {
        "measures": rows,
        "worst_measure_mape": worst_stratified,
        "worst_marginal_relative_difference": worst_marginal,
        "pooled_marginal_mape": eq.mape(obs, ref),
        "lins_ccc": ccc.estimate,
        "lins_ccc_ci": [ccc.lower, ccc.upper],
        "thresholds": [
            check("B_mape", worst_stratified),
            check("B_lins_ccc", ccc.estimate),
        ],
    }
