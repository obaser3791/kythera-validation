"""Cohort construction and condition-flag derivation.

Two decisions in this module drive more of the published numbers than any modelling choice.

The first is the continuous-enrolment requirement. Requiring at least two observations removes
26.6 million patients, and those patients are not a random subset: a single-encounter patient
is disproportionately young, commercially insured and seen in an urgent-care or emergency
setting. Every prevalence figure in the paper is therefore conditional on that requirement,
and the sensitivity cohort defined by a single medical claim is reported alongside it so the
direction and size of the effect are visible rather than assumed.

The second is the claims-based condition rule. The one-inpatient-or-two-outpatient rule with a
thirty-day separation is not a diagnosis; it is an operational definition chosen because its
positive predictive value against chart review is documented in the literature. Loosening it to
a single code raises apparent prevalence and lowers the predictive value, and tightening it to
require supporting pharmacy does the reverse. Both variants are computed here so the
sensitivity of any prevalence claim to the rule is measurable.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from ..config import load_conditions, load_study_parameters

LOOK_BACK_MONTHS = 24
OUTCOME_WINDOW_DAYS = {"mortality_90d": 90, "readmission_30d": 30}


@dataclass(frozen=True)
class CohortStep:
    """One rung of the attrition ladder."""

    label: str
    n: int
    criterion: str


def attrition_ladder() -> list[CohortStep]:
    """The published cohort ladder with the criterion applied at each rung."""
    study = load_study_parameters()
    return [
        CohortStep(
            "Source universe",
            int(study["source_universe_tokens"]),
            "Distinct patients appearing in any contributed medical or pharmacy claim.",
        ),
        CohortStep(
            "Token-linked subset",
            int(study["token_linked_subset"]),
            "Carries a usable privacy-preserving token permitting cross-source linkage.",
        ),
        CohortStep(
            "At least two observations",
            int(study["cohort_two_observations"]),
            "Two or more claims at least 30 days apart, establishing observability.",
        ),
        CohortStep(
            "Final analytic cohort",
            int(study["analytic_cohort"]),
            "Non-missing age band, sex and region; token stable across the observation window.",
        ),
    ]


def ladder_frame() -> pd.DataFrame:
    """The attrition ladder as a table with retention shares."""
    steps = attrition_ladder()
    frame = pd.DataFrame([{"step": s.label, "n": s.n, "criterion": s.criterion} for s in steps])
    frame["share_of_source"] = frame["n"] / frame["n"].iloc[0]
    frame["retained_from_previous"] = frame["n"] / frame["n"].shift(1)
    frame["removed"] = -frame["n"].diff()
    return frame


def condition_rules() -> pd.DataFrame:
    """The claims-based condition definitions with their published predictive values."""
    conditions = load_conditions()["conditions"]
    rows = []
    for key, spec in conditions.items():
        rows.append(
            {
                "condition": key,
                "rule": spec.get("rule"),
                "look_back_months": spec.get("look_back_months", LOOK_BACK_MONTHS),
                "icd10": ", ".join(spec.get("icd10", [])),
                "supporting_rx": ", ".join(spec.get("supporting_rx", []) or []),
                "published_ppv": spec.get("published_ppv"),
                "source": spec.get("source"),
            }
        )
    return pd.DataFrame(rows)


def apply_rule(
    claims: pd.DataFrame,
    codes: list[str],
    *,
    variant: str = "primary",
    separation_days: int = 30,
    look_back_months: int = LOOK_BACK_MONTHS,
) -> pd.Series:
    """Flag patients meeting a condition rule from a long claim-level frame.

    ``claims`` needs the columns ``patient_id``, ``service_date``, ``setting`` with values in
    ``{"inpatient", "outpatient"}``, and ``diagnosis``. The three variants are the
    pre-registered rule, a permissive single-code rule, and a strict rule that additionally
    requires a supporting pharmacy fill; the permissive and strict variants exist so that the
    sensitivity of prevalence to the operational definition can be quantified rather than
    asserted.
    """
    if variant not in {"primary", "permissive", "strict"}:
        raise ValueError("variant must be primary, permissive or strict")

    prefixes = tuple(c.strip() for c in codes)
    hit = claims["diagnosis"].astype(str).str.startswith(prefixes)
    window_start = claims["service_date"].max() - pd.DateOffset(months=look_back_months)
    hit &= claims["service_date"] >= window_start
    relevant = claims.loc[hit, ["patient_id", "service_date", "setting"]]

    if variant == "permissive":
        return pd.Series(True, index=pd.Index(relevant["patient_id"].unique(), name="patient_id"))

    inpatient = set(relevant.loc[relevant["setting"] == "inpatient", "patient_id"])
    outpatient = relevant[relevant["setting"] == "outpatient"].sort_values(
        ["patient_id", "service_date"]
    )
    spans = outpatient.groupby("patient_id")["service_date"].agg(["min", "max", "size"])
    qualifying_outpatient = set(
        spans.index[(spans["size"] >= 2) & ((spans["max"] - spans["min"]).dt.days >= separation_days)]
    )
    flagged = sorted(inpatient | qualifying_outpatient)

    if variant == "strict" and "supporting_rx" in claims.columns:
        with_rx = set(claims.loc[claims["supporting_rx"].fillna(False).astype(bool), "patient_id"])
        flagged = sorted(set(flagged) & with_rx)

    return pd.Series(True, index=pd.Index(flagged, name="patient_id"))


def prevalence_sensitivity(patients: pd.DataFrame, condition: str) -> dict:
    """Prevalence of a condition flag overall and within the observability strata.

    The point of the table is the contrast between the analytic cohort and the patients who
    would have been excluded by the two-observation requirement: if the two prevalences differ
    materially, the published prevalence is a statement about observable patients rather than
    about the covered population.
    """
    if condition not in patients.columns:
        raise KeyError(f"{condition} is not a column of the patient frame")
    flag = patients[condition].astype(float)
    out = {"condition": condition, "overall_prevalence": float(flag.mean()), "n": int(len(flag))}
    if "continuous_2y" in patients.columns:
        continuous = patients["continuous_2y"].astype(bool)
        out["prevalence_continuous_2y"] = float(flag[continuous].mean())
        out["prevalence_not_continuous_2y"] = float(flag[~continuous].mean())
        out["absolute_difference"] = abs(
            out["prevalence_continuous_2y"] - out["prevalence_not_continuous_2y"]
        )
    if "observable_months" in patients.columns:
        months = patients["observable_months"].astype(float)
        edges = [0, 12, 24, 48, np.inf]
        labels = ["<12", "12-23", "24-47", "48+"]
        bands = pd.cut(months, bins=edges, labels=labels, right=False)
        out["prevalence_by_observable_months"] = {
            str(k): float(v) for k, v in flag.groupby(bands, observed=True).mean().items()
        }
    return out


def run(patients: pd.DataFrame | None = None) -> dict:
    """Assemble the cohort result set."""
    result = {
        "ladder": ladder_frame().to_dict("records"),
        "condition_rules": condition_rules().to_dict("records"),
        "look_back_months": LOOK_BACK_MONTHS,
        "outcome_windows_days": OUTCOME_WINDOW_DAYS,
        "conditionality": " ".join(
            """Prevalence in this cohort is prevalence among patients observable for at least
            two encounters. Patients removed by that requirement are younger and more often
            seen in a single acute encounter, so the published figures should be read as
            conditional on observability, and the observable-months gradient below is the
            evidence for how strong that conditioning is.""".split()
        ),
    }
    if patients is not None:
        available = [
            c for c in load_conditions()["conditions"] if c in patients.columns
        ]
        result["prevalence_sensitivity"] = [
            prevalence_sensitivity(patients, c) for c in available
        ]
    return result
