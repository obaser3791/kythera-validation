"""Figures. Each one answers a question that a table answers less well.

There is no decorative figure here. The provenance schematic exists because an intake chain is
a sequence and a table of gates does not show sequence. The calibration curve exists because a
c-statistic cannot show miscalibration. The threshold-sensitivity curve exists because the
linkage operating point is a choice and the reader is entitled to see how much the false-match
rate moves when that choice moves. The attrition ladder exists because the loss from
315.8 million to 38.9 million is the single most important fact about the cohort.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

TEAL = "#20808D"
RUST = "#A84B2F"
DARK = "#1B474D"
GREY = "#7A7974"
INK = "#28251D"

plt.rcParams.update(
    {
        "figure.dpi": 200,
        "savefig.dpi": 200,
        "font.size": 9,
        "axes.edgecolor": "#D4D1CA",
        "axes.labelcolor": INK,
        "axes.titlesize": 10,
        "axes.titleweight": "bold",
        "text.color": INK,
        "xtick.color": GREY,
        "ytick.color": GREY,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "white",
    }
)


def _save(fig: plt.Figure, out_dir: Path, name: str) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{name}.png"
    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def cohort_attrition(ladder: pd.DataFrame, out_dir: Path) -> Path:
    """Horizontal bars for the cohort ladder, labelled with the share of the source universe."""
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    order = ladder.iloc[::-1]
    positions = np.arange(len(order))
    ax.barh(positions, order["n"] / 1e6, color=[TEAL, TEAL, TEAL, DARK][: len(order)], height=0.6)
    ax.set_yticks(positions)
    ax.set_yticklabels(order["step"], fontsize=8)
    ax.set_xlabel("Patients (millions)")
    ax.set_title("Cohort construction retains 12.3 per cent of the source universe")
    for pos, (_, row) in zip(positions, order.iterrows()):
        ax.text(
            row["n"] / 1e6 + 4,
            pos,
            f"{row['n'] / 1e6:,.1f}M  ({row['share_of_source'] * 100:.1f}%)",
            va="center",
            fontsize=8,
            color=INK,
        )
    ax.set_xlim(0, float(ladder["n"].max()) / 1e6 * 1.28)
    return _save(fig, out_dir, "figure_cohort_attrition")


def calibration_curve(y_true: np.ndarray, y_prob: np.ndarray, out_dir: Path, *, bins: int = 10) -> Path:
    """Observed against predicted risk by decile of predicted risk."""
    order = np.argsort(y_prob)
    groups = np.array_split(order, bins)
    predicted = np.array([y_prob[g].mean() for g in groups])
    observed = np.array([y_true[g].mean() for g in groups])
    fig, ax = plt.subplots(figsize=(4.2, 4.0))
    limit = float(max(predicted.max(), observed.max())) * 1.15
    ax.plot([0, limit], [0, limit], color=GREY, lw=1, ls="--", label="Perfect calibration")
    ax.plot(predicted, observed, "o-", color=TEAL, lw=1.6, ms=4, label="Observed by decile")
    ax.set_xlabel("Mean predicted risk")
    ax.set_ylabel("Observed risk")
    ax.set_xlim(0, limit)
    ax.set_ylim(0, limit)
    ax.set_title("Calibration, not only discrimination")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    return _save(fig, out_dir, "figure_calibration")


def linkage_threshold_sensitivity(curve: pd.DataFrame, out_dir: Path, *, operating_point: float | None = None) -> Path:
    """False-match rate and sensitivity as the upper linkage threshold moves."""
    fig, ax = plt.subplots(figsize=(6.0, 3.4))
    ax.plot(curve["upper"], curve["false_match_rate"], color=RUST, lw=1.8, label="False-match rate")
    ax.set_xlabel("Upper match-weight threshold")
    ax.set_ylabel("False-match rate", color=RUST)
    ax.tick_params(axis="y", labelcolor=RUST)
    twin = ax.twinx()
    twin.plot(curve["upper"], curve["sensitivity"], color=TEAL, lw=1.8, label="Sensitivity")
    twin.set_ylabel("Sensitivity", color=TEAL)
    twin.tick_params(axis="y", labelcolor=TEAL)
    twin.spines["top"].set_visible(False)
    if operating_point is not None:
        ax.axvline(operating_point, color=GREY, lw=1, ls=":")
        ax.annotate(
            f"pre-registered operating point ({operating_point:.2f})",
            xy=(operating_point, ax.get_ylim()[1] * 0.92),
            xytext=(4, 0),
            textcoords="offset points",
            fontsize=7.5,
            color=GREY,
        )
    ax.set_title("The false-match rate is steep in the threshold")
    return _save(fig, out_dir, "figure_linkage_threshold")


def temporal_series(series: pd.Series, out_dir: Path, *, break_label: str | None = None) -> Path:
    """The quarterly series with its mean and any flagged structural break."""
    fig, ax = plt.subplots(figsize=(6.4, 3.0))
    x = np.arange(len(series))
    ax.plot(x, series.to_numpy(), "o-", color=TEAL, lw=1.6, ms=3.5)
    ax.axhline(float(series.mean()), color=GREY, lw=1, ls="--")
    ax.set_xticks(x[:: max(1, len(x) // 8)])
    ax.set_xticklabels([str(i) for i in series.index[:: max(1, len(x) // 8)]], fontsize=7.5, rotation=0)
    ax.set_ylabel("Quarterly value")
    ax.set_title("Pre-registered window: no detectable trend")
    if break_label is not None:
        ax.annotate(
            f"structural break, {break_label}",
            xy=(0.02, 0.06),
            xycoords="axes fraction",
            fontsize=7.5,
            color=GREY,
        )
    return _save(fig, out_dir, "figure_temporal_series")


def standardized_differences(frame: pd.DataFrame, out_dir: Path, *, limit: float = 0.10) -> Path:
    """Absolute standardised differences before and after raking, against the 0.10 limit."""
    fig, ax = plt.subplots(figsize=(5.6, max(2.4, 0.28 * len(frame))))
    positions = np.arange(len(frame))
    ax.scatter(frame["abs_smd_unweighted"], positions, s=22, color=RUST, label="Unweighted")
    ax.scatter(frame["abs_smd_weighted"], positions, s=22, color=TEAL, label="Raked")
    ax.axvline(limit, color=GREY, lw=1, ls="--")
    ax.set_yticks(positions)
    ax.set_yticklabels(frame["variable"], fontsize=7.5)
    ax.set_xlabel("Absolute standardised difference")
    ax.set_title("Raking brings every stratum inside the 0.10 limit")
    ax.legend(frameon=False, fontsize=8, loc="lower right", bbox_to_anchor=(1.0, -0.02))
    return _save(fig, out_dir, "figure_standardized_differences")


def provenance_schematic(gates: pd.DataFrame, out_dir: Path) -> Path:
    """The intake chain as a sequence of stages with the number of gates in each."""
    import textwrap

    stages = gates.groupby("stage", sort=False)["gate"].count()
    n = len(stages)
    fig, ax = plt.subplots(figsize=(1.45 * n + 0.6, 2.4))
    ax.axis("off")
    slot = 1.0 / n
    box_width = slot * 0.78
    gap = (slot - box_width) / 2
    for i, (stage, count) in enumerate(stages.items()):
        left = i * slot + gap
        ax.add_patch(
            plt.Rectangle(
                (left, 0.24),
                box_width,
                0.52,
                facecolor="#EAF2F3" if i % 2 == 0 else "white",
                edgecolor=TEAL,
                lw=1.1,
            )
        )
        label = textwrap.fill(
            str(stage).replace("_", " "), width=14, break_long_words=False
        )
        centre = left + box_width / 2
        ax.text(
            centre, 0.60, label, ha="center", va="center", fontsize=7.5, color=INK, weight="bold"
        )
        ax.text(
            centre,
            0.35,
            f"{count} gate{'s' if count != 1 else ''}",
            ha="center",
            va="center",
            fontsize=7.5,
            color=GREY,
        )
        if i < n - 1:
            ax.annotate(
                "",
                xy=(left + box_width + gap * 1.6, 0.50),
                xytext=(left + box_width + gap * 0.4, 0.50),
                arrowprops={"arrowstyle": "->", "color": TEAL, "lw": 1.1},
            )
    ax.set_xlim(0, 1)
    ax.set_ylim(0.05, 0.95)
    ax.set_title(
        "Intake chain: every statistic is conditional on this sequence", loc="left", pad=14
    )
    return _save(fig, out_dir, "figure_provenance_chain")


def write_all(results: dict, out_dir: str | Path) -> dict[str, Path]:
    """Draw whatever the available results support, skipping figures that lack inputs."""
    out = Path(out_dir)
    written: dict[str, Path] = {}

    provenance = results.get("provenance")
    if provenance:
        gates = pd.DataFrame(provenance["gates"])
        written["provenance_chain"] = provenance_schematic(gates, out)

    cohort = results.get("cohort")
    if cohort:
        written["cohort_attrition"] = cohort_attrition(pd.DataFrame(cohort["ladder"]), out)

    block_d = results.get("block_d")
    if block_d and "unweighted" in block_d:
        unweighted = pd.DataFrame(block_d["unweighted"])
        weighted = pd.DataFrame(block_d.get("weighted_trimmed") or block_d["weighted"])
        merged = unweighted.merge(
            weighted[["variable", "level", "abs_smd"]],
            on=["variable", "level"],
            suffixes=("_unweighted", "_weighted"),
        )
        merged["variable"] = merged["variable"] + ": " + merged["level"].astype(str)
        merged = merged.rename(
            columns={"abs_smd_unweighted": "abs_smd_unweighted", "abs_smd_weighted": "abs_smd_weighted"}
        )
        written["standardized_differences"] = standardized_differences(
            merged.sort_values("abs_smd_unweighted", ascending=False)
            .head(18)
            .sort_values("abs_smd_unweighted"),
            out,
        )

    block_f = results.get("block_f")
    if block_f and "simulation" in block_f and "threshold_curve" in block_f["simulation"]:
        curve = pd.DataFrame(block_f["simulation"]["threshold_curve"])
        if {"upper", "false_match_rate", "sensitivity"} <= set(curve.columns):
            point = block_f["simulation"]["at_pre_registered_operating_point"]["upper"]
            written["linkage_threshold"] = linkage_threshold_sensitivity(
                curve, out, operating_point=float(point)
            )
    return written
