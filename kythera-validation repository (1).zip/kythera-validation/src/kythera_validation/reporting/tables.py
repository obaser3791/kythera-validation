"""Table assembly: turn block result dictionaries into the manuscript's numbered tables.

Tables are written to CSV and to Markdown rather than to a typeset format. CSV is what a
reader re-analyses; Markdown is what a reader reads. Nothing here reformats a number: values
are written at the precision the manuscript reports them, and a value that came from the
licensed environment is labelled with its origin so it cannot be confused with a value the
package recomputed.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from ..config import load_conditions, load_reported_values, load_thresholds

ORIGIN_PUBLISHED = "published (licensed environment)"
ORIGIN_RECOMPUTED = "recomputed by this package"


def to_markdown(frame: pd.DataFrame, *, max_rows: int | None = 40) -> str:
    """Render a frame as a Markdown table without requiring an optional dependency."""
    shown = frame if max_rows is None or len(frame) <= max_rows else frame.head(max_rows)

    def cell(value: Any) -> str:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return ""
        text = str(value).replace("|", "\\|")
        return " ".join(text.split())

    header = "| " + " | ".join(str(c) for c in shown.columns) + " |"
    rule = "| " + " | ".join("---" for _ in shown.columns) + " |"
    body = [
        "| " + " | ".join(cell(v) for v in row) + " |"
        for row in shown.itertuples(index=False, name=None)
    ]
    out = [header, rule, *body]
    if len(shown) < len(frame):
        out.append(f"\n_{len(frame) - len(shown)} further row(s) in the CSV._")
    return "\n".join(out)


def _frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(rows)


def table_2_thresholds() -> pd.DataFrame:
    """Pre-registered thresholds with the alternatives that were considered and rejected."""
    rows = []
    for key, spec in sorted(load_thresholds().items()):
        rows.append(
            {
                "key": key,
                "block": spec.block,
                "metric": spec.metric,
                "operator": spec.operator,
                "threshold": spec.value,
                "source": spec.source,
                "alternatives_considered": "; ".join(
                    str(x) for x in spec.alternatives_considered
                ),
                "rationale": spec.rationale,
            }
        )
    return _frame(rows)


def table_4_condition_definitions() -> pd.DataFrame:
    """Claims-based condition definitions with published predictive values."""
    rows = []
    for key, spec in load_conditions()["conditions"].items():
        ppv = spec.get("published_ppv") or []
        rows.append(
            {
                "condition": key,
                "rule": spec.get("rule"),
                "icd10": ", ".join(spec.get("icd10", [])),
                "supporting_rx": ", ".join(spec.get("supporting_rx", []) or []),
                "published_ppv_low": ppv[0] if len(ppv) > 0 else None,
                "published_ppv_high": ppv[1] if len(ppv) > 1 else None,
                "source": spec.get("source"),
            }
        )
    return _frame(rows)


def table_7_internal_consistency(block_a: dict) -> pd.DataFrame:
    """Alpha with its interval, per construct."""
    rows = []
    for entry in block_a["internal_consistency"]:
        rows.append(
            {
                "construct": entry["construct"],
                "items": entry["items"],
                "n": entry["n"],
                "alpha": round(float(entry["alpha"]), 3),
                "ci_low": round(float(entry["alpha_ci"][0]), 3),
                "ci_high": round(float(entry["alpha_ci"][1]), 3),
                "threshold": entry["threshold"]["threshold"],
                "passes": entry["threshold"]["passes"],
                "origin": ORIGIN_RECOMPUTED,
            }
        )
    return _frame(rows)


def table_10_cfa(block_c: dict) -> pd.DataFrame:
    """Fit indices for the pre-registered model and for the one-factor alternative."""
    rows = []
    for label, key in (("Two-factor pre-registered model", "two_factor"), ("One-factor alternative", "one_factor")):
        fit = block_c.get(key)
        if not fit:
            continue
        rows.append(
            {
                "model": label,
                "chisq": round(float(fit["chisq"]), 1),
                "df": int(fit["df"]),
                "cfi": round(float(fit["cfi"]), 3),
                "tli": round(float(fit["tli"]), 3),
                "rmsea": round(float(fit["rmsea"]), 3),
                "srmr": round(float(fit["srmr"]), 3),
                "origin": ORIGIN_RECOMPUTED,
            }
        )
    published = load_reported_values()["table_10_cfa"]
    rows.append(
        {
            "model": "Two-factor model as reported in the manuscript",
            "chisq": None,
            "df": None,
            "cfi": published["cfi"],
            "tli": published["tli"],
            "rmsea": published["rmsea"],
            "srmr": published["srmr"],
            "origin": ORIGIN_PUBLISHED,
        }
    )
    frame = _frame(rows)
    frame["factor_correlation"] = [
        round(float(block_c.get("factor_correlation", float("nan"))), 3)
        if r["origin"] == ORIGIN_RECOMPUTED
        else published["factor_correlation"]
        for r in rows
    ]
    return frame


def table_12_linkage(block_f: dict) -> pd.DataFrame:
    """The adjudicated linkage 2x2 and the operating characteristics derived from it."""
    accuracy = block_f["adjudication"]["accuracy"]
    counts = accuracy["counts"]
    rows = [
        {"quantity": "True matches", "value": counts["tp"], "ci_low": None, "ci_high": None,
         "origin": ORIGIN_PUBLISHED},
        {"quantity": "False matches", "value": counts["fp"], "ci_low": None, "ci_high": None,
         "origin": ORIGIN_PUBLISHED},
        {"quantity": "Missed matches", "value": counts["fn"], "ci_low": None, "ci_high": None,
         "origin": ORIGIN_PUBLISHED},
        {"quantity": "True non-matches", "value": counts["tn"], "ci_low": None, "ci_high": None,
         "origin": ORIGIN_PUBLISHED},
    ]
    for name in ("sensitivity", "specificity", "ppv", "npv"):
        estimate, low, high = accuracy[name]
        rows.append(
            {
                "quantity": name.upper() if name in {"ppv", "npv"} else name.capitalize(),
                "value": round(float(estimate), 4),
                "ci_low": round(float(low), 4),
                "ci_high": round(float(high), 4),
                "origin": ORIGIN_RECOMPUTED,
            }
        )
    rows.append(
        {
            "quantity": "False-match rate",
            "value": round(float(accuracy["false_match_rate"]), 5),
            "ci_low": round(float(accuracy["false_match_rate_ci"][0]), 5),
            "ci_high": round(float(accuracy["false_match_rate_ci"][1]), 5),
            "origin": ORIGIN_RECOMPUTED,
        }
    )
    rows.append(
        {
            "quantity": "Match rate",
            "value": round(float(block_f["match_rate"]["rate"]), 4),
            "ci_low": round(float(block_f["match_rate"]["ci"][0]), 4),
            "ci_high": round(float(block_f["match_rate"]["ci"][1]), 4),
            "origin": ORIGIN_PUBLISHED,
        }
    )
    return _frame(rows)


def table_15_condition_agreement(block_g: dict) -> pd.DataFrame:
    """Per-condition adjudication agreement, with the operational definition alongside it."""
    categories = pd.DataFrame(block_g["categories"])
    definitions = pd.DataFrame(block_g["definitions"])
    frame = categories.merge(
        definitions[["condition", "rule", "icd10_codes", "published_ppv"]],
        on="condition",
        how="left",
    )
    frame["origin"] = ORIGIN_PUBLISHED
    ordered = [
        "condition",
        "kappa",
        "agreement_strength",
        "meets_threshold",
        "ppv",
        "sensitivity",
        "specificity",
        "published_ppv",
        "rule",
        "icd10_codes",
        "origin",
    ]
    return frame[[c for c in ordered if c in frame.columns]]


def table_16_predictive(block_i: dict) -> pd.DataFrame:
    """Discrimination and calibration for every outcome and splitting scheme."""
    rows: list[dict[str, Any]] = []
    for outcome, schemes in block_i["published"].items():
        for scheme, values in schemes.items():
            auroc = values.get("auroc")
            brier = values.get("brier")
            slope = values.get("slope")
            rows.append(
                {
                    "outcome": outcome,
                    "scheme": scheme.replace("_", " "),
                    "auroc": (
                        f"{auroc[0]:.3f}-{auroc[1]:.3f}" if isinstance(auroc, list) else auroc
                    ),
                    "brier": (
                        f"{brier[0]:.3f}-{brier[1]:.3f}" if isinstance(brier, list) else brier
                    ),
                    "calibration_slope": (
                        f"{slope[0]:.2f}-{slope[1]:.2f}" if isinstance(slope, list) else slope
                    ),
                    "origin": ORIGIN_PUBLISHED,
                }
            )
    for outcome, schemes in block_i.get("recomputed", {}).items():
        for scheme, values in schemes.items():
            if scheme == "leave_one_region_out":
                rows.append(
                    {
                        "outcome": outcome,
                        "scheme": "leave-one-region-out (range)",
                        "auroc": f"{values['auroc_range'][0]:.3f}-{values['auroc_range'][1]:.3f}",
                        "brier": f"{values['brier_range'][0]:.4f}-{values['brier_range'][1]:.4f}",
                        "calibration_slope": (
                            f"{values['calibration_slope_range'][0]:.2f}"
                            f"-{values['calibration_slope_range'][1]:.2f}"
                        ),
                        "origin": ORIGIN_RECOMPUTED,
                    }
                )
            else:
                rows.append(
                    {
                        "outcome": outcome,
                        "scheme": scheme.replace("_", " "),
                        "auroc": round(float(values["auroc"]), 3),
                        "brier": round(float(values["brier"]), 4),
                        "calibration_slope": round(float(values["calibration_slope"]), 2),
                        "origin": ORIGIN_RECOMPUTED,
                    }
                )
    return _frame(rows)


def table_17_rwd_comparison() -> pd.DataFrame:
    """Comparison against the other real-world data assets reported in the manuscript."""
    reported = load_reported_values().get("table_17_rwd_comparison", {})
    rows = []
    for name, values in reported.items():
        row = {"asset": name}
        row.update(values if isinstance(values, dict) else {"value": values})
        row["origin"] = ORIGIN_PUBLISHED
        rows.append(row)
    return _frame(rows)


def write_tables(tables: dict[str, pd.DataFrame], out_dir: str | Path) -> dict[str, Path]:
    """Write every table to CSV and to a Markdown copy, and return the paths."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written: dict[str, Path] = {}
    index_lines = ["# Tables", ""]
    for name, frame in tables.items():
        csv_path = out / f"{name}.csv"
        frame.to_csv(csv_path, index=False)
        written[name] = csv_path
        index_lines.append(f"## {name}")
        index_lines.append("")
        index_lines.append(to_markdown(frame))
        index_lines.append("")
    (out / "tables.md").write_text("\n".join(index_lines), encoding="utf-8")
    written["tables_markdown"] = out / "tables.md"
    return written


def threshold_summary(results: dict[str, dict]) -> pd.DataFrame:
    """One row per pre-registered threshold, with the observed value and the verdict.

    This is the table a reader should look at first. A block that reports many statistics can
    look convincing while quietly failing the one criterion that was fixed in advance, and the
    only protection against that is a summary that lists the pre-registered criteria and
    nothing else.
    """
    rows: list[dict[str, Any]] = []

    def walk(node: Any, block: str, context: str) -> None:
        if isinstance(node, dict):
            if {"key", "observed", "operator", "threshold", "passes"} <= set(node):
                rows.append(
                    {
                        "block": block,
                        "key": node["key"],
                        "context": context or "block-level",
                        "metric": node.get("metric"),
                        "observed": node["observed"],
                        "operator": node["operator"],
                        "threshold": node["threshold"],
                        "passes": node["passes"],
                    }
                )
                return
            for name, value in node.items():
                child = context
                if name not in {"threshold", "thresholds"}:
                    child = f"{context}/{name}" if context else str(name)
                walk(value, block, child)
        elif isinstance(node, list):
            for index, value in enumerate(node):
                label = (
                    value.get("construct")
                    or value.get("condition")
                    or value.get("held_out_region")
                    or value.get("variable")
                    if isinstance(value, dict)
                    else None
                )
                walk(value, block, f"{context}[{label or index}]")

    for block, result in results.items():
        walk(result, block, "")
    frame = _frame(rows)
    if not frame.empty:
        frame = frame.drop_duplicates(subset=["block", "key", "context", "observed"]).sort_values(
            ["block", "key", "context"]
        )
        frame = frame[
            ["block", "key", "context", "metric", "observed", "operator", "threshold", "passes"]
        ]
    return frame


def write_results_json(results: dict, path: str | Path) -> Path:
    """Serialise the full result set, converting numpy scalars to plain Python."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    def default(value: Any) -> Any:
        if hasattr(value, "item"):
            return value.item()
        if isinstance(value, pd.DataFrame):
            return value.to_dict("records")
        if isinstance(value, (set, tuple)):
            return list(value)
        return str(value)

    target.write_text(json.dumps(results, indent=2, default=default), encoding="utf-8")
    return target
