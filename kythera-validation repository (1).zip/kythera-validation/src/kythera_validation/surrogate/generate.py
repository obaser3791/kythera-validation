"""Surrogate analytic file with the schema, cardinality and margins of the licensed data.

The licensed Kythera Labs asset cannot be redistributed. This module writes a file with
the same relational shape, the same field names and types, the same marginal
distributions and the same missingness pattern as the analytic cohort, so that every code
path in the package - all seventeen equations, all nine blocks, the linkage machinery and
the reporting layer - can be executed and audited end to end by a reader without a data
use agreement.

The surrogate contains no record derived from any person. Its marginals are taken from the
published cohort description in the manuscript, its missingness rates from the missingness
table, and its correlation structure from the confirmatory factor model, so results
computed on it are structurally comparable with the reported analysis while its point
estimates are properties of the generator rather than of the health-care system.

Usage::

    python -m kythera_validation.cli surrogate --n 250000 --seed 20250731 --out outputs/surrogate
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from ..config import load_cfa_model, load_reported_values

AGE_BANDS = ["<18", "18-44", "45-64", "65-74", "75+"]
AGE_BOUNDS = {"<18": (0, 17), "18-44": (18, 44), "45-64": (45, 64), "65-74": (65, 74), "75+": (75, 95)}
RACES = ["NH_White", "Hispanic", "NH_Black", "Asian_PI", "Other"]
PAYERS = ["Commercial", "Medicare", "Medicaid"]
REGIONS = ["Northeast", "Midwest", "South", "West", "Other"]

# Missingness rates by field, from the pooled column of the missingness table.
MISSINGNESS = {
    "income_band": 0.248,
    "housing_instability_proxy": 0.221,
    "employment_sector_proxy": 0.197,
    "prior_year_plan_type": 0.173,
    "rucc_code": 0.152,
    "race_ethnicity": 0.146,
    "group_individual": 0.139,
    "medicaid_dual_flag": 0.124,
    "primary_care_attribution": 0.114,
    "facility_type": 0.083,
    "provider_specialty": 0.051,
}


@dataclass
class SurrogateSpec:
    n: int = 250_000
    seed: int = 20_250_731
    start: str = "2015-01-01"
    end: str = "2025-07-31"


def _categorical(rng: np.random.Generator, n: int, labels: list[str], pct: dict[str, float]) -> np.ndarray:
    p = np.array([pct[k] for k in labels], dtype=float)
    return rng.choice(labels, size=n, p=p / p.sum())


def generate(spec: SurrogateSpec | None = None) -> dict[str, pd.DataFrame]:
    """Build the surrogate relational model and return it as a dict of frames."""
    spec = spec or SurrogateSpec()
    rng = np.random.default_rng(spec.seed)
    n = spec.n
    rep = load_reported_values()
    cohort = rep["table_5_cohort"]

    # ---------------------------------------------------------------- patient table
    band = _categorical(rng, n, AGE_BANDS, cohort["age_bands"])
    age = np.empty(n)
    for b in AGE_BANDS:
        mask = band == b
        lo, hi = AGE_BOUNDS[b]
        age[mask] = rng.integers(lo, hi + 1, mask.sum())
    # Ages are drawn uniformly inside each published band, so the band shares reproduce
    # the cohort description exactly while the pooled mean is whatever those shares imply
    # (about 39 years). The surrogate matches the distribution that was published, not a
    # separately published summary statistic of it.
    sex = rng.choice(["F", "M"], n, p=[cohort["female_pct"] / 100, 1 - cohort["female_pct"] / 100])
    race = _categorical(rng, n, RACES, cohort["race"])
    region = _categorical(rng, n, REGIONS, cohort["region"])

    # Payer depends on age, as it does in the population: Medicare is concentrated at 65+.
    payer = np.empty(n, dtype=object)
    for b in AGE_BANDS:
        mask = band == b
        if b in ("65-74", "75+"):
            probs = [0.14, 0.79, 0.07]
        elif b == "<18":
            probs = [0.55, 0.00, 0.45]
        else:
            probs = [0.66, 0.02, 0.32]
        payer[mask] = rng.choice(PAYERS, mask.sum(), p=probs)

    # Latent social risk drives the Block C indicators, so their correlation structure
    # matches the two-factor model rather than being independent noise.
    cfa = load_cfa_model()
    phi = float(cfa["factor_correlation"]["economic_adversity__care_access"])
    lat = rng.multivariate_normal([0.0, 0.0], [[1.0, phi], [phi, 1.0]], size=n)
    econ, access = lat[:, 0], lat[:, 1]

    def ordinal(latent: np.ndarray, loading: float) -> np.ndarray:
        y = loading * latent + np.sqrt(max(1 - loading**2, 1e-6)) * rng.normal(size=n)
        cuts = np.quantile(y, [0.2, 0.4, 0.6, 0.8])
        return np.digitize(y, cuts) + 1

    def binary(latent: np.ndarray, loading: float, prevalence: float) -> np.ndarray:
        y = loading * latent + np.sqrt(max(1 - loading**2, 1e-6)) * rng.normal(size=n)
        return (y > np.quantile(y, 1 - prevalence)).astype(int)

    ind = {}
    for factor_key, latent in (("economic_adversity", econ), ("care_access", access)):
        for item in cfa["factors"][factor_key]["indicators"]:
            name, load = item["name"], float(item["loading"])
            if item["coding"].startswith("ordinal"):
                ind[name] = ordinal(latent, load)
            else:
                ind[name] = binary(latent, load, 0.35)

    # Utilisation: negative binomial with the reported mean and dispersion, shifted by
    # age and by social risk so that the known-group separation in Block A is present.
    mean_lines = float(cohort["mean_claim_lines"])
    sd_lines = float(cohort["sd_claim_lines"])
    disp = mean_lines**2 / max(sd_lines**2 - mean_lines, 1.0)
    lam = mean_lines * np.exp(0.012 * (age - age.mean()) / 10 + 0.15 * econ)
    claim_lines = rng.negative_binomial(disp, disp / (disp + lam)).astype(int) + 1
    medical_claims = rng.binomial(claim_lines, 0.55)
    pharmacy_claims = claim_lines - medical_claims
    inpatient = rng.poisson(np.clip(0.087 * np.exp(0.4 * econ + 0.02 * (age - 40) / 10), 0, 5))
    ed_visits = rng.poisson(np.clip(0.416 * np.exp(0.5 * econ), 0, 8))
    outpatient = rng.poisson(np.clip(5.842 * np.exp(0.2 * econ), 0, 60))

    # Observability is a mixture, not a single distribution. Roughly a fifth of patients are
    # seen briefly and then disappear from the contributed data, and they are the patients the
    # two-observation requirement removes. Drawing observability from a single long-tailed
    # distribution would make every patient look continuously enrolled and would hide the
    # ascertainment effect that the cohort sensitivity analysis exists to measure.
    short_spell = rng.random(n) < 0.22
    observability_months = np.where(
        short_spell,
        rng.integers(2, 24, n),
        24 + np.round(rng.beta(2.2, 1.5, n) * 102).astype(int),
    ).astype(int)
    continuous_2y = (observability_months >= 24).astype(int)

    # Ascertainment: a condition present in a patient is recorded only if the patient is
    # observed long enough for the qualifying codes to appear. Short-spell patients therefore
    # carry systematically fewer flags, which is why claims-based prevalence is a statement
    # about observable patients.
    detection = np.where(
        observability_months >= 24, 1.0, 0.55 + 0.45 * observability_months / 24.0
    )

    patients = pd.DataFrame(
        {
            "patient_token": [f"T{i:09d}" for i in range(n)],
            "age": age.astype(int),
            "age_band": band,
            "sex": sex,
            "race_ethnicity": race,
            "region": region,
            "payer": payer,
            "medicaid_dual_flag": (payer == "Medicaid").astype(int),
            "observable_months": observability_months,
            "continuous_2y": continuous_2y,
            "claim_lines": claim_lines,
            "medical_claims": medical_claims,
            "pharmacy_claims": pharmacy_claims,
            "inpatient_admissions": inpatient,
            "ed_visits": ed_visits,
            "outpatient_visits": outpatient,
            "income_band": np.clip(6 - ind["tract_poverty_quintile"], 1, 5),
            "rucc_code": rng.integers(1, 10, n),
            "employment_sector_proxy": rng.integers(1, 21, n),
            "prior_year_plan_type": rng.choice(["HMO", "PPO", "EPO", "POS", "FFS"], n),
            "group_individual": rng.choice(["group", "individual"], n, p=[0.82, 0.18]),
            "facility_type": rng.choice(["hospital", "clinic", "asc", "office", "other"], n),
            "provider_specialty": rng.choice(
                ["internal_medicine", "family_medicine", "cardiology", "psychiatry", "other"], n
            ),
            **{k: v for k, v in ind.items()},
        }
    )

    # ---------------------------------------------------------------- condition flags
    # Prevalences equal the reported claims-side estimates; risk rises with age and with
    # economic adversity, which is what makes the known-group comparisons in Block A move.
    prevalences = {
        "diabetes": 0.118,
        "hypertension": 0.479,
        "hyperlipidemia": 0.381,
        "depression": 0.090,
        "atrial_fibrillation": 0.019,
        "copd": 0.064,
        "heart_failure": 0.042,
        "ckd": 0.061,
        "malignancy": 0.058,
        "substance_use": 0.037,
    }
    age_z = (age - age.mean()) / age.std()
    mean_detection = float(detection.mean())
    for cond, prev in prevalences.items():
        beta_age = 0.9 if cond in ("hypertension", "atrial_fibrillation", "heart_failure", "ckd") else 0.5
        eta = beta_age * age_z + 0.25 * econ + rng.normal(size=n)
        # The latent prevalence is inflated by the mean detection probability so that the
        # recorded prevalence after ascertainment equals the published claims-side estimate.
        latent_prev = min(prev / mean_detection, 0.99)
        present = eta > np.quantile(eta, 1 - latent_prev)
        patients[cond] = (present & (rng.random(n) < detection)).astype(int)

    # Elixhauser-style component flags for Block A internal consistency.
    # Component flags load on a single morbidity dimension, which is the structure that
    # gives a multi-item comorbidity index its internal consistency. A reference-definition
    # counterpart is generated for every flag so that component-level agreement can be
    # examined next to alpha, since a coherent index can still disagree item by item with
    # an independently specified definition of the same condition.
    burden = 0.7 * age_z + 0.5 * econ
    for j in range(31):
        base = 0.02 + 0.10 * rng.random()
        eta = burden + rng.normal(size=n) * 0.95
        flag = (eta > np.quantile(eta, 1 - base)).astype(int)
        patients[f"elix_{j + 1:02d}"] = flag
        reference = eta + rng.normal(scale=0.35, size=n)
        patients[f"elixref_{j + 1:02d}"] = (
            reference > np.quantile(reference, 1 - base)
        ).astype(int)
    for j in range(17):
        base = 0.02 + 0.08 * rng.random()
        eta = burden + rng.normal(size=n) * 0.74
        patients[f"charlson_{j + 1:02d}"] = (eta > np.quantile(eta, 1 - base)).astype(int)

    # Two non-overlapping twelve-month windows for the test-retest coefficient. The stable
    # component is the patient's underlying morbidity; the window-specific component is
    # the encounter noise that any claims-based count inherits from care-seeking.
    true_score = burden + 0.3 * rng.normal(size=n)
    patients["elix_count_window1"] = np.clip(
        np.round(3 + 1.4 * true_score + rng.normal(scale=0.55, size=n)), 0, 31
    )
    patients["elix_count_window2"] = np.clip(
        np.round(3 + 1.4 * true_score + rng.normal(scale=0.55, size=n)), 0, 31
    )

    # ---------------------------------------------------------------- outcomes
    mortality_eta = -4.2 + 1.55 * age_z + 0.45 * patients["heart_failure"] + 0.35 * patients["ckd"] \
        + 0.02 * np.log1p(patients["inpatient_admissions"]) + 0.30 * econ
    patients["mortality_90d"] = rng.binomial(1, 1 / (1 + np.exp(-mortality_eta)))
    readmit_eta = (
        -3.4
        + 0.85 * age_z
        + 0.95 * patients["heart_failure"]
        + 0.55 * patients["copd"]
        + 0.50 * patients["ckd"]
        + 0.30 * patients["diabetes"]
        + 0.30 * econ
        + 0.45 * np.log1p(patients["ed_visits"])
        + 0.35 * np.log1p(patients["inpatient_admissions"])
    )
    patients["readmission_30d"] = rng.binomial(1, 1 / (1 + np.exp(-readmit_eta)))
    patients["index_year"] = rng.choice(range(2015, 2026), n)
    patients["index_quarter"] = (
        patients["index_year"].astype(str) + "Q" + rng.integers(1, 5, n).astype(str)
    )
    # Calendar period bands match the stratification used in the linkage and missingness
    # tables, and the contributor cohort records which wave of data contributors a patient's
    # claims came from. Both are needed as columns rather than as derived quantities, because
    # the missingness gradient and the temporal holdout are both defined on them.
    patients["period"] = np.where(
        patients["index_year"] <= 2018,
        "2015-2018",
        np.where(patients["index_year"] <= 2021, "2019-2021", "2022-2025"),
    )
    patients["contributor_cohort"] = _categorical(
        rng, n, ["P1", "P2", "P3"], {"P1": 34.0, "P2": 41.0, "P3": 25.0}
    )

    # ---------------------------------------------------------------- missingness
    # Missing at random conditional on calendar period and payer, reproducing the
    # observed gradient: token-joined reference attributes are missing far more often in
    # the early period than in the recent one.
    period_factor = np.where(patients["index_year"] <= 2018, 1.31, np.where(patients["index_year"] <= 2021, 0.97, 0.79))
    for field, rate in MISSINGNESS.items():
        if field not in patients.columns:
            continue
        p_miss = np.clip(rate * period_factor, 0, 0.95)
        mask = rng.random(n) < p_miss
        patients.loc[mask, field] = np.nan

    return {"patients": patients}


def write(out_dir: str | Path, spec: SurrogateSpec | None = None) -> dict[str, Path]:
    """Generate and persist the surrogate file set as parquet with a CSV fallback."""
    spec = spec or SurrogateSpec()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    frames = generate(spec)
    written: dict[str, Path] = {}
    for name, frame in frames.items():
        target = out / f"{name}.parquet"
        try:
            frame.to_parquet(target, index=False)
        except (ImportError, ValueError):
            target = out / f"{name}.csv"
            frame.to_csv(target, index=False)
        written[name] = target
    manifest = out / "MANIFEST.txt"
    manifest.write_text(
        "Surrogate analytic file for the nine-block validation package.\n"
        f"rows: {spec.n}\nseed: {spec.seed}\nperiod: {spec.start} to {spec.end}\n"
        "This file contains no record derived from any person. Marginal distributions,\n"
        "missingness rates and the social-risk correlation structure follow the published\n"
        "cohort description; point estimates computed on it are properties of the\n"
        "generator and are not estimates of any health-care quantity.\n"
    )
    written["manifest"] = manifest
    return written


def load(out_dir: str | Path) -> pd.DataFrame:
    """Read a previously written surrogate patient table."""
    out = Path(out_dir)
    for candidate in (out / "patients.parquet", out / "patients.csv"):
        if candidate.exists():
            return pd.read_parquet(candidate) if candidate.suffix == ".parquet" else pd.read_csv(candidate)
    raise FileNotFoundError(f"no surrogate patient table found in {out}")
