"""Intake quality assurance: the provenance chain from clearinghouse to analytic table.

Every validation statistic in this package is conditional on the transformations recorded
here. A prevalence estimate computed after duplicate lines are removed and pharmacy reversals
are netted is a different quantity from one computed before, and the difference is not small.
The intake gates below are therefore reported as a table with the share of records affected at
each gate, and the analytic file is defined as the output of the last gate rather than as
"the claims data".

Two gates deserve emphasis. Reversal netting is what makes a pharmacy fill count a fill rather
than a transaction, and 1.70 per cent of pharmacy lines are reversals; a study that counts
transactions overstates utilisation by roughly that amount. Token availability is 21.7 per
cent of the source universe, and that single number bounds every linkage-dependent analysis in
the paper: the remaining 78.3 per cent are not missing at random with respect to care setting
or contributor.
"""

from __future__ import annotations

import pandas as pd

from ..config import (
    check,
    load_provenance_thresholds,
    load_reported_values,
    load_study_parameters,
)

# The intake gates in the order they are applied. "direction" records whether a high value is
# good, so a reader can tell a pass rate from a removal rate without consulting the text.
GATES: tuple[dict[str, str], ...] = (
    {
        "gate": "manifest_receipt",
        "stage": "receipt",
        "description": "Files received against the contributor manifest for the expected period.",
        "direction": "higher is better",
        "standard": "Contributor submission manifest",
    },
    {
        "gate": "x12_837_syntax",
        "stage": "syntax",
        "description": "Medical claim lines passing ANSI X12 837 syntactic validation.",
        "direction": "higher is better",
        "standard": "ASC X12N 837 Implementation Guide",
    },
    {
        "gate": "ncpdp_d0_conformance",
        "stage": "syntax",
        "description": "Pharmacy transactions conforming to NCPDP Telecommunication D.0.",
        "direction": "higher is better",
        "standard": "NCPDP Telecommunication Standard D.0",
    },
    {
        "gate": "icd10cm_validity",
        "stage": "code validity",
        "description": "Diagnosis codes valid in the ICD-10-CM version in force on the service date.",
        "direction": "higher is better",
        "standard": "CMS ICD-10-CM release for the service year",
    },
    {
        "gate": "cpt_hcpcs_validity",
        "stage": "code validity",
        "description": "Procedure codes valid in the CPT/HCPCS release in force on the service date.",
        "direction": "higher is better",
        "standard": "AMA CPT and CMS HCPCS releases",
    },
    {
        "gate": "ndc_rxnorm_resolution",
        "stage": "code validity",
        "description": "National Drug Codes resolving to an RxNorm concept.",
        "direction": "higher is better",
        "standard": "NLM RxNorm monthly release",
    },
    {
        "gate": "duplicate_lines_removed",
        "stage": "deduplication",
        "description": "Claim lines removed as exact or near-exact duplicates.",
        "direction": "reported as a removal share",
        "standard": "Line-level key of member, provider, service date, code and units",
    },
    {
        "gate": "reversals_netted",
        "stage": "deduplication",
        "description": "Pharmacy lines netted out as reversals against an original fill.",
        "direction": "reported as a removal share",
        "standard": "NCPDP reversal transaction matched to the original claim",
    },
    {
        "gate": "member_key_resolution",
        "stage": "entity resolution",
        "description": "Claim lines resolving to a stable member key within contributor.",
        "direction": "higher is better",
        "standard": "Contributor member identifier plus eligibility segment",
    },
    {
        "gate": "provider_npi_resolution",
        "stage": "entity resolution",
        "description": "Lines whose rendering provider resolves to an active NPI.",
        "direction": "higher is better",
        "standard": "NPPES monthly file",
    },
    {
        "gate": "token_availability",
        "stage": "tokenization",
        "description": "Share of the source universe carrying a usable privacy-preserving token.",
        "direction": "higher is better; bounds every linkage analysis",
        "standard": "Vendor tokenization specification",
    },
    {
        "gate": "records_quarantined",
        "stage": "release",
        "description": "Records held back from the analytic release pending contributor query.",
        "direction": "reported as a removal share",
        "standard": "Intake exception queue",
    },
    {
        "gate": "weeks_flagged",
        "stage": "release",
        "description": "Contributor-weeks flagged for volume anomaly against their own history.",
        "direction": "reported as a flag share",
        "standard": "Statistical process control on weekly line volume",
    },
)


def gate_table() -> pd.DataFrame:
    """The intake QA table with observed values, applicable limits and pass or fail.

    The limits are the generic provenance criteria in ``config/thresholds.yaml``: a
    conformance floor for every syntax and code-validity gate, a referential-integrity floor
    for the entity-resolution gates, and a quarantine ceiling. Gates that are descriptive
    rather than pass-or-fail - the duplicate and reversal shares, token availability, and the
    flagged-week share - carry no limit and are reported as observed, because there is no
    defensible threshold on how many duplicates a contributor ought to have submitted.
    """
    observed = load_reported_values()["table_1_intake_qa"]
    limits = load_provenance_thresholds()
    conformance = float(limits.get("conformance_min", 0.995))
    integrity = float(limits.get("referential_integrity_min", 0.980))
    quarantine = float(limits.get("quarantine_max", 0.005))

    applicable: dict[str, tuple[float, str]] = {
        "manifest_receipt": (conformance, ">="),
        "x12_837_syntax": (conformance, ">="),
        "ncpdp_d0_conformance": (conformance, ">="),
        "icd10cm_validity": (conformance, ">="),
        "cpt_hcpcs_validity": (conformance, ">="),
        "ndc_rxnorm_resolution": (conformance, ">="),
        "member_key_resolution": (integrity, ">="),
        "provider_npi_resolution": (integrity, ">="),
        "records_quarantined": (quarantine, "<="),
    }

    rows = []
    for gate in GATES:
        name = gate["gate"]
        value = observed.get(name)
        row: dict = {**gate, "observed": value}
        if name in applicable and value is not None:
            limit, operator = applicable[name]
            row["limit"] = limit
            row["operator"] = operator
            row["passes"] = float(value) >= limit if operator == ">=" else float(value) <= limit
        else:
            row["limit"] = None
            row["operator"] = None
            row["passes"] = None
        rows.append(row)
    return pd.DataFrame(rows)


def latency() -> dict:
    """Median and interquartile lag from date of service to availability in the release."""
    observed = load_reported_values()["table_1_intake_qa"]
    return {
        "median_days": int(observed["latency_median_days"]),
        "iqr_days": [int(x) for x in observed["latency_iqr_days"]],
        "implication": " ".join(
            """Claims accrue after the date of service, so a recent month is incomplete when it
            is first observed. Any analysis whose observation window reaches the edge of the
            release will understate utilisation in the final weeks, and the interquartile lag is
            the minimum run-out that has to be allowed before a period is treated as
            complete.""".split()
        ),
    }


def conditionality_statement() -> str:
    """What the validation statistics are conditional on."""
    return " ".join(
        """Every estimate in this package is conditional on the intake chain above. Duplicate
        removal, reversal netting, member-key resolution and the tokenization step each change
        the denominator, and none of them is reversible from the analytic file. A reader
        comparing these estimates to another data asset is therefore comparing two intake
        chains as well as two populations, and the gate table is what makes the first of those
        comparisons possible.""".split()
    )


def run() -> dict:
    """Assemble the provenance result set."""
    table = gate_table()
    checked = table[table["passes"].notna()]
    return {
        "gates": table.to_dict("records"),
        "gates_evaluated": int(len(checked)),
        "gates_failing": checked.loc[~checked["passes"].astype(bool), "gate"].tolist(),
        "token_availability": float(load_reported_values()["table_1_intake_qa"]["token_availability"]),
        "reversal_share": float(load_reported_values()["table_1_intake_qa"]["reversals_netted"]),
        "latency": latency(),
        "conditionality": conditionality_statement(),
    }


def cohort_attrition() -> pd.DataFrame:
    """The cohort construction ladder, with the share retained at each step."""
    study = load_study_parameters()
    steps = [
        ("Source universe of distinct patients", study["source_universe_tokens"]),
        ("Carrying a usable token", study["token_linked_subset"]),
        ("At least two observations", study["cohort_two_observations"]),
        ("Final analytic cohort", study["analytic_cohort"]),
    ]
    frame = pd.DataFrame(steps, columns=["step", "n"])
    frame["share_of_source"] = frame["n"] / frame["n"].iloc[0]
    frame["retained_from_previous"] = frame["n"] / frame["n"].shift(1)
    return frame


def verify_cohort_counts() -> dict:
    """Check that the cohort ladder is monotone and matches the reported final count."""
    frame = cohort_attrition()
    reported = int(load_reported_values()["table_5_cohort"]["n"])
    return {
        "monotone": bool((frame["n"].diff().dropna() < 0).all()),
        "final_matches_table_5": int(frame["n"].iloc[-1]) == reported,
        "ladder": frame.to_dict("records"),
        "token_availability_check": check(
            "F_match_rate", float(load_reported_values()["table_12_linkage_overall"]["match_rate"])
        ),
    }
