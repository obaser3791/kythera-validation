"""Command-line entry point: ``kythera-validate``.

The interface is deliberately narrow. ``run`` executes blocks against a data file, ``surrogate``
writes the surrogate analytic file, ``thresholds`` prints the pre-registered criteria, and
``verify`` checks the package's recomputed values against the values the manuscript reports.

``verify`` is the command that matters. A reproduction package that only runs its own code
proves nothing; what a reader needs is the comparison between what the code produces and what
the paper claims, with a non-zero exit status when they disagree.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import pandas as pd

from . import __version__
from .blocks import (
    block_a_internal_consistency,
    block_b_external_consistency,
    block_c_construct_validity,
    block_d_representativeness,
    block_e_missingness,
    block_f_linkage,
    block_g_intercoder,
    block_h_temporal,
    block_i_predictive,
)
from .cohort import build as cohort_build
from .config import load_reported_values, load_thresholds
from .provenance import intake_qa
from .reporting import figures, tables
from .surrogate import generate as surrogate

BLOCK_ORDER = ("A", "B", "C", "D", "E", "F", "G", "H", "I")
DEFAULT_SEED = 20250731
DEFAULT_N = 250_000


def _load_frame(path: str | Path) -> pd.DataFrame:
    """Read the analytic file, accepting parquet or delimited text."""
    target = Path(path)
    if not target.exists():
        raise FileNotFoundError(f"no such data file: {target}")
    if target.suffix in {".parquet", ".pq"}:
        return pd.read_parquet(target)
    if target.suffix in {".csv", ".gz"}:
        return pd.read_csv(target)
    if target.suffix in {".tsv", ".txt"}:
        return pd.read_csv(target, sep="\t")
    raise ValueError(f"unsupported data file extension: {target.suffix}")


def _run_blocks(
    frame: pd.DataFrame | None,
    which: tuple[str, ...],
    *,
    seed: int,
    simulate_linkage: bool,
    n_pairs: int,
    imputations: int,
) -> dict[str, Any]:
    """Execute the requested blocks and return their results keyed by block letter."""
    results: dict[str, Any] = {}
    if "A" in which and frame is not None:
        results["block_a"] = block_a_internal_consistency.run(frame)
    if "B" in which:
        results["block_b"] = block_b_external_consistency.run(frame)
    if "C" in which and frame is not None:
        results["block_c"] = block_c_construct_validity.run(frame)
    if "D" in which and frame is not None:
        results["block_d"] = block_d_representativeness.run(frame)
    if "E" in which and frame is not None:
        results["block_e"] = block_e_missingness.run(frame, m=imputations, seed=seed)
    if "F" in which:
        results["block_f"] = block_f_linkage.run(
            simulate=simulate_linkage, n_pairs=n_pairs, seed=seed
        )
    if "G" in which:
        results["block_g"] = block_g_intercoder.run()
    if "H" in which:
        series = None
        if frame is not None and {"index_quarter", "claim_lines"} <= set(frame.columns):
            series = block_h_temporal.quarterly_series(
                frame.rename(columns={"index_quarter": "quarter"}), "claim_lines"
            )
        results["block_h"] = block_h_temporal.run(series=series)
    if "I" in which and frame is not None:
        results["block_i"] = block_i_predictive.run(frame, seed=seed)
    return results


def _print_threshold_summary(summary: pd.DataFrame) -> int:
    """Print the pre-registered threshold table and return the number of failures."""
    if summary.empty:
        print("No pre-registered thresholds were evaluated by the selected blocks.")
        return 0
    print("\nPre-registered thresholds")
    print(summary.to_string(index=False))
    failures = summary.loc[~summary["passes"].astype(bool)]
    if len(failures):
        print(f"\n{len(failures)} threshold(s) not met:")
        for _, row in failures.iterrows():
            print(
                f"  {row['key']} ({row['context']}): observed {row['observed']:.4f} "
                f"vs {row['operator']} {row['threshold']}"
            )
    else:
        print("\nAll evaluated thresholds met.")
    return int(len(failures))


def cmd_run(args: argparse.Namespace) -> int:
    """Execute the pipeline and write tables, figures and the result JSON."""
    which = tuple(b.upper() for b in (args.blocks or BLOCK_ORDER))
    unknown = set(which) - set(BLOCK_ORDER)
    if unknown:
        raise SystemExit(f"unknown block(s): {', '.join(sorted(unknown))}")

    frame = None
    if args.data:
        frame = _load_frame(args.data)
    elif not args.no_surrogate:
        frame = surrogate.generate(surrogate.SurrogateSpec(n=args.n, seed=args.seed))["patients"]
    if frame is not None and args.sample and args.sample < len(frame):
        frame = frame.sample(args.sample, random_state=args.seed).reset_index(drop=True)

    results: dict[str, Any] = {
        "package_version": __version__,
        "seed": args.seed,
        "rows_analysed": int(len(frame)) if frame is not None else None,
        "provenance": intake_qa.run(),
        "cohort": cohort_build.run(frame),
    }
    results.update(
        _run_blocks(
            frame,
            which,
            seed=args.seed,
            simulate_linkage=args.simulate_linkage,
            n_pairs=args.n_pairs,
            imputations=args.imputations,
        )
    )

    out = Path(args.out)
    built: dict[str, pd.DataFrame] = {
        "table_02_thresholds": tables.table_2_thresholds(),
        "table_04_condition_definitions": tables.table_4_condition_definitions(),
        "table_17_rwd_comparison": tables.table_17_rwd_comparison(),
    }
    if "block_a" in results:
        built["table_07_internal_consistency"] = tables.table_7_internal_consistency(
            results["block_a"]
        )
    if "block_c" in results:
        built["table_10_cfa"] = tables.table_10_cfa(results["block_c"])
    if "block_f" in results:
        built["table_12_linkage"] = tables.table_12_linkage(results["block_f"])
    if "block_g" in results:
        built["table_15_condition_agreement"] = tables.table_15_condition_agreement(
            results["block_g"]
        )
    if "block_i" in results:
        built["table_16_predictive"] = tables.table_16_predictive(results["block_i"])

    summary = tables.threshold_summary(
        {k: v for k, v in results.items() if k.startswith("block_")}
    )
    built["threshold_summary"] = summary
    written = tables.write_tables(built, out / "tables")
    drawn = figures.write_all(results, out / "figures")
    results["threshold_summary"] = summary.to_dict("records")
    json_path = tables.write_results_json(results, out / "results.json")

    print(f"Rows analysed: {results['rows_analysed']}")
    print(f"Blocks executed: {', '.join(k.replace('block_', '').upper() for k in results if k.startswith('block_'))}")
    print(f"Tables: {len(written)} file(s) under {out / 'tables'}")
    print(f"Figures: {len(drawn)} file(s) under {out / 'figures'}")
    print(f"Results: {json_path}")
    failures = _print_threshold_summary(summary)
    return 1 if (failures and args.strict) else 0


def cmd_surrogate(args: argparse.Namespace) -> int:
    """Write the surrogate analytic file."""
    written = surrogate.write(args.out, surrogate.SurrogateSpec(n=args.n, seed=args.seed))
    for name, path in written.items():
        print(f"{name}: {path}")
    return 0


def cmd_thresholds(args: argparse.Namespace) -> int:
    """Print the pre-registered thresholds."""
    frame = tables.table_2_thresholds()
    if args.json:
        print(json.dumps(frame.to_dict("records"), indent=2))
    else:
        print(frame[["key", "block", "metric", "operator", "threshold"]].to_string(index=False))
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    """Compare recomputed values against the values the manuscript reports."""
    frame = None
    if args.data:
        frame = _load_frame(args.data)
    else:
        frame = surrogate.generate(surrogate.SurrogateSpec(n=args.n, seed=args.seed))["patients"]

    reported = load_reported_values()
    checks: list[dict[str, Any]] = []

    cohort_check = intake_qa.verify_cohort_counts()
    checks.append(
        {
            "quantity": "cohort ladder is monotone",
            "recomputed": cohort_check["monotone"],
            "reported": True,
            "agrees": bool(cohort_check["monotone"]),
        }
    )
    checks.append(
        {
            "quantity": "final cohort matches Table 5",
            "recomputed": cohort_check["final_matches_table_5"],
            "reported": True,
            "agrees": bool(cohort_check["final_matches_table_5"]),
        }
    )

    linkage = block_f_linkage.run()
    published = reported["table_12_linkage_overall"]
    recomputed_se = linkage["adjudication"]["accuracy"]["sensitivity"][0]
    expected_se = published["tp"] / (published["tp"] + published["fn"])
    checks.append(
        {
            "quantity": "linkage sensitivity from the published 2x2",
            "recomputed": round(float(recomputed_se), 4),
            "reported": round(float(expected_se), 4),
            "agrees": abs(float(recomputed_se) - float(expected_se)) < 5e-4,
        }
    )

    published_alphas = [
        float(entry["alpha"]) for entry in reported["table_7_internal_consistency"]
    ]
    alpha_range = [min(published_alphas), max(published_alphas)]
    block_a = block_a_internal_consistency.run(frame)
    alphas = [float(entry["alpha"]) for entry in block_a["internal_consistency"]]
    checks.append(
        {
            "quantity": "recomputed alpha inside the reported alpha range",
            "recomputed": [round(a, 3) for a in alphas],
            "reported": [round(a, 2) for a in alpha_range],
            "agrees": all(alpha_range[0] <= a <= alpha_range[1] for a in alphas),
        }
    )

    published_fit = reported["table_10_cfa"]
    block_c = block_c_construct_validity.run(frame.head(5000))
    recomputed_fit = block_c["two_factor"]
    checks.append(
        {
            "quantity": "two-factor CFI meets the pre-registered floor",
            "recomputed": round(float(recomputed_fit["cfi"]), 3),
            "reported": float(published_fit["cfi"]),
            "agrees": float(recomputed_fit["cfi"]) >= 0.95,
        }
    )
    checks.append(
        {
            "quantity": "two-factor RMSEA meets the pre-registered ceiling",
            "recomputed": round(float(recomputed_fit["rmsea"]), 3),
            "reported": float(published_fit["rmsea"]),
            "agrees": float(recomputed_fit["rmsea"]) <= 0.06,
        }
    )
    checks.append(
        {
            "quantity": "one-factor alternative fits worse than the two-factor model",
            "recomputed": round(float(block_c["one_factor"]["cfi"]), 3),
            "reported": float(published_fit["one_factor"]["cfi"]),
            "agrees": float(block_c["one_factor"]["cfi"]) < float(recomputed_fit["cfi"]),
        }
    )
    checks.append(
        {
            "quantity": "factor correlation below the discriminant-validity ceiling",
            "recomputed": round(float(block_c["factor_correlation"]), 3),
            "reported": float(published_fit["factor_correlation"]),
            "agrees": abs(float(block_c["factor_correlation"])) < 0.85,
        }
    )

    frame_check = pd.DataFrame(checks)
    print(frame_check.to_string(index=False))
    disagreements = int((~frame_check["agrees"]).sum())
    print(
        f"\n{len(frame_check) - disagreements} of {len(frame_check)} verification checks agree "
        f"with the reported values."
    )
    if disagreements:
        print("Disagreements are listed above and are not suppressed.")
    return 1 if disagreements else 0


def cmd_info(args: argparse.Namespace) -> int:
    """Print package, threshold and configuration inventory."""
    thresholds = load_thresholds()
    print(f"kythera-validation {__version__}")
    print(f"pre-registered thresholds: {len(thresholds)}")
    print(f"blocks: {', '.join(BLOCK_ORDER)}")
    print(f"conditions: {len(cohort_build.condition_rules())}")
    print(f"intake gates: {len(intake_qa.GATES)}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Construct the argument parser."""
    parser = argparse.ArgumentParser(
        prog="kythera-validate",
        description=(
            "Run the provenance-anchored nine-block validation framework, or verify the "
            "package's recomputed values against the values reported in the manuscript."
        ),
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="execute blocks and write tables, figures and results")
    run.add_argument("--data", help="analytic file (parquet or delimited text)")
    run.add_argument("--no-surrogate", action="store_true", help="do not fall back to the surrogate file")
    run.add_argument("--blocks", nargs="+", help=f"subset of {' '.join(BLOCK_ORDER)}")
    run.add_argument("--out", default="outputs", help="output directory")
    run.add_argument("--n", type=int, default=DEFAULT_N, help="surrogate row count")
    run.add_argument("--sample", type=int, help="analyse a random sample of this many rows")
    run.add_argument("--seed", type=int, default=DEFAULT_SEED)
    run.add_argument("--imputations", type=int, default=5, help="MICE imputations for Block E")
    run.add_argument("--simulate-linkage", action="store_true", help="exercise the linkage simulation")
    run.add_argument("--n-pairs", type=int, default=500_000, help="candidate pairs to simulate")
    run.add_argument("--strict", action="store_true", help="exit non-zero if any threshold fails")
    run.set_defaults(func=cmd_run)

    gen = sub.add_parser("surrogate", help="write the surrogate analytic file")
    gen.add_argument("--out", default="data/surrogate")
    gen.add_argument("--n", type=int, default=DEFAULT_N)
    gen.add_argument("--seed", type=int, default=DEFAULT_SEED)
    gen.set_defaults(func=cmd_surrogate)

    thr = sub.add_parser("thresholds", help="print the pre-registered thresholds")
    thr.add_argument("--json", action="store_true")
    thr.set_defaults(func=cmd_thresholds)

    ver = sub.add_parser("verify", help="check recomputed values against the reported values")
    ver.add_argument("--data", help="analytic file; the surrogate file is used when omitted")
    ver.add_argument("--n", type=int, default=40_000)
    ver.add_argument("--seed", type=int, default=DEFAULT_SEED)
    ver.set_defaults(func=cmd_verify)

    info = sub.add_parser("info", help="print package inventory")
    info.set_defaults(func=cmd_info)
    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
