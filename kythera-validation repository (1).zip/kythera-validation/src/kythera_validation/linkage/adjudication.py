"""The adjudication sample: how it was drawn, blinded, and why it is reported in two parts.

Fourteen thousand two hundred and eighty-two pairs were adjudicated. They are not one
sample. Eleven thousand eight hundred and eighty-two were drawn by stratified probability
sampling from the clerical-review region and the accepted set, with the strata mirroring the
cohort composition, and these are the pairs from which sensitivity, specificity and the
false-match rate are estimated. The remaining two thousand four hundred were drawn
purposively into four deliberately adversarial scenarios - incomplete identifier sets, payer
transitions, interstate moves, and same-household duplicates - and these are reported
separately because a purposive sample supports no unbiased estimate of a population rate.
Pooling the two would understate accuracy; reporting only the first would hide the floor.

Adjudicators worked from a redacted display that removed the linkage weight, the pass that
produced the pair, and any indication of the algorithm's decision, so the reference standard
is not a function of the classifier being evaluated. Ten per cent of pairs were adjudicated
twice, by different adjudicators, to estimate the reliability of the reference standard
itself; that agreement bounds how much of the observed error can be attributed to the
linkage rather than to the adjudication.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .. import equations as eq
from ..config import check, load_reported_values

BLINDING_PROTOCOL = " ".join(
    """Each adjudicated pair was presented as two side-by-side identifier displays with the
    hashed elements rendered as agree, disagree or unavailable per element. Withheld from the
    display were the Fellegi-Sunter weight, the blocking pass that generated the pair, the
    algorithm's classification, and the contributor identity. Adjudicators recorded a
    judgement of same person, different person, or indeterminate, together with the elements
    that drove the judgement. Indeterminate judgements were resolved by a second adjudicator
    and, where still unresolved, retained as indeterminate and reported rather than forced to
    a binary; treating an indeterminate pair as a non-match would inflate specificity, and as
    a match would inflate sensitivity.""".split()
)

SAMPLING_FRAME = " ".join(
    """The probability component was drawn from the union of the accepted set and the
    clerical-review region, stratified by age group, payer type, imputed race and ethnicity,
    and calendar period, with sampling fractions set so that every stratum returned at least
    five hundred pairs and the stratum shares matched the cohort composition. Selection
    probabilities are known by construction and the reported rates are unweighted within
    stratum and weighted to cohort composition when pooled. Pairs classified as non-links
    below the lower cut-off were sampled at a lower rate into the same frame, which is what
    makes an estimate of sensitivity, and not only of positive predictive value,
    possible.""".split()
)


def two_by_two(reported: dict | None = None) -> eq.ConfusionMatrix:
    """The adjudicated 2x2 table for the probability component."""
    reported = reported or load_reported_values()["table_12_linkage_overall"]
    return eq.ConfusionMatrix(
        tp=int(reported["tp"]),
        fp=int(reported["fp"]),
        fn=int(reported["fn"]),
        tn=int(reported["tn"]),
    )


def accuracy(matrix: eq.ConfusionMatrix | None = None) -> dict:
    """Sensitivity, specificity, predictive values and the false-match rate."""
    matrix = matrix or two_by_two()
    result = eq.linkage_accuracy(matrix)
    return {
        "counts": {"tp": matrix.tp, "fp": matrix.fp, "fn": matrix.fn, "tn": matrix.tn},
        "sensitivity": [result["sensitivity"].estimate, result["sensitivity"].lower,
                        result["sensitivity"].upper],
        "specificity": [result["specificity"].estimate, result["specificity"].lower,
                        result["specificity"].upper],
        "ppv": [result["ppv"].estimate, result["ppv"].lower, result["ppv"].upper],
        "npv": [result["npv"].estimate, result["npv"].lower, result["npv"].upper],
        "false_match_rate": result["false_match_rate"].estimate,
        "false_match_rate_ci": [
            result["false_match_rate"].lower,
            result["false_match_rate"].upper,
        ],
        "threshold": check("F_false_match_rate", result["false_match_rate"].estimate),
    }


def stratified(reported: dict | None = None) -> pd.DataFrame:
    """Sensitivity and specificity by stratum, with the spread across levels.

    The stratified table is the substantive result of Block F. A single overall sensitivity
    conceals that the Medicaid and Other/Unknown strata sit several points below the
    commercial stratum, and any study weighted towards those strata inherits the lower value
    rather than the headline one.
    """
    reported = reported or load_reported_values()["table_13_linkage_strata"]
    rows = []
    for variable, levels in reported["strata"].items():
        for level in levels:
            rows.append(
                {
                    "variable": variable,
                    "level": level["level"],
                    "n": int(level["n"]),
                    "sensitivity": float(level["sensitivity"]),
                    "specificity": float(level["specificity"]),
                }
            )
    frame = pd.DataFrame(rows)
    frame["sensitivity_gap_within_variable"] = frame.groupby("variable")["sensitivity"].transform(
        lambda s: s.max() - s.min()
    )
    return frame


def difficult_scenarios(reported: list | None = None) -> pd.DataFrame:
    """The purposive component, reported separately from the probability sample."""
    reported = reported or load_reported_values()["table_14_difficult_scenarios"]
    frame = pd.DataFrame(reported)
    frame["reported_separately_because"] = (
        "Purposive, adversarial sampling; supports a floor on accuracy, not an unbiased rate."
    )
    return frame


def reference_standard_reliability(kappa: float = 0.91, n_double_adjudicated: int = 1428) -> dict:
    """Agreement between independent adjudicators on the double-adjudicated subsample.

    This is the ceiling on how well any classifier can be seen to perform: measured error
    below the disagreement of the reference standard itself cannot be distinguished from
    adjudication noise.
    """
    return {
        "kappa": kappa,
        "n_double_adjudicated": n_double_adjudicated,
        "share_double_adjudicated": round(n_double_adjudicated / 14282, 4),
        "implication": " ".join(
            """Adjudicator agreement of {k:.2f} places a ceiling on the resolution of the
            accuracy estimates: differences in sensitivity smaller than the adjudication
            disagreement cannot be attributed to the linkage rather than to the reference
            standard.""".format(k=kappa).split()
        ),
    }


def run() -> dict:
    """Assemble the whole adjudication result set."""
    reported = load_reported_values()["table_12_linkage_overall"]
    strata = stratified()
    return {
        "sampling_frame": SAMPLING_FRAME,
        "blinding_protocol": BLINDING_PROTOCOL,
        "adjudicated_total": int(reported["adjudicated_total"]),
        "probability_component": int(reported["probability_component"]),
        "purposive_component": int(reported["adjudicated_total"])
        - int(reported["probability_component"]),
        "candidate_pairs": int(reported["candidate_pairs"]),
        "accuracy": accuracy(),
        "stratified": strata.to_dict("records"),
        "widest_sensitivity_gap": {
            "variable": strata.loc[strata["sensitivity_gap_within_variable"].idxmax(), "variable"],
            "gap": float(strata["sensitivity_gap_within_variable"].max()),
        },
        "difficult_scenarios": difficult_scenarios().to_dict("records"),
        "difficult_scenario_floor": float(
            min(row["sensitivity"] for row in difficult_scenarios().to_dict("records"))
        ),
        "reference_standard_reliability": reference_standard_reliability(),
    }


def kappa_from_double_adjudication(table: np.ndarray) -> dict:
    """Cohen's kappa for the double-adjudicated subsample."""
    result = eq.cohens_kappa(np.asarray(table, dtype=float))
    return {"kappa": result.estimate, "ci": [result.lower, result.upper]}
