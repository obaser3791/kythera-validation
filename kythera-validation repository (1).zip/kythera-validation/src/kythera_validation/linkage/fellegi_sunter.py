"""Probabilistic record linkage: blocking passes and the Fellegi-Sunter weight schedule.

Tokenization does not remove the linkage problem, it relocates it. A token is a keyed hash
of identifiers, so two tokens agree only when the underlying identifier strings agree
exactly after normalisation. Every source of disagreement that classical record linkage
handles with string similarity - a hyphenated surname, a transposed birth date, a moved
household - becomes, under tokenization, an exact disagreement. The consequence is that
tokenized linkage trades the false-match risk of fuzzy comparison for a higher missed-match
risk, and that trade is a property of the design rather than a defect of the vendor.

The weight schedule below is therefore defined on token-element agreement patterns, and the
m and u probabilities are estimated from the adjudicated sample rather than assumed. The
blocking passes are listed in the order they are applied, with the reason each pass exists,
because the set of pairs a linkage never compares bounds the sensitivity it can attain.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .. import equations as eq
from ..rngs import stream
from ..config import check

# Blocking passes, applied in order. A pair compared in an earlier pass is not reconsidered.
# The union of the passes defines the comparison space; pairs outside it are non-matches by
# construction, which is the single largest contributor to missed matches.
BLOCKING_PASSES: tuple[dict[str, str], ...] = (
    {
        "pass": "1",
        "key": "token_1 (name + date of birth + sex)",
        "purpose": "Highest-specificity pass; captures pairs with a complete identifier set.",
    },
    {
        "pass": "2",
        "key": "token_2 (surname + date of birth + ZIP5)",
        "purpose": "Recovers pairs where the given name is recorded inconsistently.",
    },
    {
        "pass": "3",
        "key": "token_4 (date of birth + sex + ZIP3)",
        "purpose": (
            "Coarse geographic pass that recovers interstate moves at the cost of a much "
            "larger candidate set, which is why it is applied last and why its pairs carry "
            "the lowest prior."
        ),
    },
    {
        "pass": "4",
        "key": "token_5 (surname + given-name initial + date of birth)",
        "purpose": (
            "Recovers pairs where the ZIP code changed and the given name was truncated or "
            "abbreviated by the contributor."
        ),
    },
)

# Token elements compared within a candidate pair, with the m and u probabilities estimated
# from the adjudicated sample. m is the probability an element agrees given a true match;
# u is the probability it agrees given a non-match.
# "available" is the proportion of pairs in which the element is present on both sides and
# can therefore be compared at all. An element that is absent contributes no weight, which is
# why identifier completeness, and not only identifier accuracy, governs achievable
# sensitivity: a pair with only three comparable elements can reach a far lower weight than
# an otherwise identical pair with six.
TOKEN_ELEMENTS: tuple[dict[str, object], ...] = (
    {"element": "surname_hash", "m": 0.972, "u": 0.0031, "available": 0.991},
    {"element": "given_name_hash", "m": 0.948, "u": 0.0104, "available": 0.973},
    {"element": "date_of_birth_hash", "m": 0.981, "u": 0.0007, "available": 0.996},
    {"element": "sex", "m": 0.996, "u": 0.5010, "available": 0.998},
    {"element": "zip5_hash", "m": 0.842, "u": 0.0009, "available": 0.857},
    {"element": "ssn_last4_hash", "m": 0.713, "u": 0.0001, "available": 0.412},
)


@dataclass(frozen=True)
class WeightSchedule:
    """Agreement weights for each token element, plus the decision thresholds.

    ``upper`` is the weight above which a pair is accepted as a link, ``lower`` the weight
    below which it is rejected; pairs between the two are the clerical-review region and are
    sent to adjudication. Both are derived rather than chosen by eye - see
    :func:`derive_thresholds`.
    """

    elements: tuple[dict[str, object], ...] = TOKEN_ELEMENTS
    # The operating point is the one returned by :func:`derive_thresholds` on the adjudicated
    # weight distributions at a false-match ceiling of 0.005 and a sensitivity target of 0.95.
    # It is recorded to two decimal places rather than rounded to a whole number because the
    # false-match rate is a steep function of the cut-off in this region: moving the upper
    # cut-off down by four tenths of a bit takes the false-match rate from 0.003 to 0.035.
    upper: float = 16.40
    lower: float = 13.62
    prior_match_odds: float = field(default=1 / 1000.0)

    def agreement_weight(self, element: str) -> float:
        """log2(m/u) contribution when the element agrees."""
        spec = self._spec(element)
        return float(np.log2(spec["m"] / spec["u"]))

    def disagreement_weight(self, element: str) -> float:
        """log2((1-m)/(1-u)) contribution when the element disagrees."""
        spec = self._spec(element)
        return float(np.log2((1 - spec["m"]) / (1 - spec["u"])))

    def _spec(self, element: str) -> dict[str, object]:
        for spec in self.elements:
            if spec["element"] == element:
                return spec
        raise KeyError(element)

    def table(self) -> pd.DataFrame:
        """The full weight schedule as reported in the methodological appendix."""
        return pd.DataFrame(
            [
                {
                    "element": spec["element"],
                    "m": spec["m"],
                    "u": spec["u"],
                    "agreement_weight": self.agreement_weight(str(spec["element"])),
                    "disagreement_weight": self.disagreement_weight(str(spec["element"])),
                }
                for spec in self.elements
            ]
        )

    def score(self, agreements: dict[str, bool]) -> float:
        """Total weight for one candidate pair's agreement pattern."""
        total = float(np.log2(self.prior_match_odds))
        for spec in self.elements:
            name = str(spec["element"])
            if name not in agreements:
                continue
            total += (
                self.agreement_weight(name) if agreements[name] else self.disagreement_weight(name)
            )
        return total

    def classify(self, weight: float) -> str:
        """Link, non-link, or clerical review."""
        if weight >= self.upper:
            return "link"
        if weight <= self.lower:
            return "non_link"
        return "clerical_review"


def derive_thresholds(
    match_weights: np.ndarray,
    nonmatch_weights: np.ndarray,
    *,
    target_false_match_rate: float = 0.005,
    target_sensitivity: float = 0.95,
) -> tuple[float, float]:
    """Derive the upper and lower cut-offs from the adjudicated weight distributions.

    Two error rates are fixed and the weights are solved for, rather than the weights being
    fixed at round numbers and whatever error rates follow being reported.

    The upper cut-off is the smallest weight at which the false-match rate among accepted
    pairs is at or below the pre-registered ceiling. The lower cut-off is the largest weight
    that can be used to reject outright while still losing no more than ``1 -
    target_sensitivity`` of the true matches; pairs between the two go to clerical review.

    When the separation between the two weight distributions is strong enough that the
    false-match constraint is already satisfied below the sensitivity constraint, the two
    cut-offs collapse onto the sensitivity-based value: there is no region in which review
    would change a decision, and the function reports that rather than emitting an inverted
    pair of thresholds.
    """
    match_weights = np.asarray(match_weights, dtype=float)
    nonmatch_weights = np.asarray(nonmatch_weights, dtype=float)
    if match_weights.size == 0 or nonmatch_weights.size == 0:
        raise ValueError("both adjudicated weight distributions must be non-empty")
    grid = np.unique(np.concatenate([match_weights, nonmatch_weights]))

    upper = float(grid.max())
    for candidate in grid:
        accepted_true = float((match_weights >= candidate).sum())
        accepted_false = float((nonmatch_weights >= candidate).sum())
        if accepted_true + accepted_false == 0:
            continue
        if accepted_false / (accepted_true + accepted_false) <= target_false_match_rate:
            upper = float(candidate)
            break

    lower = float(grid.min())
    for candidate in grid[::-1]:
        if float((match_weights < candidate).mean()) <= 1.0 - target_sensitivity:
            lower = float(candidate)
            break

    if lower > upper:
        upper = lower
    return upper, lower


def match_rate(linked: int, eligible: int) -> dict:
    """Overall match rate with its Wilson interval, against the pre-registered floor."""
    interval = eq.match_rate(linked, eligible)
    return {
        "linked": linked,
        "eligible": eligible,
        "rate": interval.estimate,
        "ci": [interval.lower, interval.upper],
        "threshold": check("F_match_rate", interval.estimate),
    }


# Elements forced to agree by the blocking key of each pass. Within a pass, a non-matched
# pair already agrees on the key, so the u probability for those elements is one by
# construction and only the remaining elements carry discriminating information. This is the
# mechanism that produces the overlap between the two weight distributions, and therefore the
# clerical-review region; a simulation that draws every element independently of the pass
# would show a separation that no real linkage achieves.
PASS_KEY_ELEMENTS: dict[str, tuple[str, ...]] = {
    "1": ("surname_hash", "given_name_hash", "date_of_birth_hash", "sex"),
    "2": ("surname_hash", "date_of_birth_hash", "zip5_hash"),
    "3": ("date_of_birth_hash", "sex"),
    "4": ("surname_hash", "date_of_birth_hash"),
}
PASS_SHARES: dict[str, float] = {"1": 0.62, "2": 0.18, "3": 0.13, "4": 0.07}


def simulate_candidate_pairs(
    n_pairs: int = 5_000_000,
    *,
    prevalence: float = 0.64,
    seed: int = 20250731,
    schedule: WeightSchedule | None = None,
) -> pd.DataFrame:
    """Generate candidate pairs with agreement patterns and their Fellegi-Sunter weights.

    The prevalence of true matches among candidate pairs, the m and u probabilities, the
    element availability rates and the distribution of pairs across blocking passes are the
    values estimated from the adjudicated sample, so the simulated weight distributions have
    the same shape as the ones the licensed pipeline produces and the threshold derivation can
    be exercised end to end without the licensed data.
    """
    schedule = schedule or WeightSchedule()
    rng = stream(seed, "linkage_candidate_pairs")
    is_match = rng.random(n_pairs) < prevalence
    passes = rng.choice(
        list(PASS_SHARES), size=n_pairs, p=np.array(list(PASS_SHARES.values()))
    )
    frame = pd.DataFrame({"is_match": is_match, "blocking_pass": passes})

    weights = np.full(n_pairs, float(np.log2(schedule.prior_match_odds)))
    comparable = np.zeros(n_pairs, dtype=int)
    for spec in schedule.elements:
        name = str(spec["element"])
        forced = np.array([name in PASS_KEY_ELEMENTS[p] for p in passes])
        available = forced | (rng.random(n_pairs) < float(spec.get("available", 1.0)))
        probability = np.where(is_match, float(spec["m"]), float(spec["u"]))
        agrees = available & (forced | (rng.random(n_pairs) < probability))
        frame[name] = np.where(available, agrees, np.nan)
        contribution = np.where(
            agrees, schedule.agreement_weight(name), schedule.disagreement_weight(name)
        )
        weights += np.where(available, contribution, 0.0)
        comparable += available.astype(int)

    frame["comparable_elements"] = comparable
    frame["weight"] = weights
    frame["decision"] = [schedule.classify(w) for w in weights]
    return frame


def operating_characteristics(frame: pd.DataFrame, schedule: WeightSchedule) -> dict:
    """Sensitivity, false-match rate and review volume at a given operating point."""
    accepted = frame["weight"] >= schedule.upper
    review = (frame["weight"] > schedule.lower) & (frame["weight"] < schedule.upper)
    matches = frame["is_match"].to_numpy(dtype=bool)
    return {
        "upper": schedule.upper,
        "lower": schedule.lower,
        "sensitivity": float(accepted[matches].mean()),
        "false_match_rate": float(1.0 - matches[accepted].mean()) if accepted.any() else 0.0,
        "clerical_review_share": float(review.mean()),
        "true_matches_in_review": int(matches[review].sum()),
    }


def threshold_curve(
    frame: pd.DataFrame,
    *,
    lower: float | None = None,
    n_points: int = 60,
) -> pd.DataFrame:
    """Sensitivity, false-match rate and clerical-review share across upper thresholds.

    The operating point is a decision, not a property of the data, and the cost of moving it
    is not symmetric: over the range examined here the false-match rate changes by an order of
    magnitude while sensitivity changes by a few points. Publishing the curve is what allows a
    reader to judge whether the chosen point was reasonable for their own purpose, which may
    weigh a missed match differently from a false one.
    """
    schedule = WeightSchedule()
    lower = float(schedule.lower if lower is None else lower)
    weights = frame["weight"].to_numpy(dtype=float)
    is_match = frame["is_match"].to_numpy(dtype=bool)
    n_match = int(is_match.sum())
    grid = np.linspace(lower, float(np.quantile(weights, 0.999)), n_points)
    rows = []
    for upper in grid:
        declared = weights >= upper
        review = (weights >= lower) & (weights < upper)
        true_positive = int((declared & is_match).sum())
        false_positive = int((declared & ~is_match).sum())
        rows.append(
            {
                "upper": float(upper),
                "lower": lower,
                "sensitivity": true_positive / n_match if n_match else float("nan"),
                "false_match_rate": (
                    false_positive / (true_positive + false_positive)
                    if (true_positive + false_positive)
                    else 0.0
                ),
                "clerical_review_share": float(review.mean()),
                "declared_share": float(declared.mean()),
            }
        )
    return pd.DataFrame(rows)
