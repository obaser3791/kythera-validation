"""Tests for the estimators in ``equations.py``.

Each test compares an implementation against a value that is known independently of the
implementation: a closed-form result, a published worked example, or an analytic property the
estimator must satisfy. A test that merely records what the code currently returns would pass
after the code broke, which is worse than no test.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy import stats

from kythera_validation import equations as eq


class TestCronbachAlpha:
    def test_matches_closed_form_for_a_two_item_scale(self) -> None:
        # For two items, alpha equals 2r/(1+r) where r is the inter-item correlation.
        rng = np.random.default_rng(1)
        x = rng.normal(size=4000)
        y = 0.6 * x + rng.normal(size=4000) * np.sqrt(1 - 0.36)
        items = np.column_stack([x, y])
        r = float(np.corrcoef(x, y)[0, 1])
        expected = 2 * r / (1 + r)
        assert eq.cronbach_alpha(items).estimate == pytest.approx(expected, abs=1e-3)

    def test_alpha_rises_with_the_number_of_parallel_items(self) -> None:
        rng = np.random.default_rng(2)
        latent = rng.normal(size=3000)

        def scale(k: int) -> float:
            items = np.column_stack(
                [0.5 * latent + rng.normal(size=3000) * np.sqrt(0.75) for _ in range(k)]
            )
            return float(eq.cronbach_alpha(items).estimate)

        assert scale(4) < scale(12) < scale(30)

    def test_independent_items_give_alpha_near_zero(self) -> None:
        rng = np.random.default_rng(3)
        items = rng.normal(size=(5000, 8))
        assert abs(eq.cronbach_alpha(items).estimate) < 0.06


class TestIntraclassCorrelation:
    def test_identical_ratings_give_unity(self) -> None:
        rng = np.random.default_rng(4)
        column = rng.normal(size=500)
        ratings = np.column_stack([column, column])
        assert eq.icc_two_way_random(ratings).estimate == pytest.approx(1.0, abs=1e-9)

    def test_unrelated_ratings_give_near_zero(self) -> None:
        rng = np.random.default_rng(5)
        ratings = rng.normal(size=(2000, 2))
        assert abs(eq.icc_two_way_random(ratings).estimate) < 0.06


class TestCohensKappa:
    def test_reproduces_a_worked_example(self) -> None:
        # Observed agreement is 0.90 and chance agreement is 0.45*0.45 + 0.55*0.55 = 0.505,
        # so kappa = (0.90 - 0.505) / (1 - 0.505) = 0.79798.
        table = np.array([[40.0, 5.0], [5.0, 50.0]])
        result = eq.cohens_kappa(table)
        assert result.estimate == pytest.approx(0.79798, abs=1e-4)
        assert result.lower < result.estimate < result.upper

    def test_chance_agreement_gives_zero(self) -> None:
        table = np.outer([0.3, 0.7], [0.3, 0.7]) * 1000
        assert abs(eq.cohens_kappa(table).estimate) < 1e-9

    def test_prevalence_depresses_kappa_at_fixed_agreement(self) -> None:
        # Two tables with the same observed agreement but different marginals: the rarer
        # condition yields the lower kappa. This is the base-rate problem the manuscript
        # discusses, and it is why kappa is reported next to positive specific agreement.
        balanced = np.array([[45.0, 5.0], [5.0, 45.0]])
        skewed = np.array([[5.0, 5.0], [5.0, 85.0]])
        assert eq.cohens_kappa(skewed).estimate < eq.cohens_kappa(balanced).estimate


class TestLinsConcordance:
    def test_identity_gives_unity(self) -> None:
        rng = np.random.default_rng(6)
        x = rng.normal(size=500)
        result = eq.lins_ccc(x, x)
        assert result.estimate == pytest.approx(1.0, abs=1e-12)
        # Lin's variance is undefined at exact agreement; the interval collapses rather
        # than returning a missing value.
        assert result.lower == pytest.approx(1.0, abs=1e-12)
        assert result.upper == pytest.approx(1.0, abs=1e-12)

    def test_location_shift_reduces_concordance_without_touching_correlation(self) -> None:
        rng = np.random.default_rng(7)
        x = rng.normal(size=2000)
        shifted = x + 1.0
        assert float(np.corrcoef(x, shifted)[0, 1]) == pytest.approx(1.0, abs=1e-12)
        assert eq.lins_ccc(x, shifted).estimate < 0.9


class TestStandardizedMeanDifference:
    def test_zero_for_identical_distributions(self) -> None:
        rng = np.random.default_rng(8)
        x = rng.normal(size=1000)
        assert eq.standardized_mean_difference(x, x) == pytest.approx(0.0, abs=1e-12)

    def test_matches_hand_calculation(self) -> None:
        # The function returns the magnitude of the difference, which is the quantity the
        # 0.10 balance criterion is stated on; direction is carried by the stratum labels.
        x = np.array([1.0, 2.0, 3.0, 4.0])
        y = np.array([2.0, 3.0, 4.0, 5.0])
        pooled = np.sqrt((x.var(ddof=1) + y.var(ddof=1)) / 2)
        assert eq.standardized_mean_difference(x, y) == pytest.approx(1.0 / pooled, abs=1e-12)
        assert eq.standardized_mean_difference(y, x) == pytest.approx(
            eq.standardized_mean_difference(x, y), abs=1e-12
        )

    def test_binary_form_uses_the_bernoulli_variance(self) -> None:
        value = eq.standardized_mean_difference(
            np.array([1.0] * 30 + [0.0] * 70), np.array([1.0] * 40 + [0.0] * 60), binary=True
        )
        pooled = np.sqrt((0.3 * 0.7 + 0.4 * 0.6) / 2)
        assert value == pytest.approx(0.1 / pooled, abs=1e-9)


class TestRakingWeights:
    def test_reproduces_target_margins_when_untrimmed(self) -> None:
        rng = np.random.default_rng(9)
        codes = rng.integers(0, 3, 5000)
        design = np.column_stack([codes, rng.integers(0, 2, 5000)])
        targets = [np.array([0.5, 0.3, 0.2]), np.array([0.45, 0.55])]
        weights = eq.raking_weights(design, targets, trim=None)
        for column, target in zip(design.T, targets):
            for level, share in enumerate(target):
                achieved = weights[column == level].sum() / weights.sum()
                assert achieved == pytest.approx(float(share), abs=1e-3)

    def test_weights_are_positive_and_average_to_one(self) -> None:
        rng = np.random.default_rng(10)
        design = np.column_stack([rng.integers(0, 4, 2000)])
        weights = eq.raking_weights(design, [np.array([0.1, 0.2, 0.3, 0.4])], trim=None)
        assert (weights > 0).all()
        assert weights.mean() == pytest.approx(1.0, abs=1e-6)


class TestRubinPooling:
    def test_identical_estimates_leave_no_between_variance(self) -> None:
        pooled = eq.rubin_pool([2.0, 2.0, 2.0], [0.25, 0.25, 0.25])
        assert pooled["between_variance"] == pytest.approx(0.0, abs=1e-12)
        assert pooled["fmi"] == pytest.approx(0.0, abs=1e-12)
        assert pooled["total_variance"] == pytest.approx(0.25, abs=1e-12)

    def test_between_variance_raises_the_fraction_of_missing_information(self) -> None:
        tight = eq.rubin_pool([2.00, 2.01, 1.99], [0.25] * 3)
        loose = eq.rubin_pool([1.0, 2.0, 3.0], [0.25] * 3)
        assert loose["fmi"] > tight["fmi"]
        assert loose["ci_upper"] - loose["ci_lower"] > tight["ci_upper"] - tight["ci_lower"]


class TestLittlesMcarTest:
    def test_complete_data_has_a_single_pattern(self) -> None:
        rng = np.random.default_rng(11)
        data = rng.normal(size=(500, 4))
        result = eq.littles_mcar_test(data)
        assert result["n_patterns"] == 1
        assert result["chisq"] == pytest.approx(0.0, abs=1e-12)
        assert result["p_value"] == pytest.approx(1.0, abs=1e-12)

    def test_data_missing_completely_at_random_is_not_rejected(self) -> None:
        rng = np.random.default_rng(12)
        data = rng.normal(size=(4000, 5))
        data[rng.random(data.shape) < 0.10] = np.nan
        assert eq.littles_mcar_test(data)["p_value"] > 0.01

    def test_missingness_driven_by_the_values_is_rejected(self) -> None:
        rng = np.random.default_rng(13)
        data = rng.normal(size=(4000, 4))
        data[data[:, 0] > 0.5, 1] = np.nan
        assert eq.littles_mcar_test(data)["p_value"] < 0.01


class TestMannKendall:
    def test_monotone_increase_is_detected(self) -> None:
        result = eq.mann_kendall(np.arange(20, dtype=float))
        assert result["tau"] == pytest.approx(1.0, abs=1e-12)
        assert result["p_value"] < 0.001

    def test_flat_series_has_no_trend(self) -> None:
        result = eq.mann_kendall(np.array([3.0, 1.0, 3.0, 1.0, 3.0, 1.0, 3.0, 1.0]))
        assert abs(result["tau"]) < 0.2
        assert result["p_value"] > 0.2

    def test_sign_reverses_with_the_series(self) -> None:
        up = eq.mann_kendall(np.arange(15, dtype=float))
        down = eq.mann_kendall(np.arange(15, 0, -1, dtype=float))
        assert up["tau"] == pytest.approx(-down["tau"], abs=1e-12)


class TestCusum:
    def test_stable_series_raises_no_break(self) -> None:
        rng = np.random.default_rng(14)
        assert eq.cusum(rng.normal(size=60))["n_breaks"] == 0

    def test_level_shift_is_flagged(self) -> None:
        rng = np.random.default_rng(15)
        series = np.concatenate([rng.normal(0, 1, 40), rng.normal(4, 1, 40)])
        assert eq.cusum(series)["n_breaks"] > 0


class TestAuroc:
    def test_perfect_separation_gives_one(self) -> None:
        y = np.array([0] * 50 + [1] * 50)
        p = np.concatenate([np.linspace(0.0, 0.4, 50), np.linspace(0.6, 1.0, 50)])
        assert eq.auroc(y, p).estimate == pytest.approx(1.0, abs=1e-12)

    def test_random_scores_give_one_half(self) -> None:
        rng = np.random.default_rng(16)
        y = rng.integers(0, 2, 4000)
        assert eq.auroc(y, rng.random(4000)).estimate == pytest.approx(0.5, abs=0.03)

    def test_equals_the_mann_whitney_statistic(self) -> None:
        rng = np.random.default_rng(17)
        y = rng.integers(0, 2, 600)
        p = rng.random(600) + 0.3 * y
        u = stats.mannwhitneyu(p[y == 1], p[y == 0], alternative="two-sided").statistic
        expected = u / (int((y == 1).sum()) * int((y == 0).sum()))
        assert eq.auroc(y, p).estimate == pytest.approx(expected, abs=1e-9)

    def test_interval_contains_the_estimate(self) -> None:
        rng = np.random.default_rng(18)
        y = rng.integers(0, 2, 1500)
        p = rng.random(1500) + 0.4 * y
        result = eq.auroc(y, p)
        assert result.lower < result.estimate < result.upper


class TestBrierAndCalibration:
    def test_perfect_prediction_scores_zero(self) -> None:
        y = np.array([0, 1, 0, 1, 1, 0])
        assert eq.brier_and_calibration(y, y.astype(float))["brier"] == pytest.approx(0.0)

    def test_calibrated_probabilities_give_unit_slope(self) -> None:
        rng = np.random.default_rng(19)
        p = rng.random(20000)
        y = rng.binomial(1, p)
        result = eq.brier_and_calibration(y, p)
        assert result["calibration_slope"] == pytest.approx(1.0, abs=0.06)
        assert abs(result["calibration_intercept"]) < 0.06

    def test_inflated_probabilities_are_detected_despite_perfect_discrimination(self) -> None:
        # A monotone transformation cannot change the c-statistic but does change calibration,
        # which is the reason both are reported.
        rng = np.random.default_rng(20)
        p = rng.random(8000) * 0.4
        y = rng.binomial(1, p)
        inflated = np.clip(p * 2.0, 0, 1)
        assert eq.auroc(y, inflated).estimate == pytest.approx(eq.auroc(y, p).estimate, abs=1e-9)
        assert eq.brier_and_calibration(y, inflated)["brier"] > eq.brier_and_calibration(y, p)["brier"]


class TestSemFitIndices:
    def test_a_saturated_model_fits_perfectly(self) -> None:
        rng = np.random.default_rng(21)
        data = rng.normal(size=(2000, 4))
        sample = np.corrcoef(data, rowvar=False)
        fit = eq.sem_fit_indices(sample, sample, n=2000, n_params=2, structure="correlation")
        assert fit.cfi == pytest.approx(1.0, abs=1e-6)
        assert fit.rmsea == pytest.approx(0.0, abs=1e-6)
        assert fit.srmr == pytest.approx(0.0, abs=1e-9)
        assert fit.df == 4

    def test_misspecification_degrades_every_index(self) -> None:
        rng = np.random.default_rng(22)
        loading = np.array([0.8, 0.7, 0.75, 0.72])
        true_corr = np.outer(loading, loading)
        np.fill_diagonal(true_corr, 1.0)
        data = rng.multivariate_normal(np.zeros(4), true_corr, size=3000)
        sample = np.corrcoef(data, rowvar=False)
        wrong = np.eye(4)
        good = eq.sem_fit_indices(sample, sample, n=3000, n_params=2, structure="correlation")
        bad = eq.sem_fit_indices(sample, wrong, n=3000, n_params=2, structure="correlation")
        assert bad.cfi < good.cfi
        assert bad.rmsea > good.rmsea
        assert bad.srmr > good.srmr
