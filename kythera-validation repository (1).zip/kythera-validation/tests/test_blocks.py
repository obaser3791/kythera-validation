"""Smoke tests for the nine blocks.

These run each block against a small surrogate cohort. They do not assert the published point
estimates - the surrogate is not the licensed asset and must not be mistaken for it. What they
assert is that each block returns the structure the reporting layer and the manuscript tables
depend on, that every pre-registered check it emits is well formed, and that the qualitative
relations the manuscript relies on hold.
"""

from __future__ import annotations

import pandas as pd
import pytest

from kythera_validation.blocks import (
    block_a_internal_consistency,
    block_b_external_consistency,
    block_c_construct_validity,
    block_d_representativeness,
    block_e_missingness,
    block_f_linkage,
    block_g_intercoder,
    block_h_temporal,
    block_i_predictive,
)
from kythera_validation.cohort import build as cohort_build
from kythera_validation.provenance import intake_qa
from kythera_validation.surrogate.generate import SurrogateSpec, generate

SEED = 20250731
N = 6000


@pytest.fixture(scope="module")
def surrogate() -> pd.DataFrame:
    return generate(SurrogateSpec(n=N, seed=SEED))["patients"]


def _threshold_checks(node: object) -> list[dict]:
    """Collect every pre-registered check embedded anywhere in a block result."""
    found: list[dict] = []
    if isinstance(node, dict):
        if {"key", "observed", "operator", "threshold", "passes"} <= set(node):
            found.append(node)
        else:
            for value in node.values():
                found.extend(_threshold_checks(value))
    elif isinstance(node, list):
        for value in node:
            found.extend(_threshold_checks(value))
    return found


def _assert_checks_are_well_formed(result: object) -> list[dict]:
    checks = _threshold_checks(result)
    for check in checks:
        assert check["operator"] in {">=", "<=", "==", "<", ">"}, check["key"]
        assert isinstance(check["passes"], bool), check["key"]
        assert check["observed"] == check["observed"], check["key"]  # not NaN
    return checks


class TestBlockA:
    def test_returns_internal_consistency_for_each_construct(self, surrogate) -> None:
        result = block_a_internal_consistency.run(surrogate)
        scales = result["internal_consistency"]
        assert len(scales) >= 2
        for scale in scales:
            assert scale["construct"]
            assert scale["items"] >= 3
            assert 0.0 < scale["alpha"] <= 1.0
            lower, upper = scale["alpha_ci"]
            assert lower <= scale["alpha"] <= upper

    def test_reports_test_retest_and_known_group_evidence(self, surrogate) -> None:
        result = block_a_internal_consistency.run(surrogate)
        assert 0.0 < result["test_retest"]["icc"] <= 1.0
        assert result["known_group"]
        assert "all_thresholds_met" in result

    def test_every_check_is_well_formed(self, surrogate) -> None:
        assert _assert_checks_are_well_formed(block_a_internal_consistency.run(surrogate))


class TestBlockB:
    def test_reports_agreement_against_the_survey_benchmarks(self, surrogate) -> None:
        result = block_b_external_consistency.run(surrogate)
        checks = _assert_checks_are_well_formed(result)
        assert {c["key"] for c in checks} >= {"B_mape", "B_lins_ccc"}


class TestBlockC:
    def test_the_two_factor_model_fits_better_than_one_factor(self, surrogate) -> None:
        result = block_c_construct_validity.run(surrogate)
        assert result["two_factor"]["cfi"] > result["one_factor"]["cfi"]
        assert result["two_factor"]["rmsea"] < result["one_factor"]["rmsea"]

    def test_the_factors_are_distinguishable(self, surrogate) -> None:
        result = block_c_construct_validity.run(surrogate)
        assert abs(result["factor_correlation"]) < 0.85
        assert result["fornell_larcker_satisfied"] in {True, False}

    def test_every_loading_and_reliability_statistic_is_admissible(self, surrogate) -> None:
        result = block_c_construct_validity.run(surrogate)
        for name, value in result["loadings"].items():
            assert 0.0 < abs(float(value)) < 1.0, name
        for factor, value in result["average_variance_extracted"].items():
            assert 0.0 < float(value) <= 1.0, factor
        for factor, value in result["composite_reliability_omega"].items():
            assert 0.0 < float(value) <= 1.0, factor


class TestBlockD:
    def test_raking_reduces_the_largest_imbalance(self, surrogate) -> None:
        result = block_d_representativeness.run(surrogate)
        before = max(row["abs_smd"] for row in result["unweighted"])
        after = max(row["abs_smd"] for row in result["weighted"])
        assert after < before

    def test_target_margins_are_stated_for_every_comparison(self, surrogate) -> None:
        for row in block_d_representativeness.run(surrogate)["unweighted"]:
            assert row["variable"] and row["level"]
            assert 0.0 <= row["target_pct"] <= 100.0
            assert 0.0 <= row["cohort_pct"] <= 100.0


class TestBlockE:
    def test_pooling_reports_a_fraction_of_missing_information(self, surrogate) -> None:
        result = block_e_missingness.run(surrogate, m=2)
        checks = _assert_checks_are_well_formed(result)
        assert any(c["key"] == "E_pooled_fmi" for c in checks)

    def test_the_mcar_test_returns_a_valid_probability(self, surrogate) -> None:
        result = block_e_missingness.run(surrogate, m=2)
        p = float(result["littles_test"]["p_value"])
        assert 0.0 <= p <= 1.0
        assert result["imputations_run"] == 2
        # The block must state what the missingness mechanism means for interpretation,
        # not only whether a test was rejected.
        assert result["origin_meaning"]


class TestBlockF:
    def test_reports_the_published_operating_characteristics(self) -> None:
        result = block_f_linkage.run(simulate=False)
        assert result["match_rate"]["rate"] > 0.9
        accuracy = result["adjudication"]["accuracy"]
        assert accuracy["sensitivity"][0] == pytest.approx(0.967, abs=0.002)
        assert accuracy["false_match_rate"] < 0.005

    def test_names_the_weakest_stratum_rather_than_only_the_average(self) -> None:
        # A single overall sensitivity can hide a stratum in which linkage performs poorly,
        # so the block is required to surface the minimum.
        result = block_f_linkage.run(simulate=False)
        assert result["lowest_sensitivity_stratum"]


class TestBlockG:
    def test_every_adjudicated_category_reports_agreement(self) -> None:
        result = block_g_intercoder.run()
        assert len(result["categories"]) >= 6
        for row in result["categories"]:
            assert 0.0 < row["kappa"] <= 1.0, row["condition"]
            assert row["agreement_strength"], row["condition"]

    def test_categories_below_the_threshold_are_named_not_hidden(self) -> None:
        result = block_g_intercoder.run()
        below = {row["condition"] for row in result["categories"] if not row["meets_threshold"]}
        assert set(result["categories_below_threshold"]) == below


class TestBlockH:
    def test_reports_both_the_observed_trend_and_the_detectable_effect(self) -> None:
        # A null trend is uninterpretable without the size of the effect the design could
        # have detected, so the block reports the minimum detectable value alongside it.
        result = block_h_temporal.run()
        assert "minimum_detectable" in str(result).lower() or "minimum_detectable_tau" in result
        checks = _assert_checks_are_well_formed(result)
        assert any(c["key"] == "H_abs_tau" for c in checks)


class TestBlockI:
    def test_reports_discrimination_and_calibration_for_every_outcome(self, surrogate) -> None:
        result = block_i_predictive.run(surrogate)
        for outcome, payload in result["recomputed"].items():
            split = payload["random_split"]
            assert 0.5 < split["auroc"] < 1.0, outcome
            assert 0.0 < split["brier"] < 0.25, outcome
            assert split["calibration_slope"] > 0.0, outcome

    def test_validation_schemes_are_all_present(self, surrogate) -> None:
        for outcome, payload in block_i_predictive.run(surrogate)["recomputed"].items():
            assert {"random_split", "temporal_holdout", "leave_one_region_out"} <= set(payload), (
                outcome
            )

    def test_leakage_controls_are_documented(self, surrogate) -> None:
        assert block_i_predictive.run(surrogate)["leakage_controls"]

    def test_discrimination_is_not_presented_as_validity(self, surrogate) -> None:
        assert block_i_predictive.run(surrogate)["discrimination_is_not_calibration"]


class TestCohortAndProvenance:
    def test_the_cohort_ladder_only_ever_loses_patients(self) -> None:
        ladder = cohort_build.attrition_ladder()
        counts = [step.n for step in ladder]
        assert counts == sorted(counts, reverse=True)
        # Every exclusion states the criterion that produced it.
        assert all(step.label and step.criterion for step in ladder)

    def test_the_final_step_is_the_analytic_cohort(self) -> None:
        assert cohort_build.attrition_ladder()[-1].n == 38947221

    def test_every_intake_gate_is_evaluated_against_its_bound(self) -> None:
        result = intake_qa.run()
        assert result["gates"]
        graded = 0
        for gate in result["gates"]:
            assert gate["gate"] and gate["stage"] and gate["description"]
            if gate["passes"] is None:
                # Some intake measures are reported for transparency and carry no bound;
                # they are described rather than graded, and must not be silently counted
                # as passing.
                continue
            graded += 1
            assert gate["operator"] in {">=", "<=", "==", "<", ">"}, gate["gate"]
            assert gate["passes"] in {True, False}, gate["gate"]
        assert graded >= 8
        assert result["gates_evaluated"] == graded
        # Failing gates are listed by name, so an empty list is the same statement as a
        # count of zero.
        failing = [g["gate"] for g in result["gates"] if g["passes"] is False]
        assert list(result["gates_failing"]) == failing
        # The conditional nature of every downstream result is stated, not implied.
        assert result["conditionality"]
