"""Tests for the probabilistic linkage machinery.

The published operating point is a claim about a trade-off, so these tests check the shape of
that trade-off - monotonicity, direction, and where the two thresholds sit - rather than only
the point estimates.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from kythera_validation import equations as eq
from kythera_validation.linkage import fellegi_sunter as fs


class TestAgreementWeights:
    def test_agreement_on_a_rare_field_earns_more_than_agreement_on_a_common_one(self) -> None:
        rare = eq.fellegi_sunter_weight(np.array([1.0]), np.array([0.95]), np.array([0.001]))
        common = eq.fellegi_sunter_weight(np.array([1.0]), np.array([0.95]), np.array([0.20]))
        assert float(rare) > float(common)

    def test_disagreement_carries_a_negative_weight(self) -> None:
        weight = eq.fellegi_sunter_weight(np.array([0.0]), np.array([0.95]), np.array([0.01]))
        assert float(weight) < 0

    def test_the_total_weight_is_the_sum_of_the_element_weights(self) -> None:
        m = np.array([0.90, 0.95, 0.80])
        u = np.array([0.01, 0.05, 0.20])
        pattern = np.array([1.0, 0.0, 1.0])
        parts = sum(
            float(eq.fellegi_sunter_weight(pattern[[i]], m[[i]], u[[i]])) for i in range(3)
        )
        assert float(eq.fellegi_sunter_weight(pattern, m, u)) == pytest.approx(parts, abs=1e-12)

    def test_sex_agreement_is_nearly_uninformative(self) -> None:
        # With u close to one half, agreement on sex adds about one bit, which is why the
        # schedule cannot rely on it. This is a property of the weight, not of the data.
        schedule = fs.WeightSchedule()
        sex = next(e for e in schedule.elements if e["element"] == "sex")
        surname = next(e for e in schedule.elements if e["element"] == "surname_hash")
        sex_weight = float(
            eq.fellegi_sunter_weight(np.array([1.0]), np.array([sex["m"]]), np.array([sex["u"]]))
        )
        surname_weight = float(
            eq.fellegi_sunter_weight(
                np.array([1.0]), np.array([surname["m"]]), np.array([surname["u"]])
            )
        )
        assert sex_weight < 1.5
        assert surname_weight > 5 * sex_weight


class TestWeightSchedule:
    def test_the_published_operating_point_is_carried_in_the_schedule(self) -> None:
        schedule = fs.WeightSchedule()
        assert schedule.upper == pytest.approx(16.40, abs=0.01)
        assert schedule.lower == pytest.approx(13.62, abs=0.01)
        assert schedule.upper > schedule.lower

    def test_every_element_has_admissible_probabilities(self) -> None:
        for element in fs.WeightSchedule().elements:
            assert 0.0 < element["m"] <= 1.0, element["element"]
            assert 0.0 < element["u"] <= 1.0, element["element"]
            assert 0.0 < element["available"] <= 1.0, element["element"]
            # An element is only informative if agreement is more likely among matches
            # than among non-matches.
            assert element["m"] > element["u"], element["element"]


class TestSimulatedPairs:
    @staticmethod
    def _pairs(n: int = 40000) -> pd.DataFrame:
        return fs.simulate_candidate_pairs(n, seed=11)

    def test_true_matches_score_above_non_matches_on_average(self) -> None:
        pairs = self._pairs()
        assert (
            pairs.loc[pairs["is_match"], "weight"].mean()
            > pairs.loc[~pairs["is_match"], "weight"].mean()
        )

    def test_missing_tokens_reduce_the_number_of_comparable_elements(self) -> None:
        pairs = self._pairs()
        assert pairs["comparable_elements"].min() >= 1
        assert pairs["comparable_elements"].max() <= 6
        # Pairs compared on fewer elements cannot reach the same total weight.
        by_count = pairs.groupby("comparable_elements")["weight"].max()
        assert by_count.is_monotonic_increasing

    def test_every_pair_receives_exactly_one_decision(self) -> None:
        pairs = self._pairs()
        assert set(pairs["decision"]) <= {"link", "clerical_review", "non_link"}
        assert pairs["decision"].notna().all()

    def test_sensitivity_falls_and_precision_rises_as_the_cutoff_rises(self) -> None:
        curve = fs.threshold_curve(self._pairs(), n_points=12)
        for column in ("sensitivity", "false_match_rate", "declared_share"):
            # Non-increasing to floating-point tolerance: adjacent cutoffs can separate
            # near-identical pair sets, which leaves the rate flat rather than lower.
            assert np.all(np.diff(curve[column].to_numpy()) <= 1e-6), column
        assert curve["clerical_review_share"].iloc[-1] > curve["clerical_review_share"].iloc[0]

    def test_the_derived_operating_point_respects_the_false_match_constraint(self) -> None:
        pairs = self._pairs(60000)
        upper, lower = fs.derive_thresholds(
            pairs.loc[pairs["is_match"], "weight"].to_numpy(),
            pairs.loc[~pairs["is_match"], "weight"].to_numpy(),
            target_false_match_rate=0.005,
        )
        assert upper >= lower
        accepted = pairs[pairs["weight"] >= upper]
        false_matches = int((~accepted["is_match"]).sum())
        assert false_matches / max(len(accepted), 1) <= 0.01

    def test_the_derived_point_lands_near_the_pre_registered_one(self) -> None:
        pairs = self._pairs(60000)
        upper, lower = fs.derive_thresholds(
            pairs.loc[pairs["is_match"], "weight"].to_numpy(),
            pairs.loc[~pairs["is_match"], "weight"].to_numpy(),
        )
        assert abs(upper - fs.WeightSchedule().upper) < 4.0
        assert abs(lower - fs.WeightSchedule().lower) < 4.0

    def test_the_clerical_review_band_is_genuinely_mixed(self) -> None:
        pairs = self._pairs()
        schedule = fs.WeightSchedule()
        band = pairs[
            (pairs["weight"] >= schedule.lower) & (pairs["weight"] < schedule.upper)
        ]
        share_matched = float(band["is_match"].mean())
        # A band containing only matches or only non-matches would not need review.
        assert 0.0 < share_matched < 1.0


class TestOperatingCharacteristics:
    def test_the_reported_characteristics_are_internally_consistent(self) -> None:
        pairs = fs.simulate_candidate_pairs(40000, seed=11)
        result = fs.operating_characteristics(pairs, fs.WeightSchedule())
        for key in ("sensitivity", "false_match_rate", "clerical_review_share"):
            assert key in result
        assert 0.0 <= result["sensitivity"] <= 1.0
        assert 0.0 <= result["false_match_rate"] <= 1.0
        assert 0.0 <= result["clerical_review_share"] <= 1.0


class TestLinkageAccuracy:
    def test_reproduces_the_published_two_by_two_table(self) -> None:
        accuracy = eq.linkage_accuracy(eq.ConfusionMatrix(tp=7353, fp=21, fn=251, tn=4257))
        assert accuracy["sensitivity"].estimate == pytest.approx(0.967, abs=0.001)
        assert accuracy["specificity"].estimate == pytest.approx(0.995, abs=0.001)
        assert accuracy["ppv"].estimate == pytest.approx(0.997, abs=0.001)
        assert accuracy["npv"].estimate == pytest.approx(0.944, abs=0.001)

    def test_the_false_match_rate_is_the_complement_of_precision(self) -> None:
        accuracy = eq.linkage_accuracy(eq.ConfusionMatrix(tp=7353, fp=21, fn=251, tn=4257))
        assert accuracy["false_match_rate"].estimate == pytest.approx(
            1 - accuracy["ppv"].estimate, abs=1e-9
        )

    def test_every_interval_brackets_its_estimate(self) -> None:
        accuracy = eq.linkage_accuracy(eq.ConfusionMatrix(tp=500, fp=10, fn=40, tn=450))
        for name, value in accuracy.items():
            if isinstance(value, eq.Interval):
                assert value.lower <= value.estimate <= value.upper, name


class TestMatchRate:
    def test_matches_the_published_rate_and_checks_the_threshold(self) -> None:
        result = fs.match_rate(linked=68412993, eligible=71114000)
        assert result["rate"] == pytest.approx(0.962, abs=0.001)
        assert result["ci"][0] < result["rate"] < result["ci"][1]
        assert result["threshold"]["passes"] is True
        assert result["threshold"]["key"] == "F_match_rate"

    def test_a_linked_count_above_the_eligible_count_is_refused(self) -> None:
        with pytest.raises(ValueError):
            fs.match_rate(linked=100, eligible=10)
