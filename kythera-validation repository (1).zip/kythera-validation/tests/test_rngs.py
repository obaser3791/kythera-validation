"""Tests for the named random streams.

A stream collision does not raise; it produces numbers that look reasonable and are wrong.
These tests exist because exactly that happened during development: drawing the train-test
split from the same seed as the surrogate data moved an apparent c-statistic by more than a
tenth, because the split indicator was no longer independent of the outcome.
"""

from __future__ import annotations

import numpy as np
import pytest

from kythera_validation import rngs


def test_a_stream_is_reproducible_under_the_same_seed_and_purpose() -> None:
    first = rngs.stream(20250731, "block_i_random_split").random(1000)
    second = rngs.stream(20250731, "block_i_random_split").random(1000)
    assert np.array_equal(first, second)


def test_different_purposes_give_different_sequences_under_one_seed() -> None:
    a = rngs.stream(20250731, "block_e_mice").random(1000)
    b = rngs.stream(20250731, "block_i_random_split").random(1000)
    assert not np.allclose(a, b)
    assert abs(float(np.corrcoef(a, b)[0, 1])) < 0.1


def test_different_seeds_give_different_sequences_for_one_purpose() -> None:
    a = rngs.stream(1, "surrogate").random(500)
    b = rngs.stream(2, "surrogate").random(500)
    assert not np.allclose(a, b)


def test_every_named_stream_in_the_package_is_independent_of_every_other() -> None:
    purposes = [
        "surrogate_patients",
        "block_e_mice",
        "block_i_random_split",
        "linkage_candidate_pairs",
    ]
    for i, first in enumerate(purposes):
        for second in purposes[i + 1 :]:
            assert rngs.are_independent(rngs.DEFAULT_SEED, first, second), (first, second)


def test_an_unnamed_stream_is_refused() -> None:
    with pytest.raises(ValueError):
        rngs.stream(1, "")


def test_the_split_indicator_is_uncorrelated_with_the_data_stream() -> None:
    # The concrete failure mode: a covariate drawn from one stream and a split indicator
    # drawn from another must not line up. If they do, the test set is systematically
    # different from the training set and every fitted model is evaluated unfairly.
    covariate = rngs.stream(rngs.DEFAULT_SEED, "surrogate_patients").normal(size=20000)
    indicator = rngs.stream(rngs.DEFAULT_SEED, "block_i_random_split").random(20000) < 0.7
    difference = covariate[indicator].mean() - covariate[~indicator].mean()
    assert abs(difference) < 0.05
