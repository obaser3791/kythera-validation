"""Tests for the command-line interface.

The interface is what a reader of the manuscript actually runs, so its exit codes and its
contract with the configuration files are tested directly.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]


def _run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-W", "ignore", "-m", "kythera_validation.cli", *args],
        cwd=REPO,
        env={"PYTHONPATH": "src", "PATH": "/usr/bin:/bin"},
        capture_output=True,
        text=True,
        timeout=900,
    )


class TestInfo:
    def test_info_succeeds_and_reports_the_configuration(self) -> None:
        result = _run("info")
        assert result.returncode == 0
        for expected in ("thresholds", "blocks", "conditions"):
            assert expected in result.stdout.lower()


class TestThresholds:
    def test_thresholds_prints_every_pre_registered_check(self) -> None:
        result = _run("thresholds")
        assert result.returncode == 0
        assert "A_cronbach_alpha" in result.stdout
        assert "I_auroc" in result.stdout

    def test_json_output_is_machine_readable_and_complete(self) -> None:
        result = _run("thresholds", "--json")
        assert result.returncode == 0
        payload = json.loads(result.stdout)
        assert len(payload) == 16
        for entry in payload:
            assert entry["key"], entry
            assert entry["operator"], entry["key"]
            assert entry["rationale"], entry["key"]
            assert entry["source"], entry["key"]


class TestVerify:
    def test_verify_exits_zero_when_the_code_agrees_with_the_manuscript(self) -> None:
        result = _run("verify", "--n", "20000")
        assert result.returncode == 0, result.stdout + result.stderr
        assert "agree" in result.stdout.lower()

    def test_verify_reports_a_check_for_every_published_quantity_it_covers(self) -> None:
        result = _run("verify", "--n", "20000")
        # Each line of the verification report names the published value it reproduces.
        for expected in ("cohort", "linkage", "alpha", "CFI", "RMSEA"):
            assert expected.lower() in result.stdout.lower(), expected


class TestRun:
    @pytest.mark.slow
    def test_run_writes_tables_figures_and_a_results_file(self, tmp_path: Path) -> None:
        out = tmp_path / "run"
        result = _run("run", "--n", "8000", "--out", str(out))
        assert result.returncode == 0, result.stdout + result.stderr
        assert (out / "results.json").exists()
        assert list((out / "tables").glob("*.csv"))
        assert list((out / "figures").glob("*.png"))
        payload = json.loads((out / "results.json").read_text())
        assert {"block_a", "block_i"} <= set(payload)

    @pytest.mark.slow
    def test_every_threshold_recorded_in_the_results_file_is_well_formed(
        self, tmp_path: Path
    ) -> None:
        out = tmp_path / "run"
        assert _run("run", "--n", "8000", "--out", str(out)).returncode == 0
        payload = json.loads((out / "results.json").read_text())

        def checks(node: object) -> list[dict]:
            found: list[dict] = []
            if isinstance(node, dict):
                if {"key", "observed", "operator", "threshold", "passes"} <= set(node):
                    found.append(node)
                else:
                    for value in node.values():
                        found.extend(checks(value))
            elif isinstance(node, list):
                for value in node:
                    found.extend(checks(value))
            return found

        recorded = checks(payload)
        assert len(recorded) >= 10
        for check in recorded:
            assert check["operator"] in {">=", "<=", "==", "<", ">"}, check["key"]
            assert isinstance(check["passes"], bool), check["key"]


class TestUnknownCommand:
    def test_an_unknown_command_fails_rather_than_doing_nothing(self) -> None:
        assert _run("not-a-command").returncode != 0
