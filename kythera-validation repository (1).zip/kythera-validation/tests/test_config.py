"""Tests for configuration integrity.

The configuration files are the contract between the manuscript and the code. If a threshold
key is renamed, a block silently stops being checked, so the keys are asserted explicitly.
"""

from __future__ import annotations

import pytest

from kythera_validation import config as cfg

EXPECTED_THRESHOLD_KEYS = {
    "A_cronbach_alpha",
    "A_test_retest_icc",
    "B_mape",
    "B_lins_ccc",
    "C_cfi",
    "C_tli",
    "C_rmsea",
    "C_srmr",
    "D_abs_smd",
    "E_pooled_fmi",
    "F_match_rate",
    "F_false_match_rate",
    "G_cohens_kappa",
    "H_abs_tau",
    "I_auroc",
    "I_brier",
}


class TestThresholds:
    def test_every_pre_registered_key_is_present(self) -> None:
        assert set(cfg.load_thresholds()) == EXPECTED_THRESHOLD_KEYS

    def test_each_threshold_is_fully_specified(self) -> None:
        for key, threshold in cfg.load_thresholds().items():
            assert threshold.operator in {">=", "<=", "==", "<", ">"}, key
            assert isinstance(threshold.value, (int, float)), key
            assert threshold.metric, key
            assert threshold.block, key
            assert threshold.rationale, key

    def test_check_applies_the_stated_operator(self) -> None:
        passing = cfg.check("A_cronbach_alpha", 0.85)
        failing = cfg.check("A_cronbach_alpha", 0.65)
        assert passing["passes"] is True
        assert failing["passes"] is False
        assert passing["operator"] == ">="
        assert cfg.check("C_rmsea", 0.03)["passes"] is True
        assert cfg.check("C_rmsea", 0.09)["passes"] is False

    def test_check_rejects_an_unknown_key(self) -> None:
        with pytest.raises(KeyError):
            cfg.check("Z_not_a_threshold", 1.0)

    def test_thresholds_can_be_selected_by_block(self) -> None:
        block_c = cfg.thresholds_for_block("C")
        assert set(block_c) == {"C_cfi", "C_tli", "C_rmsea", "C_srmr"}
        assert all(key.startswith("C_") for key in block_c)

    def test_every_block_letter_from_a_to_i_is_covered_or_documented(self) -> None:
        covered = {key.split("_")[0] for key in cfg.load_thresholds()}
        # Block G is keyed by condition and the provenance gates live in their own section,
        # so eight of the nine block letters appear here.
        assert covered == {"A", "B", "C", "D", "E", "F", "G", "H", "I"}


class TestStudyParameters:
    def test_the_cohort_ladder_is_monotone(self) -> None:
        params = cfg.load_study_parameters()
        ladder = [
            params["source_universe_tokens"],
            params["token_linked_subset"],
            params["cohort_two_observations"],
            params["analytic_cohort"],
        ]
        assert ladder == sorted(ladder, reverse=True)

    def test_the_analytic_cohort_is_a_credible_share_of_the_population(self) -> None:
        params = cfg.load_study_parameters()
        share = params["analytic_cohort"] / params["us_resident_population_2024"]
        assert 0.10 < share < 0.15


class TestProvenanceThresholds:
    def test_gate_bounds_are_present_and_ordered(self) -> None:
        gates = cfg.load_provenance_thresholds()
        assert gates["conformance_min"] > 0.99
        assert gates["referential_integrity_min"] > 0.97
        assert gates["quarantine_max"] < 0.01
        assert gates["latency_median_days_max"] == 14


class TestConditions:
    def test_each_condition_carries_codes_a_rule_and_a_comparator(self) -> None:
        conditions = cfg.load_conditions()["conditions"]
        assert len(conditions) == 6
        for name, spec in conditions.items():
            assert spec["icd10"], name
            assert spec["rule"], name
            assert spec["comparator_source"] in {"NHANES", "MEPS", "ACS"}, name
            assert spec["comparator_construct"], name
            # Every claims-survey comparison states what remains non-comparable after the
            # definitions are aligned, because that residual is the interpretation.
            assert spec["residual_noncomparability"], name

    def test_published_positive_predictive_values_are_ordered_probabilities(self) -> None:
        for name, spec in cfg.load_conditions()["conditions"].items():
            low, high = spec["published_ppv"]
            assert 0.0 < low <= high <= 1.0, name

    def test_the_look_back_window_matches_the_observability_requirement(self) -> None:
        settings = cfg.load_conditions()
        assert settings["lookback_months"] == 24
        assert settings["minimum_days_between_outpatient_codes"] == 30
        for name, spec in settings["conditions"].items():
            assert "24 months" in spec["rule"], name

    def test_the_intercoder_categories_are_distinct_and_exceed_the_condition_set(self) -> None:
        # The adjudication exercise codes ten diagnostic categories, of which six carry a
        # full claims definition; the remaining four are coded for agreement only.
        settings = cfg.load_conditions()
        categories = settings["intercoder_categories"]
        keys = [c["key"] for c in categories]
        assert len(set(keys)) == len(keys)
        assert len(keys) > len(settings["conditions"])
        # Depression is adjudicated under the broader mood-disorder category; every other
        # condition maps to a category of the same name.
        mapped = {
            spec.get("intercoder_key", name)
            for name, spec in settings["conditions"].items()
        }
        assert mapped <= set(keys)
        for category in categories:
            assert category["encounters"] > 0, category["key"]
            low, high = category["published_ppv"]
            assert 0.0 < low <= high <= 1.0, category["key"]


class TestCfaModel:
    def test_the_model_assigns_every_indicator_to_exactly_one_factor(self) -> None:
        model = cfg.load_cfa_model()
        assert len(model["factors"]) == 2
        names = [
            item["name"]
            for factor in model["factors"].values()
            for item in factor["indicators"]
        ]
        assert len(names) == len(set(names))

    def test_each_factor_is_identified_and_reports_its_reliability(self) -> None:
        for factor, spec in cfg.load_cfa_model()["factors"].items():
            assert len(spec["indicators"]) >= 3, factor
            assert 0.7 <= spec["composite_reliability_omega"] <= 1.0, factor
            # Average variance extracted above one half is the Fornell-Larcker requirement
            # for the factor to explain more of its indicators than error does.
            assert spec["average_variance_extracted"] > 0.5, factor

    def test_the_estimator_is_the_one_the_manuscript_specifies(self) -> None:
        model = cfg.load_cfa_model()
        assert model["estimator"] == "WLSMV"
        assert model["correlation"] == "polychoric"
        assert model["cross_loadings"] is False
        assert model["correlated_residuals"] is False

    def test_every_loading_is_admissible(self) -> None:
        for factor, spec in cfg.load_cfa_model()["factors"].items():
            for item in spec["indicators"]:
                assert 0.3 <= item["loading"] < 1.0, (factor, item["name"])
                assert item["se"] > 0, (factor, item["name"])


class TestReportedValues:
    def test_the_published_tables_are_loadable_and_non_empty(self) -> None:
        values = cfg.load_reported_values()
        assert values
        for table, payload in values.items():
            assert payload not in (None, {}, []), table

    def test_the_linkage_confusion_matrix_is_internally_consistent(self) -> None:
        table = cfg.load_reported_values()["table_12_linkage_overall"]
        tp, fp, fn, tn = table["tp"], table["fp"], table["fn"], table["tn"]
        sensitivity = tp / (tp + fn)
        specificity = tn / (tn + fp)
        assert sensitivity == pytest.approx(0.967, abs=0.002)
        assert specificity == pytest.approx(0.995, abs=0.002)

    def test_the_intake_table_carries_every_gate_and_the_latency_summary(self) -> None:
        table = cfg.load_reported_values()["table_1_intake_qa"]
        assert table["latency_median_days"] == 9
        assert table["latency_iqr_days"] == [7, 14]
        # Token availability is a coverage share, not a conformance rate, so it is checked
        # against the linked-subset fraction rather than the 0.99 gate.
        assert table["token_availability"] == pytest.approx(0.217, abs=0.01)
        gates = {
            "x12_837_syntax",
            "ncpdp_d0_conformance",
            "icd10cm_validity",
            "cpt_hcpcs_validity",
            "ndc_rxnorm_resolution",
            "provider_npi_resolution",
            "member_key_resolution",
        }
        assert gates <= set(table)
        for gate in gates:
            assert 0.9 <= table[gate] <= 1.0, gate
        assert table["records_quarantined"] < 0.005
