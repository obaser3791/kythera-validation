# kythera-validation

Reference implementation of the provenance-anchored nine-block validation framework applied to
the Kythera Labs all-payer real-world data asset.

This repository accompanies **Baser O. Validation of the Kythera Labs all-payer real-world data
asset: a provenance-anchored nine-block framework for tokenized evidence generation.** *BMC
Medical Research Methodology*.

The package does three separable things, and the distinction matters when reading the output:

1. **It states the framework.** All seventeen estimators, all sixteen pre-registered acceptance
   thresholds, the thirteen intake conformance gates, the six claims-based condition
   definitions and the two-factor measurement model are declared in code and configuration,
   not in prose. They can be inspected, criticised and reused without access to any licensed
   data.
2. **It verifies the manuscript against itself.** `kythera-validate verify` recomputes the
   published quantities that are recoverable from the values printed in the tables - the
   cohort ladder, the linkage two-by-two table, the reliability coefficients, the fit indices -
   and fails if the code and the manuscript disagree.
3. **It runs the whole pipeline against a surrogate cohort.** Because the licensed asset cannot
   be redistributed, the repository ships a generator that produces a cohort with the same
   schema, the same missingness structure and the same marginal distributions as the analytic
   file. Running the pipeline against it demonstrates that the code executes, that each block
   returns what the tables require, and that the thresholds are applied - it does **not**
   reproduce the published point estimates, and no output from it should be cited as though it
   did.

## Installation

```bash
git clone https://github.com/obaser3791/kythera-validation.git
cd kythera-validation
pip install -e .
```

Or with conda:

```bash
conda env create -f environment.yml
conda activate kythera-validation
```

Requires Python 3.11 or later. The dependency set is deliberately small: numpy, pandas, scipy,
scikit-learn, matplotlib and pyyaml. No proprietary or commercially licensed statistical
software is needed to run anything in this repository.

## Quick start

```bash
# What is declared: thresholds, blocks, conditions, intake gates
kythera-validate info

# The pre-registered acceptance criteria, with source and rationale for each cutoff
kythera-validate thresholds
kythera-validate thresholds --json

# Check the code against the published values
kythera-validate verify --n 20000

# Run all nine blocks against a surrogate cohort and write tables, figures and results
kythera-validate run --n 250000 --simulate-linkage --n-pairs 1000000 --out outputs/full

# Write a surrogate cohort to disk for independent inspection
kythera-validate surrogate --out data/surrogate --n 250000
```

Or use the Makefile, which fixes the seed and cohort size used in the manuscript:

```bash
make verify     # agreement check against the published tables
make run        # full pipeline, 250,000 surrogate patients
make test       # the test suite
make figures    # regenerate the manuscript figures
make all
```

## What each block does

| Block | Question | Primary estimators | Pre-registered criterion |
| --- | --- | --- | --- |
| A | Do composite measures cohere and hold still over time? | Cronbach's alpha, two-way random-effects ICC, positive specific agreement | alpha >= 0.80, ICC >= 0.70 |
| B | Do prevalence and utilisation estimates agree with national survey benchmarks? | MAPE, Lin's concordance correlation | MAPE <= 0.05, CCC >= 0.90 |
| C | Does the intended factor structure hold? | Polychoric CFA by WLSMV, CFI, TLI, RMSEA, SRMR, Fornell-Larcker | CFI and TLI >= 0.95, RMSEA <= 0.06, SRMR <= 0.08 |
| D | Is the cohort representative of the United States population? | Standardized mean differences against ACS, iterative proportional fitting | absolute SMD < 0.10 after raking |
| E | Is missingness ignorable, and what does it cost? | Little's MCAR test, MICE with Rubin pooling, fraction of missing information | pooled FMI <= 0.30 |
| F | How accurate is tokenized linkage? | Fellegi-Sunter weights, derived two-threshold operating point, blinded adjudication | match rate >= 0.90, false-match rate <= 0.005 |
| G | Do independent coders agree on diagnostic assignment? | Cohen's kappa with Landis-Koch bands, positive predictive value | kappa >= 0.61 per category |
| H | Is data quality stable across the study period? | Mann-Kendall trend test, CUSUM change detection, minimum detectable effect | absolute Kendall tau <= 0.20 |
| I | Is the asset fit for prediction? | Logistic and gradient-boosted models, AUROC, calibration slope and intercept, Brier score | AUROC >= 0.75, Brier <= 0.20 |

Every block returns its own pre-registered checks as structured records, and every check
carries the observed value, the operator, the threshold, the literature source of the cutoff
and whether it was met. `run` collects them into a single summary table, so a failure is
visible rather than buried.

## Reproducibility scope

This is stated plainly because the alternative is to imply more than the repository can
deliver:

**Fully reproducible from public inputs.** All seventeen equations; the NHANES, MEPS and ACS
comparison targets; and Blocks B, C, D and H, which operate on published marginals and summary
statistics rather than on record-level data.

**Structure reproducible against the surrogate cohort only.** Blocks A, E and I require
record-level data. Running them against the surrogate demonstrates that the code is correct
and complete; it does not reproduce the published estimates, and the surrogate's parameters
were chosen to match published marginals rather than derived from the licensed file.

**Not reproducible outside the licensed environment.** The Block F adjudication file and the
Block G intercoder assignments contain protected health information and cannot be released.
They are published instead as de-identified aggregate classification tables, which are
sufficient to recompute every accuracy statistic reported in the manuscript but not to
reconstruct any individual record.

## Repository layout

```
config/          pre-registered thresholds, condition definitions, CFA model,
                 and the values transcribed from the manuscript tables
src/kythera_validation/
  equations.py   the seventeen estimators, each with its variance formula
  rngs.py        named independent random streams
  config.py      typed loaders for every configuration file
  blocks/        one module per validation block, A through I
  linkage/       Fellegi-Sunter weights, threshold derivation, adjudication
  provenance/    intake conformance gates and the conditionality statement
  cohort/        the attrition ladder and the condition rules
  reporting/     manuscript tables and figures
  cli.py         the command-line interface
additional_files/  the five additional files submitted with the manuscript
notebooks/       an end-to-end reproduction notebook
tests/           the test suite
```

## Tests

```bash
make test
# or
PYTHONPATH=src pytest -q
PYTHONPATH=src pytest -q -m "not slow"   # skip the end-to-end pipeline tests
```

The tests compare each estimator against a closed-form value, a published worked example, or
an analytic property it must satisfy - not against whatever the implementation currently
returns. A test that only records current behaviour would still pass after the code broke.

Two classes of test exist because two classes of error occur. The first checks the mathematics.
The second checks that the configuration and the manuscript have not drifted apart: that every
threshold key is still present, that the cohort ladder is monotone, that the linkage
two-by-two table still yields the sensitivity printed in the paper.

## A note on the random streams

Every stochastic step draws from a named stream derived from the run seed. This is not
fastidiousness. During development, the train-test split indicator was drawn from the same seed
as the surrogate data; the two streams coincided, the split stopped being independent of the
outcome, and an apparent c-statistic moved by more than a tenth. The failure produced entirely
plausible numbers and raised nothing. `rngs.stream(seed, purpose)` makes the collision
impossible, and a test asserts that no two streams in the package agree.

## Licence and citation

MIT licence. See `LICENSE`.

If you use this framework, please cite the manuscript. `CITATION.cff` carries machine-readable
metadata.

## Contact

Onur Baser — onur.baser@sph.cuny.edu
Graduate School of Public Health and Health Policy, City University of New York
