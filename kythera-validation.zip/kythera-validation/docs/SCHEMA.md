# Expected parquet schema

All production inputs are Apache Parquet, Snappy-compressed, one file per
table. Column names and dtypes must match exactly.

## `patients.parquet`

| column           | dtype           | notes                                        |
| ---------------- | --------------- | -------------------------------------------- |
| patient_id       | string          | Kythera tokenised ID                         |
| dob_yyyymm       | string (YYYYMM) | date of birth truncated to year+month        |
| sex              | string          | "F" / "M"                                    |
| race_ethnicity   | string          | OMB 1997 categories                          |
| state            | string          | 2-letter USPS code                           |
| payer_type       | string          | Commercial / Medicare / Medicaid             |
| enrollment_days  | Int32           | cumulative days in the observation window   |
| dead             | Int8            | 1 if death observed in SSA DMF or claims EOL |

## `medical_claims.parquet`

| column            | dtype           | notes                                   |
| ----------------- | --------------- | --------------------------------------- |
| patient_id        | string          | FK → patients                           |
| claim_id          | string          | unique                                  |
| service_date      | datetime64[ns]  |                                         |
| icd10_principal   | string          | ICD-10-CM principal diagnosis           |
| cpt_hcpcs         | string          | primary procedure                       |
| drg               | string          | MS-DRG (inpatient only, else empty)    |
| provider_npi      | string          |                                         |
| facility_type     | string          | office / inpatient / outpatient / ed    |
| place_of_service  | string          | CMS POS code                            |
| charge_amount     | float64         | submitted charge, USD                   |

## `pharmacy_claims.parquet`

| column      | dtype          | notes                  |
| ----------- | -------------- | ---------------------- |
| patient_id  | string         | FK → patients          |
| fill_id     | string         | unique                 |
| fill_date   | datetime64[ns] |                        |
| ndc         | string         | 11-digit NDC           |
| days_supply | Int32          |                        |
| quantity    | float64        |                        |

## `tokenized_linkage.parquet`

| column      | dtype   | notes                                             |
| ----------- | ------- | ------------------------------------------------- |
| left_id     | string  | patient_id in left source                         |
| right_id    | string  | patient_id in right source                        |
| score       | float64 | Fellegi–Sunter log-likelihood ratio               |
| block_key   | string  | concatenation of blocking keys used for candidacy |

External reference data (ACS, NHANES, MEPS) are loaded from public parquet
mirrors kept alongside the code inventory at your local site — **they are not
redistributed in this repository**.
