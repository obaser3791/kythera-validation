# Pre-registered estimating equations

The paper declares **seventeen** pre-registered equations. This file maps each
equation to the Python function that implements it so reviewers can trace any
headline number in the manuscript back to a single line of code.

| Eq. | Block | Function | Definition |
| --: | :---: | :------- | :--------- |
| 1  | A | `cronbach_alpha` | α = (k/(k−1))·(1 − Σ σ²ᵢ / σ²ₜ) |
| 2  | B | `mape` | MAPE = mean(\|O − B\| / \|B\|) × 100 |
| 3  | C | `cfa_fit` → CFI | 1 − max(χ²ₘ − dfₘ, 0) / max(χ²ᵦ − dfᵦ, 0) |
| 4  | C | `cfa_fit` → TLI | (χ²ᵦ/dfᵦ − χ²ₘ/dfₘ) / (χ²ᵦ/dfᵦ − 1) |
| 5  | C | `cfa_fit` → RMSEA | √max((χ²ₘ − dfₘ) / (dfₘ·(n − 1)), 0) |
| 6  | C | `cfa_fit` → SRMR | √mean((residuals / √(diag·diag))²) |
| 7  | D | `standardized_mean_difference` | \|μ_s − μ_b\| / σ_pooled |
| 8  | E | `littles_mcar` | LR-style χ² on missing-pattern groups |
| 9  | E | `fraction_missing_information` | FMI ≈ (r + 2/(df+3)) / (r+1) |
| 10 | F | `fellegi_sunter` | w = Σ log(mᵢ/uᵢ) on agreements |
| 11 | F | `em_mu` | EM estimates of m, u and π |
| 12 | F | `fellegi_sunter.false_match_rate` | FMR among decided matches |
| 13 | G | `cohens_kappa` | (p_o − p_e) / (1 − p_e) |
| 14 | H | `cusum` → C⁺ | max(0, C⁺ₜ₋₁ + (xₜ − μ) − k·σ) |
| 15 | H | `cusum` → C⁻ | max(0, C⁻ₜ₋₁ − (xₜ − μ) − k·σ) |
| 16 | I | `auroc` (mortality)   | P(score_case > score_control) |
| 17 | I | `auroc` (readmission) | same, re-estimated on readmission target |
