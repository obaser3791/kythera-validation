#!/usr/bin/env python
"""End-to-end driver: runs every block in the nine-block framework.

For production runs, point ``--input`` at a DUA-approved Kythera extract.
For the synthetic demo used by CI, omit ``--input`` and a reproducible
cohort is generated in-memory.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

# Make `kythera_validation` importable when running from source tree.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from kythera_validation.reporting import write_all_outputs  # noqa: E402
from kythera_validation.synthetic import generate_synthetic_cohort  # noqa: E402


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", required=True, type=Path)
    p.add_argument("--input", type=Path, help="path to parquet root (production only)")
    p.add_argument("--out", type=Path, default=Path("out"))
    args = p.parse_args()

    cfg = yaml.safe_load(args.config.read_text())

    if args.input is None:
        n = cfg.get("cohort", {}).get("n_patients", 50_000)
        seed = cfg.get("random_seed", 20260101)
        print(f"[run] synthetic cohort  n={n:,}  seed={seed}")
        cohort = generate_synthetic_cohort(n_patients=n, seed=seed)
    else:
        # Production path — deliberately stubbed. Implementing the full loader
        # requires the licensed extract; the schema is documented in
        # docs/SCHEMA.md and the expected file layout in configs/kythera_production.yaml.
        raise NotImplementedError(
            "Production loader omitted from the public repository. "
            "See docs/SCHEMA.md for the expected parquet schema and wire it "
            "into `scripts/run_validation.py` inside your DUA-approved environment."
        )

    args.out.mkdir(parents=True, exist_ok=True)
    written = write_all_outputs(cohort, cfg, args.out)
    print("[run] wrote:")
    for name, path in written.items():
        print(f"    {name:<12s} -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
