# kythera-validation

Reproducible, pre-registered validation of the **Kythera Labs all-payer tokenized real-world data asset** using a nine-block framework for administrative-claims evidence generation.

Companion code for:

> Baser, O. *Validation of the Kythera Labs all-payer real-world data asset: a nine-block framework for all-payer tokenized evidence generation.* BMC Medical Research Methodology (submitted, 2026).

The framework is **scoped to administrative claims** (medical, pharmacy and eligibility). Laboratory values, vital signs and patient-reported outcomes are out of scope.

---

## Nine-block validation framework

| Block | Name                    | Primary statistic                           | Threshold           |
| ----- | ----------------------- | ------------------------------------------- | ------------------- |
| A     | Internal consistency    | Cronbach's α on claims-derived composites   | α ≥ 0.80            |
| B     | Concurrent validity     | MAPE vs NHANES / MEPS benchmarks            | MAPE ≤ 5 %          |
| C     | Construct validity      | CFA fit indices (CFI, TLI, RMSEA, SRMR)     | CFI ≥ 0.95          |
| D     | Representativeness      | Standardised mean differences vs ACS        | \|SMD\| ≤ 0.10      |
| E     | Missingness             | Little's MCAR + FMI from MICE               | FMI ≤ 0.30          |
| F     | Record linkage          | Fellegi–Sunter match rate, false-match rate | match ≥ 90 %        |
| G     | Inter-coder reliability | Cohen's κ on dual ICD-10-CM coding          | κ ≥ 0.61            |
| H     | Temporal stability      | CUSUM on monthly claim volumes              | no out-of-control   |
| I     | Predictive validity     | AUROC for mortality and readmission         | AUROC ≥ 0.75 / 0.80 |

All seventeen pre-registered estimating equations are implemented in `kythera_validation/framework.py` and documented in `docs/EQUATIONS.md`.

---

## Quick start

```bash
git clone https://github.com/obaser3791/kythera-validation.git
cd kythera-validation
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

# End-to-end dry run on synthetic data — writes all nine-block outputs to ./out
python scripts/run_validation.py --config configs/synthetic.yaml --out out/

# Unit tests
pytest -q
```

The synthetic run finishes in roughly one minute on a laptop and reproduces the
structure of every table and figure in the paper (values differ because the
synthetic dataset is random, but all estimators exercise their full pipeline).

---

## Running against the real Kythera asset

The Kythera Labs data are distributed by Columbia Data Analytics under a Data
Use Agreement and are **not** redistributed here. Once you have access, point the
loader at your local extract:

```bash
python scripts/run_validation.py \
    --config configs/kythera_production.yaml \
    --input /path/to/kythera_parquet \
    --out out/2026q1
```

The expected schema is documented in `docs/SCHEMA.md`. A tiny synthetic sample
(`data/synthetic/*.parquet`) demonstrates the columns and dtypes.

---

## Headline results (paper, Table 1)

| Statistic                           | Value                        |
| ----------------------------------- | ---------------------------- |
| Analytic cohort                     | 38,947,221 patients          |
| Source universe                     | 315,817,351 unique patients  |
| Tokenized linked                    | 68,412,993 patients          |
| Cronbach's α (Elixhauser composite) | **0.89**                     |
| Cronbach's α (Charlson composite)   | **0.87**                     |
| MAPE (diabetes prevalence vs MEPS)  | **2.8 %**                    |
| CFA fit                             | CFI 0.971, RMSEA 0.038       |
| Max \|SMD\| vs ACS 2023             | **0.061**                    |
| Tokenized linkage match rate        | **96.2 %** (FMR 0.003)       |
| Cohen's κ on dual ICD-10-CM         | **0.84**                     |
| AUROC (90-day mortality)            | **0.834**                    |
| AUROC (30-day readmission)          | **0.791**                    |

---

## Repository layout

```
kythera-validation/
├── kythera_validation/       # installable Python package
│   ├── __init__.py
│   ├── framework.py          # nine-block estimators (equations 1–17)
│   ├── linkage.py            # Fellegi–Sunter tokenized linkage
│   ├── loaders.py            # parquet loaders + schema validators
│   ├── benchmarks.py         # NHANES / MEPS / ACS reference loaders
│   ├── reporting.py          # table + figure builders
│   ├── synthetic.py          # reproducible synthetic cohort generator
│   └── cli.py                # `python -m kythera_validation` entry point
├── scripts/
│   └── run_validation.py     # end-to-end driver
├── tests/                    # pytest unit tests (one per block)
├── configs/                  # YAML configs (synthetic + production)
├── docs/                     # EQUATIONS.md, SCHEMA.md
└── data/synthetic/           # tiny parquet sample matching production schema
```

---

## Availability of data and materials

All analysis code, pre-registered equations, unit tests and a reproducible
environment are released here under the MIT licence. Kythera Labs claims data
are available from Columbia Data Analytics under a Data Use Agreement. External
reference data (NHANES, MEPS, ACS) are available without restriction from the
respective US federal agencies.

## Citation

```bibtex
@article{baser2026kythera,
  title   = {Validation of the Kythera Labs all-payer real-world data asset:
             a nine-block framework for all-payer tokenized evidence generation},
  author  = {Baser, Onur},
  journal = {BMC Medical Research Methodology},
  year    = {2026},
  note    = {Code: \url{https://github.com/obaser3791/kythera-validation}}
}
```

## Licence

MIT — see [LICENSE](LICENSE).

## Contact

Onur Baser · Graduate School of Public Health and Health Policy, CUNY · `onur.baser@sph.cuny.edu`
