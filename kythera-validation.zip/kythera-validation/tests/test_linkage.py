"""Tokenised linkage — EM estimation and pair scoring."""

from __future__ import annotations

import numpy as np
import pandas as pd

from kythera_validation.linkage import build_candidate_pairs, em_mu, score_pairs


def _make_pairs(n: int = 1_000, seed: int = 11) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n_match = n // 5
    # True matches: agree on all three fields most of the time.
    match = pd.DataFrame(
        {
            "sex_L": rng.choice(["F", "M"], n_match),
            "sex_R": None,
            "state_L": rng.choice(["CA", "NY", "TX"], n_match),
            "state_R": None,
            "dob_yyyymm_L": rng.choice(["196501", "197003", "198508"], n_match),
            "dob_yyyymm_R": None,
        }
    )
    match["sex_R"] = match["sex_L"].where(rng.random(n_match) < 0.95, "F")
    match["state_R"] = match["state_L"].where(rng.random(n_match) < 0.90, "CA")
    match["dob_yyyymm_R"] = match["dob_yyyymm_L"].where(rng.random(n_match) < 0.92, "196501")

    n_non = n - n_match
    non = pd.DataFrame(
        {
            "sex_L": rng.choice(["F", "M"], n_non),
            "sex_R": rng.choice(["F", "M"], n_non),
            "state_L": rng.choice(["CA", "NY", "TX"], n_non),
            "state_R": rng.choice(["CA", "NY", "TX"], n_non),
            "dob_yyyymm_L": rng.choice(["196501", "197003", "198508"], n_non),
            "dob_yyyymm_R": rng.choice(["196501", "197003", "198508"], n_non),
        }
    )
    return pd.concat([match, non], ignore_index=True)


def test_em_recovers_high_m_probs():
    pairs = _make_pairs(2_000)
    m, u, pi = em_mu(pairs, ["sex", "state", "dob_yyyymm"], max_iter=80)
    for f in ("sex", "state", "dob_yyyymm"):
        assert m[f] > u[f], f"{f} should have m > u"
    assert 0.0 < pi < 1.0


def test_score_pairs_full_agreement_beats_any_disagreement():
    # Pair 0: full agreement. Pair 1: one disagreement. Pair 2: both disagree.
    pairs = pd.DataFrame(
        {
            "sex_L": ["F", "F", "F"],
            "sex_R": ["F", "F", "M"],
            "state_L": ["CA", "CA", "CA"],
            "state_R": ["CA", "NY", "NY"],
        }
    )
    m = {"sex": 0.95, "state": 0.90}
    u = {"sex": 0.50, "state": 0.10}
    s = score_pairs(pairs, ["sex", "state"], m, u)
    assert s[0] > s[1]
    assert s[0] > s[2]
    assert s[1] > s[2]


def test_build_candidate_pairs_joins_on_keys():
    left = pd.DataFrame({"block": ["A", "A", "B"], "id": [1, 2, 3]})
    right = pd.DataFrame({"block": ["A", "B", "B"], "id": [10, 20, 30]})
    pairs = build_candidate_pairs(left, right, ["block"])
    # Blocking on "block" gives 2 (A) + 2 (B) = 4 candidate pairs.
    assert len(pairs) == 4
