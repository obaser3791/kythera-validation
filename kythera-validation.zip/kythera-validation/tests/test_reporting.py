"""End-to-end reporting tests."""

from __future__ import annotations

from pathlib import Path

import yaml

from kythera_validation.reporting import (
    build_table2_internal_consistency,
    build_table3_concurrent_validity,
    write_all_outputs,
)
from kythera_validation.synthetic import generate_synthetic_cohort

ROOT = Path(__file__).resolve().parents[1]
SYN_CONFIG = ROOT / "configs" / "synthetic.yaml"


def test_table2_has_seven_composites():
    cfg = yaml.safe_load(SYN_CONFIG.read_text())
    t2 = build_table2_internal_consistency(
        cfg["blocks"]["internal_consistency"]["composites"]
    )
    assert len(t2) == 7
    assert "Composite" in t2.columns


def test_table3_has_six_conditions():
    cfg = yaml.safe_load(SYN_CONFIG.read_text())
    t3 = build_table3_concurrent_validity(
        cfg["blocks"]["concurrent_validity"]["conditions"]
    )
    assert len(t3) == 6
    assert all(row.endswith("%") for row in t3["MAPE"])


def test_write_all_outputs_emits_expected_files(tmp_path: Path):
    cfg = yaml.safe_load(SYN_CONFIG.read_text())
    cohort = generate_synthetic_cohort(n_patients=2_000, seed=9)
    out = write_all_outputs(cohort, cfg, tmp_path)
    for key in ("table2", "table3", "linkage", "cusum", "predictive", "manifest"):
        assert out[key].exists(), f"{key} not written"
