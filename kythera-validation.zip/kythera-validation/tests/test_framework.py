"""Unit tests — one focused case per nine-block estimator."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from kythera_validation import framework as F


# ---------------------------------------------------------------------------
# Block A
# ---------------------------------------------------------------------------
def test_cronbach_alpha_matches_classic_identity():
    rng = np.random.default_rng(0)
    latent = rng.normal(size=2_000)
    k, lam = 10, 0.8
    items = (latent[:, None] * lam + rng.normal(size=(2_000, k)) * np.sqrt(1 - lam**2)) > 0
    a = F.cronbach_alpha(pd.DataFrame(items.astype(int)))
    assert 0.65 <= a <= 0.95, f"α out of plausible band: {a}"


def test_cronbach_alpha_requires_two_columns():
    with pytest.raises(ValueError):
        F.cronbach_alpha(pd.DataFrame({"a": [0, 1, 1]}))


# ---------------------------------------------------------------------------
# Block B
# ---------------------------------------------------------------------------
def test_mape_exact_value():
    assert F.mape(0.115, 0.118) == pytest.approx(2.542, abs=1e-2)


def test_mape_rejects_zero_benchmark():
    with pytest.raises(ValueError):
        F.mape(0.1, 0.0)


# ---------------------------------------------------------------------------
# Block C
# ---------------------------------------------------------------------------
def test_cfa_perfect_fit_hits_cfi_one():
    rng = np.random.default_rng(1)
    p = 5
    L = rng.uniform(0.5, 0.9, (p, p))
    cov = L @ L.T + np.eye(p) * 0.1
    out = F.cfa_fit(cov, cov, n_obs=1000, df_model=4, df_baseline=10)
    assert out.cfi == pytest.approx(1.0)
    assert out.rmsea == pytest.approx(0.0, abs=1e-9)


# ---------------------------------------------------------------------------
# Block D
# ---------------------------------------------------------------------------
def test_smd_zero_for_identical_distributions():
    x = np.array([1.0, 2.0, 3.0, 4.0])
    assert F.standardized_mean_difference(x, x) == 0.0


def test_smd_binary_positive():
    rng = np.random.default_rng(2)
    s = rng.binomial(1, 0.5, 10_000)
    b = rng.binomial(1, 0.7, 10_000)
    assert F.standardized_mean_difference(s, b, binary=True) > 0.3


# ---------------------------------------------------------------------------
# Block E
# ---------------------------------------------------------------------------
def test_fmi_monotone_in_between_variance():
    low = F.fraction_missing_information(within_var=1.0, between_var=0.1, m=20)
    high = F.fraction_missing_information(within_var=1.0, between_var=1.0, m=20)
    assert low < high


def test_littles_mcar_runs_and_returns_p():
    rng = np.random.default_rng(3)
    df = pd.DataFrame(rng.normal(size=(300, 4)), columns=list("abcd"))
    mask = rng.random(df.shape) < 0.1
    df = df.mask(mask)
    chi2, p = F.littles_mcar(df)
    assert chi2 >= 0
    assert 0.0 <= p <= 1.0


# ---------------------------------------------------------------------------
# Block F
# ---------------------------------------------------------------------------
def test_fellegi_sunter_identifies_most_matches():
    rng = np.random.default_rng(4)
    truth = rng.random(10_000) < 0.1
    scores = np.where(truth, rng.normal(8, 1.0, 10_000), rng.normal(-3, 1.2, 10_000))
    out = F.fellegi_sunter(scores, truth, upper=6.0)
    assert out.match_rate > 0.08
    assert out.false_match_rate < 0.02


# ---------------------------------------------------------------------------
# Block G
# ---------------------------------------------------------------------------
def test_kappa_perfect_agreement():
    a = np.array([0, 1, 1, 0, 1])
    assert F.cohens_kappa(a, a) == pytest.approx(1.0)


def test_kappa_chance_near_zero():
    rng = np.random.default_rng(5)
    a = rng.integers(0, 3, 2_000)
    b = rng.integers(0, 3, 2_000)
    assert abs(F.cohens_kappa(a, b)) < 0.1


# ---------------------------------------------------------------------------
# Block H
# ---------------------------------------------------------------------------
def test_cusum_flags_obvious_shift():
    rng = np.random.default_rng(6)
    stable = rng.normal(100.0, 5.0, 60)
    shifted = np.concatenate([stable[:30], stable[30:] + 30])
    out = F.cusum(shifted)
    assert out["out_of_control"].any()


def test_cusum_quiet_on_stable_series():
    rng = np.random.default_rng(7)
    stable = rng.normal(100.0, 5.0, 60)
    out = F.cusum(stable)
    assert out["out_of_control"].sum() <= 2  # allow rare transient flags


# ---------------------------------------------------------------------------
# Block I
# ---------------------------------------------------------------------------
def test_auroc_perfect_separation():
    y = np.array([0, 0, 0, 1, 1, 1])
    score = np.array([0.1, 0.2, 0.3, 0.9, 0.95, 0.99])
    assert F.auroc(y, score) == pytest.approx(1.0)
