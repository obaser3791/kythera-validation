"""Shape and schema tests for the synthetic cohort generator."""

from __future__ import annotations

import numpy as np

from kythera_validation.loaders import (
    MEDICAL_COLUMNS,
    PATIENT_COLUMNS,
    PHARMACY_COLUMNS,
)
from kythera_validation.synthetic import generate_synthetic_cohort


def test_synthetic_is_deterministic():
    a = generate_synthetic_cohort(n_patients=500, seed=42)
    b = generate_synthetic_cohort(n_patients=500, seed=42)
    assert a.patients.equals(b.patients)
    np.testing.assert_array_equal(a.linkage_scores, b.linkage_scores)


def test_synthetic_schema_matches_loader_contract():
    c = generate_synthetic_cohort(n_patients=200, seed=1)
    assert set(PATIENT_COLUMNS).issubset(c.patients.columns)
    assert set(MEDICAL_COLUMNS).issubset(c.medical.columns)
    assert set(PHARMACY_COLUMNS).issubset(c.pharmacy.columns)


def test_synthetic_sizes_scale():
    c = generate_synthetic_cohort(n_patients=1_000, seed=3)
    assert len(c.patients) == 1_000
    assert len(c.medical) == 20_000
    assert len(c.pharmacy) == 12_000
