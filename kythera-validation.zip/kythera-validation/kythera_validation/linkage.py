"""Tokenized Fellegi–Sunter record-linkage helpers.

Given two tokenised extracts (e.g. medical-claims vs pharmacy-claims), generate
candidate pairs by blocking on low-cardinality keys, compute comparison vectors,
and estimate m- and u-probabilities via the EM algorithm.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = ["LinkageConfig", "build_candidate_pairs", "score_pairs", "em_mu"]


@dataclass
class LinkageConfig:
    blocking_keys: list[str]
    compare_fields: list[str]
    upper: float = 6.0
    lower: float = -2.0
    max_iter: int = 50
    tol: float = 1e-4


def build_candidate_pairs(
    left: pd.DataFrame, right: pd.DataFrame, keys: list[str]
) -> pd.DataFrame:
    """Cartesian join within each blocking stratum."""
    missing = [k for k in keys if k not in left.columns or k not in right.columns]
    if missing:
        raise KeyError(f"blocking keys missing from one side: {missing}")
    return left.merge(right, on=keys, how="inner", suffixes=("_L", "_R"))


def score_pairs(
    pairs: pd.DataFrame,
    compare_fields: list[str],
    m: dict[str, float],
    u: dict[str, float],
) -> np.ndarray:
    """Compute pairwise log-likelihood-ratio scores."""
    score = np.zeros(len(pairs))
    for f in compare_fields:
        agree = (pairs[f + "_L"] == pairs[f + "_R"]).to_numpy()
        # Log-likelihood ratio: log(m/u) on agreement, log((1-m)/(1-u)) on disagreement.
        score += np.where(
            agree,
            np.log(m[f] / u[f]),
            np.log((1 - m[f]) / (1 - u[f])),
        )
    return score


def em_mu(
    pairs: pd.DataFrame,
    compare_fields: list[str],
    max_iter: int = 50,
    tol: float = 1e-4,
) -> tuple[dict[str, float], dict[str, float], float]:
    """Estimate m- and u-probabilities plus the prior match rate π via EM.

    Returns ``(m, u, pi)``.
    """
    agree = np.column_stack(
        [(pairs[f + "_L"] == pairs[f + "_R"]).to_numpy() for f in compare_fields]
    ).astype(float)
    n, k = agree.shape

    # Initialise
    m = {f: 0.9 for f in compare_fields}
    u = {f: 0.1 for f in compare_fields}
    pi = 0.1

    prev_ll = -np.inf
    for _ in range(max_iter):
        # E-step: posterior probability each pair is a match.
        log_pm = np.log(pi) + agree @ np.log([m[f] for f in compare_fields]) + (
            1 - agree
        ) @ np.log([1 - m[f] for f in compare_fields])
        log_pu = np.log(1 - pi) + agree @ np.log([u[f] for f in compare_fields]) + (
            1 - agree
        ) @ np.log([1 - u[f] for f in compare_fields])
        max_log = np.maximum(log_pm, log_pu)
        denom = max_log + np.log(np.exp(log_pm - max_log) + np.exp(log_pu - max_log))
        g = np.exp(log_pm - denom)

        # M-step
        pi = float(g.mean())
        for j, f in enumerate(compare_fields):
            m[f] = float((g * agree[:, j]).sum() / max(g.sum(), 1e-9))
            u[f] = float(((1 - g) * agree[:, j]).sum() / max((1 - g).sum(), 1e-9))
            # Bound away from 0/1 for numerical stability.
            m[f] = min(max(m[f], 1e-4), 1 - 1e-4)
            u[f] = min(max(u[f], 1e-4), 1 - 1e-4)

        ll = float(denom.sum())
        if abs(ll - prev_ll) < tol:
            break
        prev_ll = ll

    return m, u, pi
