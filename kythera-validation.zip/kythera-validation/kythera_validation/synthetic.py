"""Deterministic synthetic cohort generator used by CI and tutorials.

Produces a small parquet-shaped pandas bundle with the exact schema the
production code expects. Useful for local dry runs and for exercising every
estimator end-to-end without access to the licensed Kythera asset.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = ["SyntheticCohort", "generate_synthetic_cohort"]


@dataclass
class SyntheticCohort:
    patients: pd.DataFrame
    medical: pd.DataFrame
    pharmacy: pd.DataFrame
    linkage_scores: np.ndarray
    linkage_truth: np.ndarray


def generate_synthetic_cohort(n_patients: int = 50_000, seed: int = 20260101) -> SyntheticCohort:
    """Return a reproducible synthetic cohort matching the production schema."""
    rng = np.random.default_rng(seed)

    # --------------------- patients ---------------------
    patient_ids = np.array([f"P{i:09d}" for i in range(n_patients)])
    dob_year = rng.integers(1935, 2010, n_patients)
    dob_month = rng.integers(1, 13, n_patients)
    dob_yyyymm = np.array([f"{y}{m:02d}" for y, m in zip(dob_year, dob_month, strict=False)])
    sex = rng.choice(["F", "M"], n_patients, p=[0.515, 0.485])
    race = rng.choice(
        ["White", "Black", "Hispanic", "Asian", "Other"],
        n_patients,
        p=[0.59, 0.135, 0.185, 0.06, 0.03],
    )
    state = rng.choice(
        ["CA", "TX", "NY", "FL", "IL", "PA", "OH", "GA", "NC", "MI"],
        n_patients,
    )
    payer = rng.choice(
        ["Commercial", "Medicare", "Medicaid"], n_patients, p=[0.55, 0.25, 0.20]
    )
    enrollment_days = rng.integers(365, 3_650, n_patients).astype("int32")
    dead = rng.binomial(1, 0.018, n_patients).astype("int8")

    patients = pd.DataFrame(
        {
            "patient_id": patient_ids,
            "dob_yyyymm": dob_yyyymm,
            "sex": sex,
            "race_ethnicity": race,
            "state": state,
            "payer_type": payer,
            "enrollment_days": enrollment_days,
            "dead": dead,
        }
    )

    # --------------------- medical claims ---------------------
    n_claims = n_patients * 20
    claim_idx = rng.integers(0, n_patients, n_claims)
    icd_pool = [
        "E11.9", "I10", "J44.9", "I50.9", "N18.3", "F32.9", "M17.9",
        "K21.9", "Z00.00", "J45.909", "I25.10",
    ]
    cpt_pool = ["99213", "99214", "99232", "99285", "70450", "80053", "93000"]
    drg_pool = ["", "190", "291", "470", "885", "871"]
    fac_pool = ["office", "inpatient", "outpatient", "ed"]

    medical = pd.DataFrame(
        {
            "patient_id": patient_ids[claim_idx],
            "claim_id": [f"C{i:012d}" for i in range(n_claims)],
            "service_date": pd.to_datetime(
                rng.integers(
                    pd.Timestamp("2015-01-01").value // 10**9,
                    pd.Timestamp("2025-07-31").value // 10**9,
                    n_claims,
                ),
                unit="s",
            ),
            "icd10_principal": rng.choice(icd_pool, n_claims),
            "cpt_hcpcs": rng.choice(cpt_pool, n_claims),
            "drg": rng.choice(drg_pool, n_claims),
            "provider_npi": [f"{rng.integers(1_000_000_000, 9_999_999_999)}" for _ in range(n_claims)],
            "facility_type": rng.choice(fac_pool, n_claims, p=[0.55, 0.12, 0.22, 0.11]),
            "place_of_service": rng.choice(["11", "21", "22", "23"], n_claims),
            "charge_amount": rng.gamma(2.0, 120.0, n_claims).round(2),
        }
    )

    # --------------------- pharmacy claims ---------------------
    n_fills = n_patients * 12
    fill_idx = rng.integers(0, n_patients, n_fills)
    pharmacy = pd.DataFrame(
        {
            "patient_id": patient_ids[fill_idx],
            "fill_id": [f"R{i:012d}" for i in range(n_fills)],
            "fill_date": pd.to_datetime(
                rng.integers(
                    pd.Timestamp("2015-01-01").value // 10**9,
                    pd.Timestamp("2025-07-31").value // 10**9,
                    n_fills,
                ),
                unit="s",
            ),
            "ndc": [f"{rng.integers(10_000, 99_999)}-{rng.integers(1000, 9999)}-{rng.integers(10, 99):02d}" for _ in range(n_fills)],
            "days_supply": rng.choice([30, 60, 90], n_fills, p=[0.65, 0.15, 0.20]).astype("int32"),
            "quantity": rng.gamma(3.0, 15.0, n_fills).round(1),
        }
    )

    # --------------------- linkage scores ---------------------
    n_pairs = 200_000
    # Mixture: 10% true matches (high-score), 90% non-matches (low-score).
    is_match = rng.random(n_pairs) < 0.10
    scores = np.where(
        is_match,
        rng.normal(8.0, 1.2, n_pairs),
        rng.normal(-3.0, 1.4, n_pairs),
    )

    return SyntheticCohort(
        patients=patients,
        medical=medical,
        pharmacy=pharmacy,
        linkage_scores=scores,
        linkage_truth=is_match,
    )
