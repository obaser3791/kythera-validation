"""Parquet loaders and schema validators for the Kythera extract."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

__all__ = ["PATIENT_COLUMNS", "MEDICAL_COLUMNS", "load_patients", "load_medical_claims"]

PATIENT_COLUMNS = {
    "patient_id": "string",
    "dob_yyyymm": "string",
    "sex": "string",
    "race_ethnicity": "string",
    "state": "string",
    "payer_type": "string",
    "enrollment_days": "Int32",
    "dead": "Int8",
}

MEDICAL_COLUMNS = {
    "patient_id": "string",
    "claim_id": "string",
    "service_date": "datetime64[ns]",
    "icd10_principal": "string",
    "cpt_hcpcs": "string",
    "drg": "string",
    "provider_npi": "string",
    "facility_type": "string",
    "place_of_service": "string",
    "charge_amount": "float64",
}

PHARMACY_COLUMNS = {
    "patient_id": "string",
    "fill_id": "string",
    "fill_date": "datetime64[ns]",
    "ndc": "string",
    "days_supply": "Int32",
    "quantity": "float64",
}


def _validate(df: pd.DataFrame, schema: dict[str, str], name: str) -> pd.DataFrame:
    missing = set(schema) - set(df.columns)
    if missing:
        raise ValueError(f"{name}: missing required columns {sorted(missing)}")
    return df[list(schema)]


def load_patients(path: str | Path) -> pd.DataFrame:
    df = pd.read_parquet(path)
    return _validate(df, PATIENT_COLUMNS, "patients")


def load_medical_claims(path: str | Path) -> pd.DataFrame:
    df = pd.read_parquet(path)
    return _validate(df, MEDICAL_COLUMNS, "medical_claims")


def load_pharmacy_claims(path: str | Path) -> pd.DataFrame:
    df = pd.read_parquet(path)
    return _validate(df, PHARMACY_COLUMNS, "pharmacy_claims")
