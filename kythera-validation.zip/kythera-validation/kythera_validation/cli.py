"""`python -m kythera_validation` — thin CLI wrapper around ``scripts/run_validation.py``."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

from .reporting import write_all_outputs
from .synthetic import generate_synthetic_cohort


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="kythera-validate")
    p.add_argument("--config", required=True, help="YAML config file")
    p.add_argument("--out", default="out", help="output directory")
    p.add_argument(
        "--n-patients",
        type=int,
        default=None,
        help="override patient count for synthetic runs",
    )
    args = p.parse_args(argv)

    cfg = yaml.safe_load(Path(args.config).read_text())
    n = args.n_patients or cfg.get("cohort", {}).get("n_patients", 10_000)
    seed = cfg.get("random_seed", 20260101)

    print(f"[kythera-validation] loading synthetic cohort n={n:,} seed={seed}")
    cohort = generate_synthetic_cohort(n_patients=n, seed=seed)

    print(f"[kythera-validation] writing outputs to {args.out}")
    written = write_all_outputs(cohort, cfg, args.out)
    for name, path in written.items():
        print(f"  {name:<12s} -> {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
