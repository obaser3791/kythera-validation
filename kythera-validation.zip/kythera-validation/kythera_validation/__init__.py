"""Kythera Labs nine-block validation framework.

Pre-registered, claims-only validation of the Kythera Labs all-payer tokenized
real-world data asset. All seventeen estimating equations referenced in the
companion paper are implemented in :mod:`kythera_validation.framework`.
"""

from __future__ import annotations

from .framework import (
    auroc,
    cfa_fit,
    cohens_kappa,
    cronbach_alpha,
    cusum,
    fellegi_sunter,
    fraction_missing_information,
    littles_mcar,
    mape,
    standardized_mean_difference,
)
from .reporting import (
    build_table2_internal_consistency,
    build_table3_concurrent_validity,
    write_all_outputs,
)
from .synthetic import generate_synthetic_cohort

__all__ = [
    "__version__",
    "auroc",
    "build_table2_internal_consistency",
    "build_table3_concurrent_validity",
    "cfa_fit",
    "cohens_kappa",
    "cronbach_alpha",
    "cusum",
    "fellegi_sunter",
    "fraction_missing_information",
    "generate_synthetic_cohort",
    "littles_mcar",
    "mape",
    "standardized_mean_difference",
    "write_all_outputs",
]

__version__ = "1.0.0"
