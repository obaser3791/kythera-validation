"""External public-use benchmark loaders.

Only ACS 2023, NHANES 2017–2020 and MEPS 2022 are used by the nine-block
framework. All three are freely available from US federal agencies and are
loaded from local parquet mirrors to guarantee reproducibility.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

__all__ = ["load_acs_2023", "load_meps_2022", "load_nhanes_2017_2020", "MEPS_PREVALENCE"]

# Published MEPS 2022 adult prevalence (weighted, self-report + claims confirmed).
# Used as the default benchmark for Block B when a full MEPS extract is not
# available. Source: MEPS-HC summary tables, 2022.
MEPS_PREVALENCE: dict[str, float] = {
    "diabetes": 0.118,
    "hypertension": 0.335,
    "copd": 0.064,
    "chf": 0.050,
    "ckd": 0.089,
    "depression": 0.192,
}


def load_acs_2023(path: str | Path) -> pd.DataFrame:
    """Load American Community Survey 2023 reference shares by stratum."""
    return pd.read_parquet(path)


def load_meps_2022(path: str | Path) -> pd.DataFrame:
    return pd.read_parquet(path)


def load_nhanes_2017_2020(path: str | Path) -> pd.DataFrame:
    return pd.read_parquet(path)
