"""Nine-block validation framework — estimators only.

Each public function corresponds to one or more of the seventeen
pre-registered estimating equations in the paper. Functions are pure, take
plain numpy/pandas inputs, and return scalar statistics plus (where relevant)
confidence intervals. No plotting, no I/O — see :mod:`kythera_validation.reporting`.

Block map
---------
A. Internal consistency .......... :func:`cronbach_alpha`
B. Concurrent validity ........... :func:`mape`
C. Construct validity ............ :func:`cfa_fit`
D. Representativeness ............ :func:`standardized_mean_difference`
E. Missingness ................... :func:`littles_mcar`, :func:`fraction_missing_information`
F. Record linkage ................ :func:`fellegi_sunter`
G. Inter-coder reliability ....... :func:`cohens_kappa`
H. Temporal stability ............ :func:`cusum`
I. Predictive validity ........... :func:`auroc`
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score

__all__ = [
    "CFAResult",
    "LinkageResult",
    "auroc",
    "cfa_fit",
    "cohens_kappa",
    "cronbach_alpha",
    "cusum",
    "fellegi_sunter",
    "fraction_missing_information",
    "littles_mcar",
    "mape",
    "standardized_mean_difference",
]


# ---------------------------------------------------------------------------
# Block A — Internal consistency  (Equation 1)
# ---------------------------------------------------------------------------
def cronbach_alpha(items: pd.DataFrame) -> float:
    """Cronbach's α for a set of binary or ordinal claims-derived indicator items.

    Parameters
    ----------
    items
        Rows = patients, columns = items (one per diagnosis flag, utilisation
        bucket, etc.). Must contain ≥2 columns with non-zero variance.

    Notes
    -----
    α = (k / (k - 1)) · (1 − Σ σ²_i / σ²_T)
    """
    x = np.asarray(items, dtype=float)
    if x.ndim != 2 or x.shape[1] < 2:
        raise ValueError("items must be 2D with at least 2 columns")
    k = x.shape[1]
    item_var = x.var(axis=0, ddof=1)
    total_var = x.sum(axis=1).var(ddof=1)
    if total_var <= 0:
        return float("nan")
    return float((k / (k - 1)) * (1 - item_var.sum() / total_var))


# ---------------------------------------------------------------------------
# Block B — Concurrent validity  (Equation 2)
# ---------------------------------------------------------------------------
def mape(observed: float | np.ndarray, benchmark: float | np.ndarray) -> float:
    """Mean absolute percentage error, expressed in percent.

    MAPE = mean(|(observed − benchmark)| / |benchmark|) × 100
    """
    o = np.atleast_1d(np.asarray(observed, dtype=float))
    b = np.atleast_1d(np.asarray(benchmark, dtype=float))
    if o.shape != b.shape:
        raise ValueError("observed and benchmark must have identical shape")
    if np.any(b == 0):
        raise ValueError("benchmark contains zero — MAPE undefined")
    return float(np.mean(np.abs((o - b) / b)) * 100.0)


# ---------------------------------------------------------------------------
# Block C — Construct validity  (Equations 3–6)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class CFAResult:
    cfi: float
    tli: float
    rmsea: float
    srmr: float

    def passes(self) -> bool:
        return (
            self.cfi >= 0.95
            and self.tli >= 0.95
            and self.rmsea <= 0.06
            and self.srmr <= 0.08
        )


def cfa_fit(
    observed_cov: np.ndarray,
    model_cov: np.ndarray,
    n_obs: int,
    df_model: int,
    df_baseline: int,
) -> CFAResult:
    """Approximate CFA fit indices from observed and model-implied covariance matrices.

    Uses the WLSMV-style discrepancy function. This is a light-weight
    implementation adequate for validation reporting; for production
    model-fitting use ``semopy`` or ``lavaan``.
    """
    obs = np.asarray(observed_cov, dtype=float)
    mod = np.asarray(model_cov, dtype=float)
    if obs.shape != mod.shape or obs.ndim != 2 or obs.shape[0] != obs.shape[1]:
        raise ValueError("covariance matrices must be square and identical shape")

    # Minimum-fit function (maximum-likelihood form)
    sign, logdet_obs = np.linalg.slogdet(obs)
    _, logdet_mod = np.linalg.slogdet(mod)
    if sign <= 0:
        raise ValueError("observed covariance not positive definite")

    p = obs.shape[0]
    inv_mod = np.linalg.pinv(mod)
    f_model = logdet_mod - logdet_obs + np.trace(inv_mod @ obs) - p
    chi2_model = max(n_obs * f_model, 0.0)

    # Baseline (independence) chi-square
    diag_obs = np.diag(np.diag(obs))
    inv_diag = np.linalg.pinv(diag_obs)
    f_base = (
        np.log(np.linalg.det(diag_obs))
        - logdet_obs
        + np.trace(inv_diag @ obs)
        - p
    )
    chi2_base = max(n_obs * f_base, 0.0)

    # Indices
    cfi = 1.0 - max(chi2_model - df_model, 0.0) / max(chi2_base - df_baseline, 1e-9)
    tli = (chi2_base / df_baseline - chi2_model / df_model) / (
        chi2_base / df_baseline - 1.0
    )
    rmsea = np.sqrt(max((chi2_model - df_model) / (df_model * (n_obs - 1)), 0.0))
    resid = obs - mod
    denom = np.sqrt(np.outer(np.diag(obs), np.diag(obs)))
    srmr = float(np.sqrt(np.mean((resid / denom) ** 2)))

    return CFAResult(
        cfi=float(np.clip(cfi, 0.0, 1.0)),
        tli=float(np.clip(tli, 0.0, 1.0)),
        rmsea=float(rmsea),
        srmr=srmr,
    )


# ---------------------------------------------------------------------------
# Block D — Representativeness  (Equation 7)
# ---------------------------------------------------------------------------
def standardized_mean_difference(
    sample: np.ndarray, benchmark: np.ndarray, binary: bool = False
) -> float:
    """Standardised mean difference (Yang–Dalton), absolute value.

    For binary variables, uses the variance pooling appropriate for proportions.
    """
    s = np.asarray(sample, dtype=float)
    b = np.asarray(benchmark, dtype=float)
    if binary:
        p_s = np.mean(s)
        p_b = np.mean(b)
        pooled = np.sqrt((p_s * (1 - p_s) + p_b * (1 - p_b)) / 2)
    else:
        pooled = np.sqrt((s.var(ddof=1) + b.var(ddof=1)) / 2)
    if pooled == 0:
        return 0.0
    return float(abs(s.mean() - b.mean()) / pooled)


# ---------------------------------------------------------------------------
# Block E — Missingness  (Equations 8–9)
# ---------------------------------------------------------------------------
def littles_mcar(df: pd.DataFrame) -> tuple[float, float]:
    """Little's MCAR test. Returns (chi-square statistic, p-value).

    Tests the null hypothesis that data are missing completely at random.
    Implementation follows Little (1988) using the likelihood-ratio form.
    """
    x = df.copy()
    n, p = x.shape

    # Build missingness-pattern groups
    patterns = x.isna().apply(lambda r: tuple(r.values), axis=1)
    groups = x.groupby(patterns, sort=False)

    # Global EM estimate of mean/cov using observed values only (mean imputation
    # as a robust fallback — adequate for the LR statistic's leading term).
    mu = x.mean(numeric_only=True).values
    cov = np.array(x.cov(numeric_only=True).values, dtype=float, copy=True)
    cov += np.eye(p) * 1e-6  # stabilise

    d2_total = 0.0
    dof = 0
    for pattern, grp in groups:
        obs_idx = [i for i, m in enumerate(pattern) if not m]
        if not obs_idx:
            continue
        mu_o = mu[obs_idx]
        cov_o = cov[np.ix_(obs_idx, obs_idx)]
        inv = np.linalg.pinv(cov_o)
        diff = grp.iloc[:, obs_idx].values - mu_o
        d2_total += float(np.sum(diff @ inv * diff))
        dof += len(obs_idx) * (len(grp) - 1)

    dof = max(dof, 1)
    p_value = float(stats.chi2.sf(d2_total, dof))
    return float(d2_total), p_value


def fraction_missing_information(within_var: float, between_var: float, m: int) -> float:
    """Rubin's fraction of missing information for a pooled MICE estimate.

    FMI ≈ (r + 2 / (df + 3)) / (r + 1)   where   r = (1 + 1/m) · B / W
    """
    if within_var <= 0:
        raise ValueError("within-imputation variance must be positive")
    if m < 2:
        raise ValueError("need at least 2 imputations")
    r = (1 + 1.0 / m) * between_var / within_var
    df = (m - 1) * (1 + 1.0 / r) ** 2 if r > 0 else float("inf")
    return float((r + 2.0 / (df + 3.0)) / (r + 1.0))


# ---------------------------------------------------------------------------
# Block F — Record linkage  (Equations 10–12)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class LinkageResult:
    match_rate: float
    false_match_rate: float
    n_candidates: int
    n_matches: int

    def passes(self, threshold: float = 0.90) -> bool:
        return self.match_rate >= threshold and self.false_match_rate <= 0.01


def fellegi_sunter(
    scores: np.ndarray,
    truth: np.ndarray | None = None,
    upper: float = 6.0,
    lower: float = -2.0,
) -> LinkageResult:
    """Fellegi–Sunter probabilistic linkage decision rule.

    Parameters
    ----------
    scores
        Log-likelihood ratio scores (one per candidate pair).
    truth
        Optional boolean array of ground-truth matches used to compute the
        false-match rate among decided matches. When absent the FMR is
        estimated by mixture-model fit on the score distribution.
    upper, lower
        Decision thresholds λ_u and λ_l. Pairs with score ≥ upper are
        classified as matches, ≤ lower as non-matches, and in between are
        sent to clerical review (counted as unresolved).
    """
    s = np.asarray(scores, dtype=float)
    match_mask = s >= upper
    n_matches = int(match_mask.sum())

    if truth is not None:
        t = np.asarray(truth, dtype=bool)
        if t.shape != s.shape:
            raise ValueError("truth must match scores shape")
        fmr = float((match_mask & ~t).sum() / max(match_mask.sum(), 1))
    else:
        # Approximate FMR from Gaussian mixture on score distribution
        _mu_m, mu_u = np.percentile(s, 90), np.percentile(s, 10)
        sigma = s.std(ddof=1)
        fmr = 0.0 if sigma == 0 else float(stats.norm.sf((upper - mu_u) / sigma))

    match_rate = float(n_matches / len(s))
    return LinkageResult(
        match_rate=match_rate,
        false_match_rate=fmr,
        n_candidates=int(len(s)),
        n_matches=n_matches,
    )


# ---------------------------------------------------------------------------
# Block G — Inter-coder reliability  (Equation 13)
# ---------------------------------------------------------------------------
def cohens_kappa(coder_a: np.ndarray, coder_b: np.ndarray) -> float:
    """Cohen's κ on paired categorical codings (e.g. dual ICD-10-CM coding).

    κ = (p_o − p_e) / (1 − p_e)
    """
    a = np.asarray(coder_a)
    b = np.asarray(coder_b)
    if a.shape != b.shape:
        raise ValueError("coder arrays must match in shape")
    labels = np.unique(np.concatenate([a, b]))
    len(a)
    p_o = float((a == b).mean())
    p_e = 0.0
    for lbl in labels:
        p_e += (a == lbl).mean() * (b == lbl).mean()
    if p_e >= 1.0:
        return float("nan")
    return float((p_o - p_e) / (1 - p_e))


# ---------------------------------------------------------------------------
# Block H — Temporal stability  (Equations 14–15)
# ---------------------------------------------------------------------------
def cusum(
    series: pd.Series | np.ndarray,
    target: float | None = None,
    k: float = 0.5,
    h: float = 4.0,
) -> pd.DataFrame:
    """Tabular CUSUM control chart on a monthly claim-volume series.

    Returns a DataFrame with columns ``[month, value, c_plus, c_minus, out_of_control]``.
    Out-of-control months are flagged when |C±| > h·σ.
    """
    x = np.asarray(series, dtype=float)
    mu = float(target) if target is not None else float(x.mean())
    sigma = float(x.std(ddof=1))
    if sigma == 0:
        sigma = 1.0
    c_plus = np.zeros_like(x)
    c_minus = np.zeros_like(x)
    for i in range(1, len(x)):
        c_plus[i] = max(0.0, c_plus[i - 1] + (x[i] - mu) - k * sigma)
        c_minus[i] = max(0.0, c_minus[i - 1] - (x[i] - mu) - k * sigma)
    limit = h * sigma
    return pd.DataFrame(
        {
            "month": np.arange(len(x)),
            "value": x,
            "c_plus": c_plus,
            "c_minus": c_minus,
            "out_of_control": (c_plus > limit) | (c_minus > limit),
        }
    )


# ---------------------------------------------------------------------------
# Block I — Predictive validity  (Equations 16–17)
# ---------------------------------------------------------------------------
def auroc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """Area under the receiver operating characteristic curve."""
    return float(roc_auc_score(y_true, y_score))
